﻿'GAP_CLoSR_GUI.exe (this application) is an implementation of GAP_CLoSR tools and methods 
'developed by Dr Alex Lechner (alexmarklechner@yahoo.com.au) as a part of the Australian 
'Government's National Environmental Research Program (NERP) Landscapes and Policy hub.
'GAP_CLoSR_GUI.exe was developed by Dr Michael Lacey (Michael.Lacey@utas.edu.au), in 
'association with Alex Lechner and the NERP Landscapes and Policy hub and is licensed 
'under the Creative Commons AttributionNonCommercial-ShareAlike 3.0 Australia 
'(CC BY-NC-SA 3.0 AU) license . To view a copy of this licence, 
'visit https://creativecommons.org/licenses/by-nc-sa/3.0/au/).

Public Class frm_Main
    'set some module level variables
    ''
    'Filenames and locations
    Private GC_RootDir As String   'base folder for raster processing
    Private GC_OutputDir As String 'output folder for for GAP_CLoSR.py
    Private GC_input_CC As String            'lh_cc            raster variable name
    Private GC_input_gap_cross As String     'gap_cross        raster variable name
    Private GC_input_gap_crossO As String    'gap_crosso       raster variable name
    Private GC_input_luse As String          'luse             raster variable name
    Private GC_input_luse_shp As String      'luse.shp         shapefile variable name
    Private GC_input_changelyr As String     'changelayer      raster variable name
    Private GC_input_changelyr_shp As String 'changelayer.shp  shapefile variable name
    Private GC_veg_removal As String         'lh_ccrem         raster variable name
    Private GC_veg_addition As String        'lh_ccadd         raster variable name
    Private GC_gapcross_add As String        'gap_crossadd     raster variable name
    Private GC_luse_add As String            'luse_add         raster variable name
    'testing
    Private GC_LastFolder As String  'the last visited folder
    Private GC_v As New List(Of String)  'list of vegetation rasters
    Private GC_g As New List(Of String)  'list of gapcross rasters
    Private GC_l As New List(Of String)  'list of landuse rasters
    Private GC_v_sel As String           'the selected veg raster for GAP_CLoSR script
    Private GC_g_sel As String           'the selected gapcross raster for GAP_CLoSR script
    Private GC_l_sel As String           'the selected landuse raster for GAP_CLoSR script

    'Processing parameters
    Private GC_conv_luse_RVfield As String   'variable for Python Script Convert_luseToRaster.py
    Private GC_Max_dist1 As Double           'variable for Python Script CreateGapCrossingLayer.py
    Private GC_CellMultiplier As Double      'variable for Python Script CreateGapCrossingLayerOLD.py
    Private GC_FieldName As String           'variable for Python Script 1_CreateRasterChangeLayer.py
    Private GC_HydrologyValue1 As Double     'variable for Python Script 2b_ModifyVegetationLayer_Addition.py
    Private GC_CellMultiplier2 As Double     'variable for Python Script 3_CreateGapCrossingLayer.py
    Private GC_HydrologyValue2 As Double     'variable for Python Script 4_ModifyLuseLayer_AddInfra.py
    Private GC_original_pixel_size As Single 'variable for Python Script GAP_CLoSR_ArgV.py 
    Private GC_new_pixel_size As Single      'variable for Python Script GAP_CLoSR_ArgV.py
    Private GC_Max_cost As Single            'variable for Python Script GAP_CLoSR_ArgV.py
    Private GC_Max_distance As Double        'variable for Python Script GAP_CLoSR_ArgV.py
    Private GC_reclass_txt As String         'variable for Python Script GAP_CLoSR_ArgV.py

    'flags that datasets and paths exist
    Private GC_RootDir_exists As Boolean = False             'base folder exists
    Private GC_OutputDir_exists As Boolean = False           'output folder exists
    Private GC_input_CC_exists As Boolean = False            'lh_cc            exists
    Private GC_input_gap_cross_exists As Boolean = False     'gap_cross        exists
    Private GC_input_gap_crossO_exists As Boolean = False    'gap_crosso       exists
    Private GC_input_luse_exists As Boolean = False         'luse             exists
    Private GC_input_luse_shp_exists As Boolean = False     'luse.shp         exists
    Private GC_input_changelyr_exists As Boolean = False    'changelayer      exists
    Private GC_input_changelyr_shp_exists As Boolean = False 'changelayer.shp  exists
    Private GC_veg_removal_exists As Boolean = False        'lh_ccrem         exists
    Private GC_veg_addition_exists As Boolean = False       'lh_ccadd         exists
    Private GC_gapcross_add_exists As Boolean = False       'gap_crossadd     exists
    Private GC_luse_add_exists As Boolean = False           'luse_add         exists
    Private GC_reclass_txt_exists As Boolean = False         'reclass.txt      exists

    Private GC_v_sel_exists As Boolean = False           'the selected veg raster for GAP_CLoSR script    exists
    Private GC_g_sel_exists As Boolean = False          'the selected gapcross raster for GAP_CLoSR script    exists
    Private GC_l_sel_exists As Boolean = False          'the selected landuse raster for GAP_CLoSR script    exists

    'flags that processing parameters are valid
    Private GC_conv_luse_RVfield_exists As Boolean = False   'for Python Script Convert_luseToRaster.py
    Private GC_Max_dist1_exists As Boolean = False           'for Python Script CreateGapCrossingLayer.py
    Private GC_CellMultiplier_exists As Boolean = False      'for Python Script CreateGapCrossingLayerOLD.py
    Private GC_FieldName_exists As Boolean = False           'for Python Script 1_CreateRasterChangeLayer.py
    Private GC_HydrologyValue1_exists As Boolean = False     'for Python Script 2b_ModifyVegetationLayer_Addition.py
    Private GC_CellMultiplier2_exists As Boolean = False     'for Python Script 3_CreateGapCrossingLayer.py
    Private GC_HydrologyValue2_exists As Boolean = False     'for Python Script 4_ModifyLuseLayer_AddInfra.py
    Private GC_original_pixel_size_exists As Boolean = False 'for Python Script GAP_CLoSR_ArgV.py 
    Private GC_new_pixel_size_exists As Boolean = False     'for Python Script GAP_CLoSR_ArgV.py
    Private GC_Max_cost_exists As Boolean = False           'for Python Script GAP_CLoSR_ArgV.py
    Private GC_Max_distance_exists As Boolean = False       'for Python Script GAP_CLoSR_ArgV.py
    'Python parameters
    Private GC_theApplication As String
    Private GC_ScriptsFolder As String  'Python Scripts folder
    Private GC_Scr_DefL As String       'Python Script Convert_luseToRaster.py
    Private GC_Scr_DefGC As String      'Python Script CreateGapCrossingLayer.py
    Private GC_Scr_DefO As String       'Python Script CreateGapCrossingLayerOLD.py
    Private GC_Scr_Scen1 As String      'Python Script 1_CreateRasterChangeLayer.py
    Private GC_Scr_Scen2a As String     'Python Script 2a_ModifyVegetationLayer_Removal.py
    Private GC_Scr_Scen2b As String     'Python Script 2b_ModifyVegetationLayer_Addition.py
    Private GC_Scr_Scen3 As String      'Python Script 3_CreateGapCrossingLayer.py
    Private GC_Scr_Scen4 As String      'Python Script 4_ModifyLuseLayer_AddInfra.py
    Private GC_theScript As String      'Python Script GAP_CLoSR_ArgV.py 
    Private GC_theArguments As String
    'coding parameters - some of these may be redundant
    Private GC_DefaultsLoaded As Boolean = False       'set initially to false (Have parameter defaults been loaded?)
    Private GC_AllVariablesComplete As Boolean = False 'set initially to false (Are all variables entered?)
    Private GC_DefaultsSaved As Boolean = False        'set initially to false (Have parameter defaults been saved?)
    Private GC_HasScripRun As Boolean = False          'set initially to false (Has the script run?)
    Private GC_PyAppSelected As Boolean = False 'has the python exe application been selected?
    Private GC_PyAppSaved As Boolean = False    'has the python exe application name been saved?
    Private GC_startup As Boolean = True
    'get the current exe application path to locate settings file
    Private appPath As String ' this variable now set at form load(), see below.
    'Private SPath As String 'default parameter file path. Now set after appPath at form load(), see below.
    Private PPath As String 'python settings file path. Now set after appPath at form load(), see below.

    '
    'Form load
    Private Sub frm_Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'get the current exe application path to locate settings file
        appPath = IO.Path.GetDirectoryName(Application.ExecutablePath)
        'create some folders if they do not exist
        Dim folderExists As Boolean
        folderExists = My.Computer.FileSystem.DirectoryExists(appPath & "\Config")
        If folderExists = False Then
            My.Computer.FileSystem.CreateDirectory(appPath & "\Config")
        End If
        folderExists = My.Computer.FileSystem.DirectoryExists(appPath & "\Scenarios")
        If folderExists = False Then
            My.Computer.FileSystem.CreateDirectory(appPath & "\Scenarios")
        End If

        'load python settings
        PPath = appPath & "\Config\Configs.txt"
        Try
            btn_LoadPyExePth_Click(Me, Nothing)
        Catch ex As Exception
            MsgBox("Could not load '\Config\Configs.txt'.")
        End Try

        'add some text to script and script error text boxes
        txt_PythonOutput.Text = "Script output." & vbCrLf & "====="
        txt_PythonError.Text = "Script error output." & vbCrLf & "====="

    End Sub
    'load parameter settings generic code
    Private Sub LoadParameters(path1 As String)

        'this routine opens a file to read based on the path passed
        'set combo box lists to nothing
        'it goes through the file line by line and reads the variable into GC_...
        'updates relevant text boxes
        'checks existence of the variable
        'close settings file
        'note type casting should be automatic as variables have been declared

        'listed below are the variables in the settings file in the expected order

        '"___Parameter_Settings_File___")
        '"___Root_Directory___")
        '"RootDir=" & GC_RootDir)
        '"___Shapefiles___")
        '"LanduseShapefile=" & GC_input_luse_shp)
        '"ParamRasterValueField1=" & GC_conv_luse_RVfield)
        '"ChangeShapfile=" & GC_input_changelyr_shp)
        '"ParamRasterValueField2=" & GC_FieldName)
        '"___Default___")
        '"HabitatTemplateRaster=" & GC_input_CC)
        '"DefaultLandUseRaster=" & GC_input_luse)
        '"DefaultGapCrossRaster=" & GC_input_gap_cross)
        '"ParamMaxDistance=" & GC_Max_dist1)
        '"DefaultGapCrossMethod2Raster=" & GC_input_gap_crossO)
        '"ParamCellMultiplier1=" & GC_CellMultiplier)
        '"___Scenario___")
        '"ScenarioChangeRaster=" & )
        '"ScenarioHabitatRemovalRaster=" & GC_veg_removal)
        '"ScenarioHabitatAdditionRaster=" & GC_veg_addition)
        '"ParamHydrologyValue1=" & GC_HydrologyValue1)
        '"ScenarioGapCrossRaster=" & GC_gapcross_add)
        '"ParamCellMultiplier2=" & GC_CellMultiplier2)
        '"ScenarioLandUseInfr=" & GC_luse_add)
        '"ParamHydrologyValue2=" & GC_HydrologyValue2)
        '"___Model___")
        '"ModelHabitatRaster=" & GC_v_sel)
        '"ModelGapCrossRaster=" & GC_g_sel)
        '"ModelLandUseRaster=" & GC_l_sel)
        '"OutputFolder=" & GC_OutputDir)
        '"ParamOriginalPixelSize=" & GC_original_pixel_size)
        '"ParamNewPixelSize=" & GC_new_pixel_size)
        '"ParamMaxCost=" & GC_Max_cost)
        '"ParamMaxDistance=" & GC_Max_distance)
        '"ParamReclassTextFile=" & GC_reclass_txt)
        '"___End_File___")


        Try
            Dim swrd As New IO.StreamReader(path1)
            '"___Parameter_Settings_File___")
            swrd.ReadLine() 'no data in this line

            '"___Root_Directory___")
            swrd.ReadLine() 'no data in this line

            '"RootDir=" & GC_RootDir)
            GC_RootDir = swrd.ReadLine().Split(CChar("=")).Last()
            txt_SelRootDir.Text = GC_RootDir
            txt_InputF.Text = GC_RootDir
            txt_rasterFolderTab2.Text = GC_RootDir
            If (GC_RootDir <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir) Then
                GC_RootDir_exists = True
                txt_InputF.ForeColor = Color.Black
                txt_rasterFolderTab2.ForeColor = Color.Black
                txt_SelRootDir.ForeColor = Color.Black
            Else
                GC_RootDir_exists = False
                txt_InputF.ForeColor = Color.Red
                txt_rasterFolderTab2.ForeColor = Color.Red
                txt_SelRootDir.ForeColor = Color.Red
            End If

            '"___Shapefiles___")
            swrd.ReadLine() 'no data in this line

            '"LanduseShapefile=" & GC_input_luse_shp)
            GC_input_luse_shp = swrd.ReadLine().Split(CChar("=")).Last()
            txt_LanduseShp.Text = GC_input_luse_shp
            If (GC_input_luse_shp <> "") And My.Computer.FileSystem.FileExists(GC_input_luse_shp) Then
                GC_input_luse_shp_exists = True
                txt_LanduseShp.ForeColor = Color.Black
            Else
                GC_input_luse_shp_exists = False
                txt_LanduseShp.ForeColor = Color.Red
            End If

            '"ParamRasterValueField1=" & GC_conv_luse_RVfield)
            GC_conv_luse_RVfield = swrd.ReadLine().Split(CChar("=")).Last()
            txt_RasterValueField.Text = GC_conv_luse_RVfield
            If txt_RasterValueField.TextLength > 0 Then
                GC_conv_luse_RVfield_exists = True
                txt_RasterValueField.ForeColor = Color.Black
            Else
                GC_conv_luse_RVfield_exists = False
                txt_RasterValueField.ForeColor = Color.Red
            End If

            '"ChangeShapfile=" & GC_input_changelyr_shp)
            GC_input_changelyr_shp = swrd.ReadLine().Split(CChar("=")).Last()
            txt_ChngLyrShpTab2.Text = GC_input_changelyr_shp
            If (GC_input_changelyr_shp <> "") And My.Computer.FileSystem.FileExists(GC_input_changelyr_shp) Then
                GC_input_changelyr_shp_exists = True
                txt_ChngLyrShpTab2.ForeColor = Color.Black
            Else
                GC_input_changelyr_shp_exists = False
                txt_ChngLyrShpTab2.ForeColor = Color.Red
            End If

            '"ParamRasterValueField2=" & GC_FieldName)
            GC_FieldName = swrd.ReadLine().Split(CChar("=")).Last()
            txt_RasValFldTab2.Text = GC_FieldName
            If txt_RasValFldTab2.TextLength > 0 Then
                GC_FieldName_exists = True
                txt_RasValFldTab2.ForeColor = Color.Black
            Else
                GC_FieldName_exists = False
                txt_RasValFldTab2.ForeColor = Color.Red
            End If

            '"___Default___")
            swrd.ReadLine() 'no data in this line

            '"HabitatTemplateRaster=" & GC_input_CC)
            GC_input_CC = swrd.ReadLine().Split(CChar("=")).Last()
            'copy to other tabs
            txt_inplh_cc1.Text = GC_input_CC
            txt_habitatTab2.Text = GC_input_CC

            '"DefaultLandUseRaster=" & GC_input_luse)
            GC_input_luse = swrd.ReadLine().Split(CChar("=")).Last()
            txt_luse1.Text = GC_input_luse
            txt_landuseTab2.Text = GC_input_luse

            '"DefaultGapCrossRaster=" & GC_input_gap_cross)
            GC_input_gap_cross = swrd.ReadLine().Split(CChar("=")).Last()
            txt_gap_cross1.Text = GC_input_gap_cross

            '"ParamMaxDistance=" & GC_Max_dist1)
            GC_Max_dist1 = CDbl(swrd.ReadLine().Split(CChar("=")).Last())
            If GC_Max_dist1 <> Nothing Then
                txt_MaxDist1.Text = CStr(GC_Max_dist1)
                GC_Max_dist1_exists = True
                txt_MaxDist1.ForeColor = Color.Black
            Else
                GC_Max_dist1_exists = False
                txt_MaxDist1.ForeColor = Color.Red
            End If

            '"DefaultGapCrossMethod2Raster=" & GC_input_gap_crossO)
            GC_input_gap_crossO = swrd.ReadLine().Split(CChar("=")).Last()
            txt_gapcrossOld.Text = GC_input_gap_crossO

            '"ParamCellMultiplier1=" & GC_CellMultiplier)
            GC_CellMultiplier = CDbl(swrd.ReadLine().Split(CChar("=")).Last())
            If GC_CellMultiplier <> Nothing Then
                txt_inpMultiTab1.Text = CStr(GC_CellMultiplier)
                GC_CellMultiplier_exists = True
                txt_inpMultiTab1.ForeColor = Color.Black
            Else
                GC_CellMultiplier_exists = False
                txt_inpMultiTab1.ForeColor = Color.Red
            End If

            '"___Scenario___")
            swrd.ReadLine() 'no data in this line

            '"ScenarioChangeRaster=" & GC_input_changelyr)
            GC_input_changelyr = swrd.ReadLine().Split(CChar("=")).Last()
            txt_ChangerasterTab2.Text = GC_input_changelyr

            '"ScenarioHabitatRemovalRaster=" & GC_veg_removal)
            GC_veg_removal = swrd.ReadLine().Split(CChar("=")).Last()
            txt_NewRasterRemv.Text = GC_veg_removal

            '"ScenarioHabitatAdditionRaster=" & GC_veg_addition)
            GC_veg_addition = swrd.ReadLine().Split(CChar("=")).Last()
            txt_NewRastAdd.Text = GC_veg_addition

            '"ParamHydrologyValue1=" & GC_HydrologyValue1)
            GC_HydrologyValue1 = CDbl(swrd.ReadLine().Split(CChar("=")).Last())
            If GC_HydrologyValue1 <> Nothing Then
                txt_HydrolVal1.Text = CStr(GC_HydrologyValue1)
                GC_HydrologyValue1_exists = True
                txt_HydrolVal1.ForeColor = Color.Black
            Else
                GC_HydrologyValue1_exists = False
                txt_HydrolVal1.ForeColor = Color.Red
            End If

            '"ScenarioGapCrossRaster=" & GC_gapcross_add)
            GC_gapcross_add = swrd.ReadLine().Split(CChar("=")).Last()
            txt_GapcrossTab2.Text = GC_gapcross_add

            '"ParamCellMultiplier2=" & GC_CellMultiplier2)
            GC_CellMultiplier2 = CDbl(swrd.ReadLine().Split(CChar("=")).Last())
            If GC_CellMultiplier2 <> Nothing Then
                txt_CellMultip2.Text = CStr(GC_CellMultiplier2)
                GC_CellMultiplier2_exists = True
                txt_CellMultip2.ForeColor = Color.Black
            Else
                GC_CellMultiplier2_exists = False
                txt_CellMultip2.ForeColor = Color.Red
            End If

            '"ScenarioLandUseInfr=" & GC_luse_add)
            GC_luse_add = swrd.ReadLine().Split(CChar("=")).Last()
            txt_infrastructure.Text = GC_luse_add

            '"ParamHydrologyValue2=" & GC_HydrologyValue2)
            GC_HydrologyValue2 = CDbl(swrd.ReadLine().Split(CChar("=")).Last())
            If GC_HydrologyValue2 <> Nothing Then
                txt_HydrolVal2.Text = CStr(GC_HydrologyValue2)
                GC_HydrologyValue2_exists = True
                txt_HydrolVal2.ForeColor = Color.Black
            Else
                GC_HydrologyValue2_exists = False
                txt_HydrolVal2.ForeColor = Color.Red
            End If

            '"___Model___")
            swrd.ReadLine() 'no data in this line

            '"ModelHabitatRaster=" & GC_v_sel)
            GC_v_sel = swrd.ReadLine().Split(CChar("=")).Last()
            txt_inp_cc.Text = GC_v_sel

            '"ModelGapCrossRaster=" & GC_g_sel)
            GC_g_sel = swrd.ReadLine().Split(CChar("=")).Last()
            txt_inp_gc.Text = GC_g_sel

            '"ModelLandUseRaster=" & GC_l_sel)
            GC_l_sel = swrd.ReadLine().Split(CChar("=")).Last()
            txt_inp_luse.Text = GC_l_sel

            '"OutputFolder=" & GC_OutputDir)
            GC_OutputDir = swrd.ReadLine().Split(CChar("=")).Last()
            txt_OutputF.Text = GC_OutputDir
            If (GC_OutputDir <> "") And My.Computer.FileSystem.DirectoryExists(GC_OutputDir) Then
                GC_OutputDir_exists = True
                txt_OutputF.ForeColor = Color.Black
            Else
                GC_OutputDir_exists = False
                txt_OutputF.ForeColor = Color.Red
            End If

            '"ParamOriginalPixelSize=" & GC_original_pixel_size)
            GC_original_pixel_size = CSng(swrd.ReadLine().Split(CChar("=")).Last())
            If GC_original_pixel_size <> Nothing Then
                txt_OriginalPixelSize.Text = CStr(GC_original_pixel_size)
                GC_original_pixel_size_exists = True
                txt_OriginalPixelSize.ForeColor = Color.Black
            Else
                GC_original_pixel_size_exists = False
                txt_OriginalPixelSize.ForeColor = Color.Red
            End If

            '"ParamNewPixelSize=" & GC_new_pixel_size)
            GC_new_pixel_size = CSng(swrd.ReadLine().Split(CChar("=")).Last())
            If GC_new_pixel_size <> Nothing Then
                txt_NewPixelSize.Text = CStr(GC_new_pixel_size)
                GC_new_pixel_size_exists = True
                txt_NewPixelSize.ForeColor = Color.Black
            Else
                GC_new_pixel_size_exists = False
                txt_NewPixelSize.ForeColor = Color.Red
            End If
            '"ParamMaxCost=" & GC_Max_cost)
            GC_Max_cost = CSng(swrd.ReadLine().Split(CChar("=")).Last())
            If GC_Max_cost <> Nothing Then
                txt_MaxCost.Text = CStr(GC_Max_cost)
                GC_Max_cost_exists = True
                txt_MaxCost.ForeColor = Color.Black
            Else
                GC_Max_cost_exists = False
                txt_MaxCost.ForeColor = Color.Red
            End If

            '"ParamMaxDistance=" & GC_Max_distance)
            GC_Max_distance = CDbl(swrd.ReadLine().Split(CChar("=")).Last())
            If GC_Max_distance <> Nothing Then
                txt_MaxDist.Text = CStr(GC_Max_distance)
                GC_Max_distance_exists = True
                txt_MaxDist.ForeColor = Color.Black
            Else
                GC_Max_distance_exists = False
                txt_MaxDist.ForeColor = Color.Red
            End If

            '"ParamReclassTextFile=" & GC_reclass_txt)
            GC_reclass_txt = swrd.ReadLine().Split(CChar("=")).Last()
            txt_ReclassTxtFile.Text = GC_reclass_txt
            If (GC_reclass_txt <> "") And My.Computer.FileSystem.FileExists(GC_reclass_txt) Then
                GC_reclass_txt_exists = True
                txt_ReclassTxtFile.ForeColor = Color.Black
            Else
                GC_reclass_txt_exists = False
                txt_ReclassTxtFile.ForeColor = Color.Red
            End If

            '"___End_File___")



            'close the settings file
            swrd.Close()
            '
            GC_DefaultsLoaded = True

            'update raster text boxcolours and existence flags
            UpdateRasterFieldsColoursAndExistence()

            'update list for combo boxes
            UpdateListsForComboBoxes()


        Catch ex As Exception
            If GC_startup = False Then
                MsgBox("There was an error in loading the parameters file.") 'not shown when attempting to load settings at startup
            End If
        End Try

    End Sub
    'update raster fields colours and existence
    Private Sub UpdateRasterFieldsColoursAndExistence()

        Try
            If (GC_input_CC <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_CC) Then
                GC_input_CC_exists = True
                txt_inplh_cc1.ForeColor = Color.Black
                txt_habitatTab2.ForeColor = Color.Black
            Else
                GC_input_CC_exists = False
                txt_inplh_cc1.ForeColor = Color.Red
                txt_habitatTab2.ForeColor = Color.Red
            End If

            If (GC_input_luse <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_luse) Then
                GC_input_luse_exists = True
                txt_landuseTab2.ForeColor = Color.Black
                txt_luse1.ForeColor = Color.Black
            Else
                GC_input_luse_exists = False
                txt_landuseTab2.ForeColor = Color.Red
                txt_luse1.ForeColor = Color.Red
            End If

            If (GC_input_gap_cross <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_gap_cross) Then
                GC_input_gap_cross_exists = True
                txt_gap_cross1.ForeColor = Color.Black
            Else
                GC_input_gap_cross_exists = False
                txt_gap_cross1.ForeColor = Color.Red
            End If

            If (GC_input_gap_crossO <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_gap_crossO) Then
                GC_input_gap_crossO_exists = True
                txt_gapcrossOld.ForeColor = Color.Black
            Else
                GC_input_gap_crossO_exists = False
                txt_gapcrossOld.ForeColor = Color.Red
            End If

            If (GC_input_changelyr <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_changelyr) Then
                GC_input_changelyr_exists = True
                txt_ChangerasterTab2.ForeColor = Color.Black
            Else
                GC_input_changelyr_exists = False
                txt_ChangerasterTab2.ForeColor = Color.Red
            End If

            If (GC_veg_removal <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_veg_removal) Then
                GC_veg_removal_exists = True
                txt_NewRasterRemv.ForeColor = Color.Black
            Else
                GC_veg_removal_exists = False
                txt_NewRasterRemv.ForeColor = Color.Red
            End If

            If (GC_veg_addition <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_veg_addition) Then
                GC_veg_addition_exists = True
                txt_NewRastAdd.ForeColor = Color.Black
            Else
                GC_veg_addition_exists = False
                txt_NewRastAdd.ForeColor = Color.Red
            End If

            If (GC_gapcross_add <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_gapcross_add) Then
                GC_gapcross_add_exists = True
                txt_GapcrossTab2.ForeColor = Color.Black
            Else
                GC_gapcross_add_exists = False
                txt_GapcrossTab2.ForeColor = Color.Red
            End If

            If (GC_luse_add <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_luse_add) Then
                GC_luse_add_exists = True
                txt_infrastructure.ForeColor = Color.Black
            Else
                GC_luse_add_exists = False
                txt_infrastructure.ForeColor = Color.Red
            End If

            If (GC_v_sel <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_v_sel) Then
                GC_v_sel_exists = True
                txt_inp_cc.ForeColor = Color.Black
            Else
                GC_v_sel_exists = True
                txt_inp_cc.ForeColor = Color.Red
            End If

            If (GC_g_sel <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_g_sel) Then
                GC_g_sel_exists = True
                txt_inp_gc.ForeColor = Color.Black
            Else
                GC_g_sel_exists = False
                txt_inp_gc.ForeColor = Color.Red
            End If

            If (GC_l_sel <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_l_sel) Then
                GC_l_sel_exists = True
                txt_inp_luse.ForeColor = Color.Black
            Else
                GC_l_sel_exists = False
                txt_inp_luse.ForeColor = Color.Red
            End If
        Catch ex As Exception
            MsgBox("there was an error in updating the raster fields")
        End Try
    End Sub
    'update lists for combo boxes
    Private Sub UpdateListsForComboBoxes()
        Try
            'clear combo box lists
            GC_v.Clear()
            GC_g.Clear()
            GC_l.Clear()
            'update vegetation list for combo box
            If Not GC_input_CC = "" Then
                UpdateVegList(GC_input_CC, GC_input_CC_exists)
            End If
            If Not GC_veg_removal = "" Then
                UpdateVegList(GC_veg_removal, GC_veg_removal_exists)
            End If
            If Not GC_veg_addition = "" Then
                UpdateVegList(GC_veg_addition, GC_veg_addition_exists)
            End If
            'update gapcross list for combo box
            If Not GC_input_gap_cross = "" Then
                UpdateGapcrossList(GC_input_gap_cross, GC_input_gap_cross_exists)
            End If
            If Not GC_input_gap_crossO = "" Then
                UpdateGapcrossList(GC_input_gap_crossO, GC_input_gap_crossO_exists)
            End If
            If Not GC_gapcross_add = "" Then
                UpdateGapcrossList(GC_gapcross_add, GC_gapcross_add_exists)
            End If
            'update landuse list for combo box
            If Not GC_input_luse = "" Then
                UpdateLanduseList(GC_input_luse, GC_input_luse_exists)
            End If
            If Not GC_luse_add = "" Then
                UpdateLanduseList(GC_luse_add, GC_luse_add_exists)
            End If
        Catch ex As Exception
            MsgBox("There was an error in updating lists")
        End Try
    End Sub

    'GAP_CLoSR root directory browser -tab 3
    Private Sub btn_RootDir_Click(sender As Object, e As EventArgs) Handles btn_RootDir.Click
        Dim tempText As String = txt_SelRootDir.Text

        'sets the initial selected directory to the luse.shp path if that has been previously selected
        dlg_GetRootFolder.SelectedPath = GC_LastFolder

        Try
            Dim dlgc = dlg_GetRootFolder.ShowDialog()
            If dlgc = Windows.Forms.DialogResult.OK Then
                txt_SelRootDir.Text = dlg_GetRootFolder.SelectedPath
                GC_RootDir = txt_SelRootDir.Text
                GC_LastFolder = dlg_GetRootFolder.SelectedPath
                'copy to other tabs
                txt_rasterFolderTab2.Text = txt_SelRootDir.Text 'update to tab 2
                txt_InputF.Text = txt_SelRootDir.Text 'update to tab 1
                'update text colour on all tabs if folder exists/does not exist
                If My.Computer.FileSystem.DirectoryExists(GC_RootDir) Then
                    GC_RootDir_exists = True
                    txt_InputF.ForeColor = Color.Black
                    txt_rasterFolderTab2.ForeColor = Color.Black
                    txt_SelRootDir.ForeColor = Color.Black
                Else
                    GC_RootDir_exists = False
                    txt_InputF.ForeColor = Color.Red
                    txt_rasterFolderTab2.ForeColor = Color.Red
                    txt_SelRootDir.ForeColor = Color.Red
                End If
                'update colours on text boxes existence flags and combo box lists


            ElseIf dlgc = Windows.Forms.DialogResult.Cancel Then
                txt_SelRootDir.Text = tempText
            End If
        Catch ex As Exception
            MsgBox("Please enter or select the path to the GAP_CLoSR\python_processing folder")
        End Try
    End Sub
    'raster folder leave generic
    Private Sub RasterFolderLeave()
        'update raster text boxcolours and existence flags
        UpdateRasterFieldsColoursAndExistence()
        'update list for combo boxes
        UpdateListsForComboBoxes()
    End Sub

    ''
    'entering Select Root Dir text box
    Private Sub txt_SelRootDir_Enter(sender As Object, e As EventArgs) Handles txt_SelRootDir.Enter
        txt_SelRootDir.ForeColor = Color.Blue
    End Sub
    'entering inp cc text box
    Private Sub txt_inp_cc_Enter(sender As Object, e As EventArgs) Handles txt_inp_cc.Enter
        txt_inp_cc.ForeColor = Color.Blue
    End Sub
    'entering inp gc text box
    Private Sub txt_inp_gc_Enter(sender As Object, e As EventArgs) Handles txt_inp_gc.Enter
        txt_inp_gc.ForeColor = Color.Blue
    End Sub
    'entering inp luse text box
    Private Sub txt_inp_luse_Enter(sender As Object, e As EventArgs) Handles txt_inp_luse.Enter
        txt_inp_luse.ForeColor = Color.Blue
    End Sub
    'entering OriginalPixelSize text box
    Private Sub txt_OriginalPixelSize_Enter(sender As Object, e As EventArgs) Handles txt_OriginalPixelSize.Enter
        txt_OriginalPixelSize.ForeColor = Color.Blue
    End Sub
    'entering NewPixelSize text box
    Private Sub txt_NewPixelSize_Enter(sender As Object, e As EventArgs) Handles txt_NewPixelSize.Enter
        txt_NewPixelSize.ForeColor = Color.Blue
    End Sub
    'entering MaxCost text box
    Private Sub txt_MaxCost_Enter(sender As Object, e As EventArgs) Handles txt_MaxCost.Enter
        txt_MaxCost.ForeColor = Color.Blue
    End Sub
    'entering MaxDist text box
    Private Sub txt_MaxDist_Enter(sender As Object, e As EventArgs) Handles txt_MaxDist.Enter
        txt_MaxDist.ForeColor = Color.Blue
    End Sub
    'entering reclass_txt text box
    Private Sub txt_ReclassTxtFile_Enter(sender As Object, e As EventArgs) Handles txt_ReclassTxtFile.Enter
        txt_ReclassTxtFile.ForeColor = Color.Blue
    End Sub
    'leaving select root directory text box
    Private Sub txt_SelRootDir_Leave(sender As Object, e As EventArgs) Handles txt_SelRootDir.Leave
        Try
            GC_RootDir = txt_SelRootDir.Text
            txt_rasterFolderTab2.Text = txt_SelRootDir.Text 'update to tab 2
            txt_InputF.Text = txt_SelRootDir.Text 'update to tab 1
            If (GC_RootDir <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir) Then
                GC_RootDir_exists = True
                txt_InputF.ForeColor = Color.Black
                txt_rasterFolderTab2.ForeColor = Color.Black
                txt_SelRootDir.ForeColor = Color.Black
            Else
                GC_RootDir_exists = False
                txt_InputF.ForeColor = Color.Red
                txt_rasterFolderTab2.ForeColor = Color.Red
                txt_SelRootDir.ForeColor = Color.Red
            End If
            'update raster existence, colors and combo box lists
            RasterFolderLeave()

        Catch ex As Exception
            MsgBox("enter text")
        End Try
    End Sub
    'leaving inp cc text box
    Private Sub txt_inp_cc_Leave(sender As Object, e As EventArgs) Handles txt_inp_cc.Leave
        Try
            GC_v_sel = txt_inp_cc.Text
            If (GC_v_sel <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_v_sel) Then
                GC_v_sel_exists = True
                txt_inp_cc.ForeColor = Color.Black
            Else
                GC_v_sel_exists = True
                txt_inp_cc.ForeColor = Color.Red
            End If

        Catch ex As Exception
            MsgBox("enter text")
        End Try
    End Sub
    'leaving inp gc text box
    Private Sub txt_inp_gc_Leave(sender As Object, e As EventArgs) Handles txt_inp_gc.Leave
        Try
            GC_g_sel = txt_inp_gc.Text
            If (GC_g_sel <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_g_sel) Then
                GC_g_sel_exists = True
                txt_inp_gc.ForeColor = Color.Black
            Else
                GC_g_sel_exists = False
                txt_inp_gc.ForeColor = Color.Red
            End If

        Catch ex As Exception
            MsgBox("enter text")
        End Try
    End Sub
    'leaving inp luse text box
    Private Sub txt_inp_luse_Leave(sender As Object, e As EventArgs) Handles txt_inp_luse.Leave
        Try
            GC_l_sel = txt_inp_luse.Text
            If (GC_l_sel <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_l_sel) Then
                GC_l_sel_exists = True
                txt_inp_luse.ForeColor = Color.Black
            Else
                GC_l_sel_exists = False
                txt_inp_luse.ForeColor = Color.Red
            End If

        Catch ex As Exception
            MsgBox("enter text")
        End Try
    End Sub
    'leaving OriginalPixelSize text box - numerical
    Private Sub txt_OriginalPixelSize_Leave(sender As Object, e As EventArgs) Handles txt_OriginalPixelSize.Leave
        Try
            If txt_OriginalPixelSize.Text <> Nothing Then
                GC_original_pixel_size = CSng(txt_OriginalPixelSize.Text)
                GC_original_pixel_size_exists = True
                txt_OriginalPixelSize.ForeColor = Color.Black
            Else
                GC_original_pixel_size_exists = False
                txt_OriginalPixelSize.ForeColor = Color.Red
            End If

        Catch ex As Exception
            MsgBox("The value entered for Original Pixel Size must be a number")
            txt_OriginalPixelSize.Select()
        End Try
    End Sub
    'leaving NewPixelSize text box - numerical
    Private Sub txt_NewPixelSize_Leave(sender As Object, e As EventArgs) Handles txt_NewPixelSize.Leave
        Try
            If txt_NewPixelSize.Text <> Nothing Then
                GC_new_pixel_size = CSng(txt_NewPixelSize.Text)
                GC_new_pixel_size_exists = True
                txt_NewPixelSize.ForeColor = Color.Black
            Else
                GC_new_pixel_size_exists = False
                txt_NewPixelSize.ForeColor = Color.Red
            End If

        Catch ex As Exception
            MsgBox("The value entered for New Pixel Size must be a number")
            txt_NewPixelSize.Select()
        End Try
    End Sub
    'leaving MaxCost text box - numerical
    Private Sub txt_MaxCost_Leave(sender As Object, e As EventArgs) Handles txt_MaxCost.Leave
        Try
            If txt_MaxCost.Text <> Nothing Then
                GC_Max_cost = CSng(txt_MaxCost.Text)
                GC_Max_cost_exists = True
                txt_MaxCost.ForeColor = Color.Black
            Else
                GC_Max_cost_exists = False
                txt_MaxCost.ForeColor = Color.Red
            End If

        Catch ex As Exception
            MsgBox("The value entered for Max Cost must be a number")
            txt_MaxCost.Select()
        End Try
    End Sub
    'leaving MaxDist text box - numerical
    Private Sub txt_MaxDist_Leave(sender As Object, e As EventArgs) Handles txt_MaxDist.Leave
        Try
            If txt_MaxDist.Text <> Nothing Then
                GC_Max_distance = CDbl(txt_MaxDist.Text)
                GC_Max_distance_exists = True
                txt_MaxDist.ForeColor = Color.Black
            Else
                GC_Max_distance_exists = False
                txt_MaxDist.ForeColor = Color.Red
            End If

        Catch ex As Exception
            MsgBox("The value entered for Max Distance must be a number")
            txt_MaxDist.ForeColor = Color.Red
            txt_MaxDist.Select()
        End Try
    End Sub
    'leaving reclass_txt text box
    Private Sub txt_ReclassTxtFile_Leave(sender As Object, e As EventArgs) Handles txt_ReclassTxtFile.Leave
        Try
            GC_reclass_txt = txt_ReclassTxtFile.Text
            If (GC_reclass_txt <> "") And My.Computer.FileSystem.FileExists(GC_reclass_txt) Then
                GC_reclass_txt_exists = True
                txt_ReclassTxtFile.ForeColor = Color.Black
            Else
                GC_reclass_txt_exists = False
                txt_ReclassTxtFile.ForeColor = Color.Red
            End If

        Catch ex As Exception
            MsgBox("Please enter reclass_txt name with path.")
        End Try
    End Sub
    'enter output folder text box - tab 3
    Private Sub txt_OutputF_Enter(sender As Object, e As EventArgs) Handles txt_OutputF.Enter
        txt_OutputF.ForeColor = Color.Blue
    End Sub
    'leave output folder text box - tab 3
    Private Sub txt_OutputF_Leave(sender As Object, e As EventArgs) Handles txt_OutputF.Leave
        Try
            GC_OutputDir = txt_OutputF.Text
            If (GC_OutputDir <> "") And My.Computer.FileSystem.DirectoryExists(GC_OutputDir) Then
                GC_OutputDir_exists = True
                txt_OutputF.ForeColor = Color.Black
            Else
                GC_OutputDir_exists = False
                txt_OutputF.ForeColor = Color.Red
            End If

        Catch ex As Exception
            MsgBox("Error in setting output folder.")
        End Try
    End Sub
    '

    'clear all parameter settings
    Private Sub btn_ClearAll_Click(sender As Object, e As EventArgs) Handles btn_ClearAll.Click
        'clear text boxes
        txt_InputF.Text = ""
        txt_rasterFolderTab2.Text = ""
        txt_SelRootDir.Text = ""
        txt_OutputF.Text = ""
        txt_inplh_cc1.Text = ""
        txt_habitatTab2.Text = ""
        txt_NewRasterRemv.Text = ""
        txt_NewRastAdd.Text = ""
        txt_gap_cross1.Text = ""
        txt_gapcrossOld.Text = ""
        txt_GapcrossTab2.Text = ""
        txt_LanduseShp.Text = ""
        txt_luse1.Text = ""
        txt_landuseTab2.Text = ""
        txt_infrastructure.Text = ""
        txt_ChngLyrShpTab2.Text = ""
        txt_ChangerasterTab2.Text = ""
        txt_ReclassTxtFile.Text = ""
        txt_RasterValueField.Text = ""
        txt_HydrolVal1.Text = ""
        txt_MaxDist1.Text = ""
        txt_inpMultiTab1.Text = ""
        txt_CellMultip2.Text = ""
        txt_HydrolVal2.Text = ""
        txt_RasValFldTab2.Text = ""
        txt_OriginalPixelSize.Text = ""
        txt_NewPixelSize.Text = ""
        txt_MaxCost.Text = ""
        txt_MaxDist.Text = ""
        txt_inp_cc.Text = ""
        txt_inp_gc.Text = ""
        txt_inp_luse.Text = ""
        txt_PythonOutput.Text = ""
        txt_PythonError.Text = ""

        'reset variables
        GC_RootDir = Nothing
        GC_OutputDir = Nothing
        GC_input_CC = Nothing
        GC_input_gap_cross = Nothing
        GC_input_gap_crossO = Nothing
        GC_input_luse = Nothing
        GC_input_luse_shp = Nothing
        GC_input_changelyr = Nothing
        GC_input_changelyr_shp = Nothing
        GC_veg_removal = Nothing
        GC_veg_addition = Nothing
        GC_gapcross_add = Nothing
        GC_luse_add = Nothing
        GC_v.Clear()
        GC_g.Clear()
        GC_l.Clear()
        GC_v_sel = Nothing
        GC_g_sel = Nothing
        GC_l_sel = Nothing
        GC_conv_luse_RVfield = Nothing
        GC_Max_dist1 = Nothing
        GC_CellMultiplier = Nothing
        GC_FieldName = Nothing
        GC_HydrologyValue1 = Nothing
        GC_CellMultiplier2 = Nothing
        GC_HydrologyValue2 = Nothing
        GC_original_pixel_size = Nothing
        GC_new_pixel_size = Nothing
        GC_Max_cost = Nothing
        GC_Max_distance = Nothing
        GC_reclass_txt = Nothing
        GC_RootDir_exists = False
        GC_OutputDir_exists = False
        GC_input_CC_exists = False
        GC_input_gap_cross_exists = False
        GC_input_gap_crossO_exists = False
        GC_input_luse_exists = False
        GC_input_luse_shp_exists = False
        GC_input_changelyr_exists = False
        GC_input_changelyr_shp_exists = False
        GC_veg_removal_exists = False
        GC_veg_addition_exists = False
        GC_gapcross_add_exists = False
        GC_luse_add_exists = False
        GC_reclass_txt_exists = False
        GC_v_sel_exists = False
        GC_g_sel_exists = False
        GC_l_sel_exists = False
        GC_conv_luse_RVfield_exists = False
        GC_Max_dist1_exists = False
        GC_CellMultiplier_exists = False
        GC_FieldName_exists = False
        GC_HydrologyValue1_exists = False
        GC_CellMultiplier2_exists = False
        GC_HydrologyValue2_exists = False
        GC_original_pixel_size_exists = False
        GC_new_pixel_size_exists = False
        GC_Max_cost_exists = False
        GC_Max_distance_exists = False

        GC_DefaultsLoaded = False 'set initially to false (Have defaults been loaded?)
        btn_ClearAll.Enabled = False 'reset the button to not enabled
        'btn_ReadSettings.Text = "Load Settings"



        GC_AllVariablesComplete = False
    End Sub
    'button to select the reclass_txt file - Tab 3
    Private Sub btn_ReclTextFile_Click(sender As Object, e As EventArgs) Handles btn_ReclTextFile.Click

        Dim temp5 As String = txt_ReclassTxtFile.Text
        Try
            Dim dlgb = dlg_ReclassText.ShowDialog() ' find file dialog to find or set scenario file name
            If dlgb = Windows.Forms.DialogResult.OK Then
                txt_ReclassTxtFile.Text = dlg_ReclassText.FileName
                GC_reclass_txt = txt_ReclassTxtFile.Text
                If My.Computer.FileSystem.FileExists(GC_reclass_txt) Then
                    GC_reclass_txt_exists = True
                    txt_ReclassTxtFile.ForeColor = Color.Black
                Else
                    GC_reclass_txt_exists = False
                    txt_ReclassTxtFile.ForeColor = Color.Red
                End If

            ElseIf dlgb = Windows.Forms.DialogResult.Cancel Then
                txt_ReclassTxtFile.Text = temp5
            End If
        Catch ex As Exception
            MsgBox("Error in selecting reclass text file")
        End Try
    End Sub
    'select tab 3 by clicking on it - Tab 3
    Private Sub tb_3_Click(sender As Object, e As EventArgs) Handles tb_3.Click
        tb_3.Select()
    End Sub
    'select output folder' button - Tab 3
    Private Sub btn_OutputF_Click(sender As Object, e As EventArgs) Handles btn_OutputF.Click
        Dim tempText As String = txt_OutputF.Text

        Try
            Dim dlgc = dlg_GetRootFolder.ShowDialog()
            If dlgc = Windows.Forms.DialogResult.OK Then
                txt_OutputF.Text = dlg_GetRootFolder.SelectedPath
                GC_OutputDir = txt_OutputF.Text
                If My.Computer.FileSystem.DirectoryExists(GC_OutputDir) Then
                    GC_OutputDir_exists = True
                    txt_OutputF.ForeColor = Color.Black
                Else
                    GC_OutputDir_exists = False
                    txt_OutputF.ForeColor = Color.Red
                End If

            ElseIf dlgc = Windows.Forms.DialogResult.Cancel Then
                txt_OutputF.Text = tempText
            End If
        Catch ex As Exception
            MsgBox("Please enter or select the path to the raster folder")
        End Try
    End Sub
    'write Parameters to output file generic code   
    Private Sub SaveParamsGeneric(path2 As String)
        Try
            Dim sw As New IO.StreamWriter(path2, False) 'overwrite
            sw.WriteLine("___Parameter_Settings_File___")
            sw.WriteLine("___Root_Directory___")
            sw.WriteLine("RootDir=" & GC_RootDir)
            sw.WriteLine("___Shapefiles___")
            sw.WriteLine("LanduseShapefile=" & GC_input_luse_shp)
            sw.WriteLine("ParamRasterValueField1=" & GC_conv_luse_RVfield)
            sw.WriteLine("ChangeShapfile=" & GC_input_changelyr_shp)
            sw.WriteLine("ParamRasterValueField2=" & GC_FieldName)
            sw.WriteLine("___Default___")
            sw.WriteLine("HabitatTemplateRaster=" & GC_input_CC)
            sw.WriteLine("DefaultLandUseRaster=" & GC_input_luse)
            sw.WriteLine("DefaultGapCrossRaster=" & GC_input_gap_cross)
            sw.WriteLine("ParamMaxDistance=" & GC_Max_dist1)
            sw.WriteLine("DefaultGapCrossMethod2Raster=" & GC_input_gap_crossO)
            sw.WriteLine("ParamCellMultiplier1=" & GC_CellMultiplier)
            sw.WriteLine("___Scenario___")
            sw.WriteLine("ScenarioChangeRaster=" & GC_input_changelyr)
            sw.WriteLine("ScenarioHabitatRemovalRaster=" & GC_veg_removal)
            sw.WriteLine("ScenarioHabitatAdditionRaster=" & GC_veg_addition)
            sw.WriteLine("ParamHydrologyValue1=" & GC_HydrologyValue1)
            sw.WriteLine("ScenarioGapCrossRaster=" & GC_gapcross_add)
            sw.WriteLine("ParamCellMultiplier2=" & GC_CellMultiplier2)
            sw.WriteLine("ScenarioLandUseInfr=" & GC_luse_add)
            sw.WriteLine("ParamHydrologyValue2=" & GC_HydrologyValue2)
            sw.WriteLine("___Model___")
            sw.WriteLine("ModelHabitatRaster=" & GC_v_sel)
            sw.WriteLine("ModelGapCrossRaster=" & GC_g_sel)
            sw.WriteLine("ModelLandUseRaster=" & GC_l_sel)
            sw.WriteLine("OutputFolder=" & GC_OutputDir)
            sw.WriteLine("ParamOriginalPixelSize=" & GC_original_pixel_size)
            sw.WriteLine("ParamNewPixelSize=" & GC_new_pixel_size)
            sw.WriteLine("ParamMaxCost=" & GC_Max_cost)
            sw.WriteLine("ParamMaxDistance=" & GC_Max_distance)
            sw.WriteLine("ParamReclassTextFile=" & GC_reclass_txt)
            sw.WriteLine("___End_File___")

            sw.Close()
            GC_DefaultsSaved = True
        Catch ex As Exception
            MsgBox("Error while saving settings to file")
        End Try
    End Sub

    ''
    ''
    'run python script - generic code
    Private Sub ExecutePythonScript(PyApp As String, PyScript As String, PyArgs As String)
        Dim theApplication As String
        Dim theScript As String
        Dim theArguments As String

        theApplication = PyApp
        'add path to the script name
        theScript = PyScript
        'include the arguments
        theArguments = PyArgs

        Try
            Dim p As Process = New Process()
            p.StartInfo.UseShellExecute = False
            p.StartInfo.RedirectStandardOutput = True
            p.StartInfo.RedirectStandardError = True
            p.StartInfo.FileName = theApplication
            p.StartInfo.Arguments = theScript & theArguments
            p.StartInfo.UseShellExecute = False
            p.StartInfo.CreateNoWindow = True
            p.Start()
            'txt_PythonOutput.Text = txt_PythonOutput.Text & vbCrLf & "=====" & vbCrLf & (p.StandardOutput.ReadToEnd())
            'txt_PythonError.Text = txt_PythonError.Text & vbCrLf & "=====" & vbCrLf & (p.StandardError.ReadToEnd())
            txt_PythonOutput.AppendText(vbCrLf & (p.StandardOutput.ReadToEnd()) & "=====")
            txt_PythonOutput.Select(txt_PythonOutput.TextLength(), 0)
            txt_PythonError.AppendText(vbCrLf & (p.StandardError.ReadToEnd()) & "=====")
            txt_PythonError.Select(txt_PythonError.TextLength(), 0)

            p.WaitForExit()
            p.Close()

        Catch ex As Exception
            MsgBox("unhandled exception")
        End Try
    End Sub
    'runs Python Script GAP_CLoSR_ArgV4.py (GC_theScript) (10 arguments) - button currently on tab 4
    Private Sub btn_Run_GC_Click(sender As Object, e As EventArgs) Handles btn_Run_GC.Click

        Dim theApplication As String
        Dim theScript As String
        Dim theArguments As String
        Dim s As String
        'buttons disabled so that user does not press it twice
        btn_Run_GC.Enabled = False
        btn_ProcessrastersTab4.Enabled = False

        'Script Arguments        
        'RootDir				        GC_RootDir
        'output_folder                  GC_OutputDir
        'input_CC			            GC_v_sel
        'input_gap_cross			    GC_g_sel
        'input_luse			            GC_l_sel
        'original_pixel_size		    GC_original_pixel_size
        'new_pixel_size			        GC_new_pixel_size
        'Max_cost			            GC_Max_cost
        'Max_distance			        GC_Max_distance
        'reclass_txt			        GC_reclass_txt

        'there is probably a more efficient way to do it but will try it this way:
        s = "" & vbCrLf
        If GC_RootDir_exists = False Then
            s = s & "raster folder" & vbCrLf
        End If
        If GC_OutputDir_exists = False Then
            s = s & "output folder" & vbCrLf
        End If
        If GC_v_sel_exists = False Then
            s = s & "gap cross raster" & vbCrLf
        End If
        If GC_g_sel_exists = False Then
            s = s & "land use raster" & vbCrLf
        End If
        If GC_l_sel_exists = False Then
            s = s & "vegetation (habitat) raster" & vbCrLf
        End If
        If GC_original_pixel_size_exists = False Then
            s = s & "original pixel size value" & vbCrLf
        End If
        If GC_new_pixel_size_exists = False Then
            s = s & "new pixel size value" & vbCrLf
        End If
        If GC_Max_cost_exists = False Then
            s = s & "maximum cost value" & vbCrLf
        End If
        If GC_Max_distance_exists = False Then
            s = s & "maximum distance value" & vbCrLf
        End If
        If GC_reclass_txt_exists = False Then
            s = s & "reclass text file" & vbCrLf
        End If

        If s <> ("" & vbCrLf) Then
            MessageBox.Show("please enter the following data:" & s, "Some inputs are missing", MessageBoxButtons.OK)
        Else
            theApplication = GC_theApplication
            'add path to the script name
            theScript = GC_ScriptsFolder & "\" & GC_theScript
            'there are currently nine arguments
            theArguments = " " & GC_RootDir & " " & GC_OutputDir & " " & GC_v_sel & " " & GC_g_sel & " " & GC_l_sel & " " & GC_original_pixel_size & " " & GC_new_pixel_size & " " & GC_Max_cost & " " & GC_Max_distance & " " & GC_reclass_txt

            ExecutePythonScript(theApplication, theScript, theArguments)

        End If
        'buttons enabled again
        btn_Run_GC.Enabled = True
        btn_ProcessrastersTab4.Enabled = True

    End Sub
    'runs  Python Script Convert_luseToRaster.py (GC_Scr_DefL) (5 arguments)
    Private Sub RunScriptDefL()
        Dim theApplication As String
        Dim theScript As String
        Dim theArguments As String

        'Script Arguments        
        'basefolder			            GC_RootDir
        'lh_cc				            GC_input_CC
        'luse.shp with path		        GC_input_luse_shp
        'luse				            GC_input_luse
        'rastervalue field "GRIDCODE"	GC_conv_luse_RVfield

        'run the script
        theApplication = GC_theApplication
        'add path to the script name
        theScript = GC_ScriptsFolder & "\" & GC_Scr_DefL
        'there are currently nine arguments
        theArguments = " " & GC_RootDir & " " & GC_input_CC & " " & GC_input_luse_shp & " " & GC_input_luse & " " & GC_conv_luse_RVfield

        ExecutePythonScript(theApplication, theScript, theArguments)
        '


    End Sub
    '   prepare data for Convert_luseToRaster.py
    Private Sub btn_RunConvLusetoRaster_Click(sender As Object, e As EventArgs) Handles btn_RunConvLusetoRaster.Click
        Dim s As String
        'button disabled so that user does not press it twice
        btn_RunConvLusetoRaster.Enabled = False
        'Script Arguments        
        'basefolder			            GC_RootDir
        'lh_cc				            GC_input_CC
        'luse.shp with path		        GC_input_luse_shp
        'luse				            GC_input_luse
        'rastervalue field "GRIDCODE"	GC_conv_luse_RVfield


        'there is probably a more efficient way to do it but will try it this way:
        s = "" & vbCrLf
        If GC_RootDir_exists = False Then
            s = s & "raster folder" & vbCrLf
        End If
        If GC_input_CC_exists = False Then
            s = s & "vegetation raster" & vbCrLf
        End If
        If GC_input_luse_shp_exists = False Then
            s = s & "land-use shapefile" & vbCrLf
        End If
        If GC_conv_luse_RVfield_exists = False Then
            s = s & "raster value field" & vbCrLf
        End If
        If txt_luse1.TextLength = 0 Then 'just look for a valid name for the output dataset
            s = s & "output land use raster name" & vbCrLf
        End If
        If s <> ("" & vbCrLf) Then
            MessageBox.Show("please enter the following data:" & s, "Some inputs are missing", MessageBoxButtons.OK)
        Else
            If GC_input_luse_exists = False Then
                'run the script
                RunScriptDefL()
                chk_SelDefL.Checked = False
            Else
                Dim MB1 = MessageBox.Show("An output dataset with the same name already exists. Do you want to replace it?", "Output land use raster already exists", MessageBoxButtons.OKCancel)
                If MB1 = Windows.Forms.DialogResult.OK Then
                    'run the script
                    RunScriptDefL()
                    chk_SelDefL.Checked = False
                Else
                End If
            End If
        End If
        'button enabled
        btn_RunConvLusetoRaster.Enabled = True
        'check existence of output
        'update text colour on all tabs if folder exists/does not exist
        If My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_luse) Then
            GC_input_luse_exists = True
            txt_landuseTab2.ForeColor = Color.Black
            txt_luse1.ForeColor = Color.Black
        Else
            GC_input_luse_exists = False
            txt_landuseTab2.ForeColor = Color.Red
            txt_luse1.ForeColor = Color.Red
        End If
        'update landuse list for combo box
        If Not GC_input_luse = "" Then
            UpdateLanduseList(GC_input_luse, GC_input_luse_exists)
        End If

    End Sub
    'runs Python Script CreateGapCrossingLayer.py (GC_Scr_DefGC) (4 arguments)
    Private Sub RunScriptDefGC()
        Dim theApplication As String
        Dim theScript As String
        Dim theArguments As String
        'Script Arguments        
        'basefolder			        GC_RootDir
        'lh_cc				        GC_input_CC
        'gapcross			        GC_input_gap_cross
        'maxdistance1 (numeric)		GC_Max_dist1

        theApplication = GC_theApplication
        'add path to the script name
        theScript = GC_ScriptsFolder & "\" & GC_Scr_DefGC
        'there are currently 4 arguments
        theArguments = " " & GC_RootDir & " " & GC_input_CC & " " & GC_input_gap_cross & " " & GC_Max_dist1

        ExecutePythonScript(theApplication, theScript, theArguments)
    End Sub
    '   prepare data for CreateGapCrossingLayer.py
    Private Sub btn_CreateGapCross_Click(sender As Object, e As EventArgs) Handles btn_CreateGapCross.Click
        Dim s As String
        'button disabled so that user does not press it twice
        btn_CreateGapCross.Enabled = False
        'Script Arguments        
        'basefolder			        GC_RootDir
        'lh_cc				        GC_input_CC
        'gapcross			        GC_input_gap_cross
        'maxdistance1 (numeric)		GC_Max_dist1
        'there is probably a more efficient way to do it but will try it this way:
        s = "" & vbCrLf
        If GC_RootDir_exists = False Then
            s = s & "raster folder" & vbCrLf
        End If
        If GC_input_CC_exists = False Then
            s = s & "vegetation raster" & vbCrLf
        End If
        If GC_Max_dist1_exists = False Then '''''fix this bit
            s = s & "maximum distance" & vbCrLf
        End If
        If txt_gap_cross1.TextLength = 0 Then 'just look for a valid name for the output dataset
            s = s & "output gap cross raster name" & vbCrLf
        End If
        If s <> ("" & vbCrLf) Then
            MessageBox.Show("please enter the following data:" & s, "Some inputs are missing", MessageBoxButtons.OK)
        Else
            If GC_input_gap_cross_exists = False Then
                'run the script
                RunScriptDefGC()
                chk_SelDefGC.Checked = False
            Else
                Dim MB1 = MessageBox.Show("An output dataset with the same name already exists. Do you want to replace it?", "Output gap cross raster already exists", MessageBoxButtons.OKCancel)
                If MB1 = Windows.Forms.DialogResult.OK Then
                    'run the script
                    RunScriptDefGC()
                    chk_SelDefGC.Checked = False
                End If
            End If
        End If
        'button enabled
        btn_CreateGapCross.Enabled = True
        'check existence
        If My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_gap_cross) Then
            GC_input_gap_cross_exists = True
            txt_gap_cross1.ForeColor = Color.Black
        Else
            GC_input_gap_cross_exists = False
            txt_gap_cross1.ForeColor = Color.Red
        End If
        'update gapcross list for combo box
        If Not GC_input_gap_cross = "" Then
            UpdateGapcrossList(GC_input_gap_cross, GC_input_gap_cross_exists)
        End If

    End Sub
    'runs Python Script CreateGapCrossingLayerOLD.py (GC_Scr_DefO) (4 arguments)
    Private Sub RunScriptDefO()
        Dim theApplication As String
        Dim theScript As String
        Dim theArguments As String
        'Script Arguments        
        'basefolder			        GC_RootDir
        'lh_cc				        GC_input_CC
        'gapcrosso			        GC_input_gap_crossO
        'maxdistance1 (numeric)		GC_CellMultiplier

        theApplication = GC_theApplication
        'add path to the script name
        theScript = GC_ScriptsFolder & "\" & GC_Scr_DefO
        'there are currently 4 arguments
        theArguments = " " & GC_RootDir & " " & GC_input_CC & " " & GC_input_gap_crossO & " " & GC_CellMultiplier

        ExecutePythonScript(theApplication, theScript, theArguments)
    End Sub
    '  prepare data for CreateGapCrossingLayerOLD.py
    Private Sub btn_GapCrossOld_Click(sender As Object, e As EventArgs) Handles btn_GapCrossOld.Click
        Dim s As String
        'button disabled so that user does not press it twice
        btn_GapCrossOld.Enabled = False
        'Script Arguments        
        'basefolder			        GC_RootDir
        'lh_cc				        GC_input_CC
        'gapcrosso			        GC_input_gap_crossO
        'maxdistance1 (numeric)		GC_CellMultiplier
        'there is probably a more efficient way to do it but will try it this way:
        s = "" & vbCrLf
        If GC_RootDir_exists = False Then
            s = s & "raster folder" & vbCrLf
        End If
        If GC_input_CC_exists = False Then
            s = s & "vegetation raster" & vbCrLf
        End If
        If GC_CellMultiplier_exists = False Then '''''fix this bit
            s = s & "cell multiplier" & vbCrLf
        End If
        If txt_gapcrossOld.TextLength = 0 Then 'just look for a valid name for the output dataset
            s = s & "output gap cross raster name" & vbCrLf
        End If
        If s <> ("" & vbCrLf) Then
            MessageBox.Show("please enter the following data:" & s, "Some inputs are missing", MessageBoxButtons.OK)
        Else
            If GC_input_gap_crossO_exists = False Then
                'run the script
                RunScriptDefO()
                chk_SelDefGCO.Checked = False
            Else
                Dim MB1 = MessageBox.Show("An output dataset with the same name already exists. Do you want to replace it?", "Output gap cross raster (old method) already exists", MessageBoxButtons.OKCancel)
                If MB1 = Windows.Forms.DialogResult.OK Then
                    'run the script
                    RunScriptDefO()
                    chk_SelDefGCO.Checked = False
                End If
            End If
        End If
        'button enabled
        btn_GapCrossOld.Enabled = True
        'update existence
        If My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_gap_crossO) Then
            GC_input_gap_crossO_exists = True
            txt_gapcrossOld.ForeColor = Color.Black
        Else
            GC_input_gap_crossO_exists = False
            txt_gapcrossOld.ForeColor = Color.Red
        End If
        'update gapcross list for combo box
        If Not GC_input_gap_crossO = "" Then
            UpdateGapcrossList(GC_input_gap_crossO, GC_input_gap_crossO_exists)
        End If

    End Sub
    'runs Python Script 1_CreateRasterChangeLayer.py (GC_Scr_Scen1) (5 arguments)
    Private Sub RunScriptScen1()
        Dim theApplication As String
        Dim theScript As String
        Dim theArguments As String
        '   basefolder			        GC_RootDir
        '	changelayer.shp with path   GC_input_changelyr_shp
        '   lh_cc				        GC_input_CC
        '   rastervaluefield            GC_FieldName
        '   changelayer                 GC_input_changelyr

        theApplication = GC_theApplication
        'add path to the script name
        theScript = GC_ScriptsFolder & "\" & GC_Scr_Scen1
        'there are currently 4 arguments
        theArguments = " " & GC_RootDir & " " & GC_input_changelyr_shp & " " & GC_input_CC & " " & GC_FieldName & " " & GC_input_changelyr

        ExecutePythonScript(theApplication, theScript, theArguments)
    End Sub
    Private Sub btn_RunScen1_Click(sender As Object, e As EventArgs) Handles btn_RunScen1.Click
        '   basefolder			        GC_RootDir
        '	changelayer.shp with path   GC_input_changelyr_shp
        '   lh_cc				        GC_input_CC
        '   rastervaluefield            GC_FieldName
        '   changelayer                 GC_input_changelyr
        btn_RunScen1.Enabled = False
        Dim s As String
        s = "" & vbCrLf
        If GC_RootDir_exists = False Then
            s = s & "raster folder" & vbCrLf
        End If
        If GC_input_changelyr_shp_exists = False Then '
            s = s & "change layer shapefile" & vbCrLf
        End If
        If GC_input_CC_exists = False Then '
            s = s & "vegetation raster" & vbCrLf
        End If
        If GC_FieldName_exists = False Then '
            s = s & "field name" & vbCrLf
        End If
        If txt_ChangerasterTab2.TextLength = 0 Then 'just look for a valid name for the output dataset
            s = s & "output change raster name" & vbCrLf
        End If
        If s <> ("" & vbCrLf) Then
            MessageBox.Show("please enter the following data:" & s, "Some inputs are missing", MessageBoxButtons.OK)
        Else
            If GC_input_changelyr_exists = False Then
                'run the script
                RunScriptScen1()
                chk_selS1.Checked = False
            Else
                Dim MB1 = MessageBox.Show("An output dataset with the same name already exists. Do you want to replace it?", "Output change raster (Scenario 1) already exists", MessageBoxButtons.OKCancel)
                If MB1 = Windows.Forms.DialogResult.OK Then
                    'run the script
                    RunScriptScen1()
                    chk_selS1.Checked = False
                End If
            End If
        End If
        'button enabled
        btn_RunScen1.Enabled = True
        'update existence
        If My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_changelyr) Then
            GC_input_changelyr_exists = True
            txt_ChangerasterTab2.ForeColor = Color.Black
        Else
            GC_input_changelyr_exists = False
            txt_ChangerasterTab2.ForeColor = Color.Red
        End If
    End Sub
    'runs Python Script 2a_ModifyVegetationLayer_Removal.py (GC_Scr_Scen2a) (4 arguments)
    Private Sub RunScriptScen2a()
        Dim theApplication As String
        Dim theScript As String
        Dim theArguments As String
        '   basefolder		GC_RootDir
        '   changelayer     GC_input_changelyr
        '   lh_cc			GC_input_CC
        '   lh_ccrem		GC_veg_removal

        theApplication = GC_theApplication
        'add path to the script name
        theScript = GC_ScriptsFolder & "\" & GC_Scr_Scen2a
        'there are currently 4 arguments
        theArguments = " " & GC_RootDir & " " & GC_input_changelyr & " " & GC_input_CC & " " & GC_veg_removal

        ExecutePythonScript(theApplication, theScript, theArguments)
    End Sub
    Private Sub btn_RunScen2a_Click(sender As Object, e As EventArgs) Handles btn_RunScen2a.Click
        '   basefolder		GC_RootDir
        '   changelayer     GC_input_changelyr
        '   lh_cc			GC_input_CC
        '   lh_ccrem		GC_veg_removal
        btn_RunScen2a.Enabled = False
        Dim s As String
        s = "" & vbCrLf
        If GC_RootDir_exists = False Then
            s = s & "raster folder" & vbCrLf
        End If
        If GC_input_changelyr_exists = False Then '
            s = s & "change raster" & vbCrLf
        End If
        If GC_input_CC_exists = False Then '
            s = s & "vegetation raster" & vbCrLf
        End If
        If txt_NewRasterRemv.TextLength = 0 Then 'just look for a valid name for the output dataset
            s = s & "output modified vegetation (removal) raster name" & vbCrLf
        End If
        If s <> ("" & vbCrLf) Then
            MessageBox.Show("please enter the following data:" & s, "Some inputs are missing", MessageBoxButtons.OK)
        Else
            If GC_veg_removal_exists = False Then
                'run the script
                RunScriptScen2a()
                chk_selS2a.Checked = False
            Else
                Dim MB1 = MessageBox.Show("An output dataset with the same name already exists. Do you want to replace it?", "Output modified vegetation (removal) raster (Scenario 2a) already exists", MessageBoxButtons.OKCancel)
                If MB1 = Windows.Forms.DialogResult.OK Then
                    'run the script
                    RunScriptScen2a()
                    chk_selS2a.Checked = False
                End If
            End If
        End If
        'button enabled
        btn_RunScen2a.Enabled = True
        'update existence
        If My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_veg_removal) Then
            GC_veg_removal_exists = True
            txt_NewRasterRemv.ForeColor = Color.Black
        Else
            GC_veg_removal_exists = False
            txt_NewRasterRemv.ForeColor = Color.Red
        End If
        'update veg list for combo box
        UpdateVegList(GC_veg_removal, GC_veg_removal_exists)

    End Sub
    'runs Python Script 2b_ModifyVegetationLayer_Addition.py (GC_Scr_Scen2b) (6 arguments)
    Private Sub RunScriptScen2b()
        Dim theApplication As String
        Dim theScript As String
        Dim theArguments As String
        '   basefolder			            GC_RootDir
        '   changelayer                     GC_input_changelyr
        '   lh_cc				            GC_input_CC
        '   luse				            GC_input_luse
        '   HydrologyValue1 (numeric, 10)   GC_HydrologyValue1
        '	lh_ccadd			            GC_veg_addition
        theApplication = GC_theApplication
        'add path to the script name
        theScript = GC_ScriptsFolder & "\" & GC_Scr_Scen2b
        'there are currently 4 arguments
        theArguments = " " & GC_RootDir & " " & GC_input_changelyr & " " & GC_input_CC & " " & GC_input_luse & " " & GC_HydrologyValue1 & " " & GC_veg_addition

        ExecutePythonScript(theApplication, theScript, theArguments)
    End Sub
    Private Sub btn_RunScen2b_Click(sender As Object, e As EventArgs) Handles btn_RunScen2b.Click
        '   basefolder			            GC_RootDir
        '   changelayer                     GC_input_changelyr
        '   lh_cc				            GC_input_CC
        '   luse				            GC_input_luse
        '   HydrologyValue1 (numeric, 10)   GC_HydrologyValue1
        '	lh_ccadd			            GC_veg_addition
        btn_RunScen2b.Enabled = False
        Dim s As String
        s = "" & vbCrLf
        If GC_RootDir_exists = False Then
            s = s & "raster folder" & vbCrLf
        End If
        If GC_input_changelyr_exists = False Then '
            s = s & "change raster" & vbCrLf
        End If
        If GC_input_CC_exists = False Then '
            s = s & "vegetation raster" & vbCrLf
        End If
        If GC_input_luse_exists = False Then '
            s = s & "land use raster" & vbCrLf
        End If
        If GC_HydrologyValue1_exists = False Then '
            s = s & "hydrology value" & vbCrLf
        End If

        If txt_NewRastAdd.TextLength = 0 Then 'just look for a valid name for the output dataset
            s = s & "output modified vegetation (addition) raster name" & vbCrLf
        End If
        If s <> ("" & vbCrLf) Then
            MessageBox.Show("please enter the following data:" & s, "Some inputs are missing", MessageBoxButtons.OK)
        Else
            If GC_veg_addition_exists = False Then
                'run the script
                RunScriptScen2b()
                chk_sel2b.Checked = False
            Else
                Dim MB1 = MessageBox.Show("An output dataset with the same name already exists. Do you want to replace it?", "Output modified vegetation (addition) raster (Scenario 2b) already exists", MessageBoxButtons.OKCancel)
                If MB1 = Windows.Forms.DialogResult.OK Then
                    'run the script
                    RunScriptScen2b()
                    chk_sel2b.Checked = False
                End If
            End If
        End If
        'button enabled
        btn_RunScen2b.Enabled = True
        'update existence
        If My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_veg_addition) Then
            GC_veg_addition_exists = True
            txt_NewRastAdd.ForeColor = Color.Black
        Else
            GC_veg_addition_exists = False
            txt_NewRastAdd.ForeColor = Color.Red
        End If
        'update veg list for combo box
        UpdateVegList(GC_veg_addition, GC_veg_addition_exists)

    End Sub
    'runs Python Script 3_CreateGapCrossingLayer.py (GC_Scr_Scen3) (4 arguments)
    Private Sub RunScriptScen3()
        Dim theApplication As String
        Dim theScript As String
        Dim theArguments As String
        '   basefolder			           GC_RootDir
        '   lh_ccrem			           GC_veg_removal
        '   gap_crossadd                   GC_gapcross_add
        '   InputCellMultiplier2 (numeric) GC_CellMultiplier2
        theApplication = GC_theApplication
        'add path to the script name
        theScript = GC_ScriptsFolder & "\" & GC_Scr_Scen3
        'there are currently 4 arguments
        theArguments = " " & GC_RootDir & " " & GC_veg_removal & " " & GC_gapcross_add & " " & GC_CellMultiplier2

        ExecutePythonScript(theApplication, theScript, theArguments)
    End Sub
    Private Sub btn_RunScen3_Click(sender As Object, e As EventArgs) Handles btn_RunScen3.Click
        '   basefolder			           GC_RootDir
        '   lh_ccrem			           GC_veg_removal
        '   gap_crossadd                   GC_gapcross_add
        '   InputCellMultiplier2 (numeric) GC_CellMultiplier2
        btn_RunScen3.Enabled = False
        Dim s As String
        s = "" & vbCrLf
        If GC_RootDir_exists = False Then
            s = s & "raster folder" & vbCrLf
        End If
        If GC_veg_removal_exists = False Then '
            s = s & "modified vegetation (removal) raster" & vbCrLf
        End If
        If GC_CellMultiplier2_exists = False Then '
            s = s & "cell multiplier" & vbCrLf
        End If

        If txt_GapcrossTab2.TextLength = 0 Then 'just look for a valid name for the output dataset
            s = s & "output gap cross (addition) raster name" & vbCrLf
        End If
        If s <> ("" & vbCrLf) Then
            MessageBox.Show("please enter the following data:" & s, "Some inputs are missing", MessageBoxButtons.OK)
        Else
            If GC_gapcross_add_exists = False Then
                'run the script
                RunScriptScen3()
                chk_sel3.Checked = False
            Else
                Dim MB1 = MessageBox.Show("An output dataset with the same name already exists. Do you want to replace it?", "Output  gapp cross (addition) raster (Scenario 2b) already exists", MessageBoxButtons.OKCancel)
                If MB1 = Windows.Forms.DialogResult.OK Then
                    'run the script
                    RunScriptScen3()
                    chk_sel3.Checked = False
                End If
            End If
        End If
        'button enabled
        btn_RunScen3.Enabled = True
        'update existence
        If My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_gapcross_add) Then
            GC_gapcross_add_exists = True
            txt_GapcrossTab2.ForeColor = Color.Black
        Else
            GC_gapcross_add_exists = False
            txt_GapcrossTab2.ForeColor = Color.Red
        End If
        'update gapcross list for combo box
        If Not GC_gapcross_add = "" Then
            UpdateGapcrossList(GC_gapcross_add, GC_gapcross_add_exists)
        End If


    End Sub
    'runsPython Script 4_ModifyLuseLayer_AddInfra.py (GC_Scr_Scen4) (5 arguments)
    Private Sub RunScriptScen4()
        Dim theApplication As String
        Dim theScript As String
        Dim theArguments As String
        '   basefolder		               GC_RootDir
        '   changelayer                    GC_input_changelyr
        '   luse_add                       GC_luse_add
        '   HydrologyValue2 (numeric, 30)  GC_HydrologyValue2 (passed as string)
        '   luse				           GC_input_luse
        theApplication = GC_theApplication
        'add path to the script name
        theScript = GC_ScriptsFolder & "\" & GC_Scr_Scen4
        'there are currently 4 arguments
        theArguments = " " & GC_RootDir & " " & GC_input_changelyr & " " & GC_luse_add & " " & GC_HydrologyValue2 & " " & GC_input_luse

        ExecutePythonScript(theApplication, theScript, theArguments)
    End Sub
    Private Sub btn_RunScen4_Click(sender As Object, e As EventArgs) Handles btn_RunScen4.Click
        '   basefolder		               GC_RootDir
        '   changelayer                    GC_input_changelyr
        '   luse_add                       GC_luse_add
        '   HydrologyValue2 (numeric, 30)  GC_HydrologyValue2 (passed as string)
        '   luse				           GC_input_luse
        btn_RunScen4.Enabled = False
        Dim s As String
        s = "" & vbCrLf
        If GC_RootDir_exists = False Then
            s = s & "raster folder" & vbCrLf
        End If
        If GC_input_changelyr_exists = False Then '
            s = s & "change raster" & vbCrLf
        End If
        If GC_input_luse_exists = False Then '
            s = s & "land use raster" & vbCrLf
        End If
        If GC_HydrologyValue2_exists = False Then '
            s = s & "hydrology value" & vbCrLf
        End If

        If txt_infrastructure.TextLength = 0 Then 'just look for a valid name for the output dataset
            s = s & "output modified land use (infrastructure) raster name" & vbCrLf
        End If
        If s <> ("" & vbCrLf) Then
            MessageBox.Show("please enter the following data:" & s, "Some inputs are missing", MessageBoxButtons.OK)
        Else
            If GC_luse_add_exists = False Then
                'run the script
                RunScriptScen4()
                chk_selS4.Checked = False
            Else
                Dim MB1 = MessageBox.Show("An output dataset with the same name already exists. Do you want to replace it?", "Output modified land use (infrastructure) raster (Scenario 2b) already exists", MessageBoxButtons.OKCancel)
                If MB1 = Windows.Forms.DialogResult.OK Then
                    'run the script
                    RunScriptScen4()
                    chk_selS4.Checked = False
                End If
            End If
        End If
        'button enabled
        btn_RunScen4.Enabled = True
        'update existence
        If My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_luse_add) Then
            GC_luse_add_exists = True
            txt_infrastructure.ForeColor = Color.Black
        Else
            GC_luse_add_exists = False
            txt_infrastructure.ForeColor = Color.Red
        End If
        'update landuse list for combo box
        If Not GC_luse_add = "" Then
            UpdateLanduseList(GC_luse_add, GC_luse_add_exists)
        End If

    End Sub

    '

    'entering Python Application text box - Tab 5
    Private Sub txt_ArcPythonApp_Enter(sender As Object, e As EventArgs) Handles txt_ArcPythonApp.Enter
        txt_ArcPythonApp.ForeColor = Color.Blue
    End Sub
    'leaving Python Application text box - Tab 5
    Private Sub txt_ArcPythonApp_Leave(sender As Object, e As EventArgs) Handles txt_ArcPythonApp.Leave
        Try
            GC_theApplication = txt_ArcPythonApp.Text
            txt_ArcPythonApp.ForeColor = Color.Black

        Catch ex As Exception
            MsgBox("Please enter Python application name with path or just python. Include quotes if path contains spaces.")
        End Try
    End Sub
    'entering GAP_CLoSR Script text box -tab 5
    Private Sub txt_GC_ScriptName_Enter(sender As Object, e As EventArgs) Handles txt_GC_ScriptName.Enter
        txt_GC_ScriptName.ForeColor = Color.Blue
    End Sub
    'leaving GAP_CLoSR Script text box -tab 5
    Private Sub txt_GC_ScriptName_Leave(sender As Object, e As EventArgs) Handles txt_GC_ScriptName.Leave
        Try
            GC_theScript = txt_GC_ScriptName.Text
            txt_GC_ScriptName.ForeColor = Color.Black

        Catch ex As Exception
            MsgBox("Please enter Python script name.")
        End Try
    End Sub
    'ArcGIS Python file and path browser button - Tab 5
    Private Sub btn_BrowseArcPyPath_Click(sender As Object, e As EventArgs) Handles btn_BrowseArcPyPath.Click
        Dim tempText2 As String = txt_ArcPythonApp.Text

        Try
            Dim dlga = dlg_FindArcPyPath.ShowDialog()
            If dlga = Windows.Forms.DialogResult.OK Then
                txt_ArcPythonApp.Text = dlg_FindArcPyPath.FileName
                GC_theApplication = txt_ArcPythonApp.Text
            ElseIf dlga = Windows.Forms.DialogResult.Cancel Then
                txt_ArcPythonApp.Text = tempText2
            End If
        Catch ex As Exception
            MsgBox("Error in selecting python.exe application")
        End Try
    End Sub
    'saves the Python Configuration settings -Tab 5
    Private Sub btn_SavePyExePth_Click(sender As Object, e As EventArgs) Handles btn_SavePyExePth.Click
        Try
            Dim sw As New IO.StreamWriter(PPath, False) 'overwrite
            sw.WriteLine("ArcGISPythonApp=" & GC_theApplication) '
            sw.WriteLine("ScriptsFolder=" & GC_ScriptsFolder)
            sw.WriteLine("Scr_DefL=" & GC_Scr_DefL)
            sw.WriteLine("Scr_DefG=" & GC_Scr_DefGC)
            sw.WriteLine("Scr_DefO=" & GC_Scr_DefO)
            sw.WriteLine("Scr_Scen1=" & GC_Scr_Scen1)
            sw.WriteLine("Scr_Scen2a=" & GC_Scr_Scen2a)
            sw.WriteLine("Scr_Scen2b=" & GC_Scr_Scen2b)
            sw.WriteLine("Scr_Scen3=" & GC_Scr_Scen3)
            sw.WriteLine("Scr_Scen4=" & GC_Scr_Scen4)
            sw.WriteLine("GAP_CLoSR.pyScript=" & GC_theScript)
            sw.Close()
            GC_PyAppSaved = True
        Catch ex As Exception
            MsgBox("Error while saving config file")
        End Try
    End Sub
    'loads the Python Configuration settings -Tab 5
    Private Sub btn_LoadPyExePth_Click(sender As Object, e As EventArgs) Handles btn_LoadPyExePth.Click
        Dim fileExists As Boolean

        fileExists = My.Computer.FileSystem.FileExists(PPath)
        If fileExists = True Then
            Try
                'there are currently ONE config variable, python exe, to load
                Dim swrd As New IO.StreamReader(PPath)
                Dim Linedata As String
                Dim ConfigReadError As String = ""
                'read variables text from setting file, display them in the text boxes and convert to variables

                'ArcGISPythonApp="C:\Python27\ArcGIS10.2\python.exe"
                'ScriptsFolder=C:\Users\mj_lacey\Documents\Visual Studio 2012\Projects\TestApp_GAP_CLoSR_Dev1\TestApp_GAP_CLoSR_Dev1\bin\Debug\GAP_CLoSR_Code
                'Scr_DefL = Convert_luseToRaster.py
                'Scr_DefGC = CreateGapCrossingLayer.py
                'Scr_DefO = CreateGapCrossingLayerOLD.py
                'Scr_Scen1=1_CreateRasterChangeLayer.py
                'Scr_Scen2a=2a_ModifyVegetationLayer_Removal.py
                'Scr_Scen2b=2b_ModifyVegetationLayer_Addition.py
                'Scr_Scen3=3_CreateGapCrossingLayer.py
                'Scr_Scen4=4_ModifyLuseLayer_AddInfra.py

                'config line 1
                Linedata = swrd.ReadLine() 'python application
                If Linedata.Split(CChar("=")).First() = "ArcGISPythonApp" Then
                    txt_ArcPythonApp.Text = Linedata.Split(CChar("=")).Last()
                    GC_theApplication = txt_ArcPythonApp.Text
                Else
                    ConfigReadError = "ArcGISPythonApp"
                End If
                'config line 2
                Linedata = swrd.ReadLine() 'scripts folder. This path needs to be added to the script names.
                If Linedata.Split(CChar("=")).First() = "ScriptsFolder" Then
                    txt_ScriptsFolder.Text = Linedata.Split(CChar("=")).Last()
                    GC_ScriptsFolder = txt_ScriptsFolder.Text
                Else
                    ConfigReadError = "ScriptsFolder"
                End If
                'config line 3
                Linedata = swrd.ReadLine()  ' default luse script
                If Linedata.Split(CChar("=")).First() = "Scr_DefL" Then
                    txt_ScriptLuseToRaster.Text = Linedata.Split(CChar("=")).Last()
                    GC_Scr_DefL = txt_ScriptLuseToRaster.Text
                Else
                    ConfigReadError = "Scr_DefL"
                End If
                'config line 4
                Linedata = swrd.ReadLine() 'default gap cross script
                If Linedata.Split(CChar("=")).First() = "Scr_DefG" Then
                    txt_ScriptCreateGapCross.Text = Linedata.Split(CChar("=")).Last()
                    GC_Scr_DefGC = txt_ScriptCreateGapCross.Text
                Else
                    ConfigReadError = "Scr_DefG"
                End If
                'config line 5
                Linedata = swrd.ReadLine()  'default gap cross script old
                If Linedata.Split(CChar("=")).First() = "Scr_DefO" Then
                    txt_ScriptcreateGC_old.Text = Linedata.Split(CChar("=")).Last()
                    GC_Scr_DefO = txt_ScriptcreateGC_old.Text
                Else
                    ConfigReadError = "Scr_DefO"
                End If
                'config line 6
                Linedata = swrd.ReadLine()  'scenario 1 script
                If Linedata.Split(CChar("=")).First() = "Scr_Scen1" Then
                    txt_ScriptScenario1.Text = Linedata.Split(CChar("=")).Last()
                    GC_Scr_Scen1 = txt_ScriptScenario1.Text
                Else
                    ConfigReadError = "Scr_Scen1"
                End If
                'config line 7
                Linedata = swrd.ReadLine()  'scenario 2a script
                If Linedata.Split(CChar("=")).First() = "Scr_Scen2a" Then
                    txt_ScriptScenario2a.Text = Linedata.Split(CChar("=")).Last()
                    GC_Scr_Scen2a = txt_ScriptScenario2a.Text
                Else
                    ConfigReadError = "Scr_Scen2a"
                End If
                'config line 8
                Linedata = swrd.ReadLine()  'scenario 2b script
                If Linedata.Split(CChar("=")).First() = "Scr_Scen2b" Then
                    txt_ScriptScenario2b.Text = Linedata.Split(CChar("=")).Last()
                    GC_Scr_Scen2b = txt_ScriptScenario2b.Text
                Else
                    ConfigReadError = "Scr_Scen2b"
                End If
                'config line 9
                Linedata = swrd.ReadLine()  'scenario 3 script
                If Linedata.Split(CChar("=")).First() = "Scr_Scen3" Then
                    txt_ScriptScenario3.Text = Linedata.Split(CChar("=")).Last()
                    GC_Scr_Scen3 = txt_ScriptScenario3.Text
                Else
                    ConfigReadError = "Scr_Scen3"
                End If
                'config line 10
                Linedata = swrd.ReadLine()  'scenario 4 script
                If Linedata.Split(CChar("=")).First() = "Scr_Scen4" Then
                    txt_scriptScenario4.Text = Linedata.Split(CChar("=")).Last()
                    GC_Scr_Scen4 = txt_scriptScenario4.Text
                Else
                    ConfigReadError = "Scr_Scen4"
                End If
                'config line 11
                Linedata = swrd.ReadLine()  'GAP_CLoSR script
                If Linedata.Split(CChar("=")).First() = "GAP_CLoSR.pyScript" Then
                    txt_GC_ScriptName.Text = Linedata.Split(CChar("=")).Last()
                    GC_theScript = txt_GC_ScriptName.Text
                Else
                    ConfigReadError = "GAP_CLoSR.pyScript"
                End If


                'close the settings file
                swrd.Close()
                'flag as python exe application selected
                GC_PyAppSelected = True
            Catch ex As Exception
                MsgBox("There was an error in loading the configs file.")
            End Try
        Else
            txt_ArcPythonApp.Text = "python"
            GC_theApplication = "python"
            MsgBox("A config. file 'Configs.txt' was not be found in Configs folder")
        End If

    End Sub
    'select the configs tab by clicking on it - Tab 5
    Private Sub tb_Config_Click(sender As Object, e As EventArgs) Handles tb_Config.Click
        tb_Config.Select()
    End Sub
    'clear error output - Tab 4
    Private Sub btn_ClearErrorOutput_Click(sender As Object, e As EventArgs) Handles btn_ClearErrorOutput.Click
        txt_PythonError.Text = ""
    End Sub
    'clear script output - Tab 4
    Private Sub btn_ClearScriptOutput_Click(sender As Object, e As EventArgs) Handles btn_ClearScriptOutput.Click
        txt_PythonOutput.Text = ""
    End Sub

    '
    'enter text box - tab 1
    Private Sub txt_LanduseShp_Enter(sender As Object, e As EventArgs) Handles txt_LanduseShp.Enter
        txt_LanduseShp.ForeColor = Color.Blue
    End Sub
    'enter text box - tab 1
    Private Sub txt_InputF_Enter(sender As Object, e As EventArgs) Handles txt_InputF.Enter
        txt_InputF.ForeColor = Color.Blue
    End Sub
    'enter text box - tab 1
    Private Sub txt_inplh_cc1_Enter(sender As Object, e As EventArgs) Handles txt_inplh_cc1.Enter
        txt_inplh_cc1.ForeColor = Color.Blue
    End Sub
    'enter text box - tab 1
    Private Sub txt_luse1_Enter(sender As Object, e As EventArgs) Handles txt_luse1.Enter
        txt_luse1.ForeColor = Color.Blue
    End Sub
    'enter text box - tab 1
    Private Sub txt_gap_cross1_Enter(sender As Object, e As EventArgs) Handles txt_gap_cross1.Enter
        txt_gap_cross1.ForeColor = Color.Blue
    End Sub
    'enter text box - tab 1
    Private Sub txt_gapcrossOld_Enter(sender As Object, e As EventArgs) Handles txt_gapcrossOld.Enter
        txt_gapcrossOld.ForeColor = Color.Blue
    End Sub
    'enter text box - tab 1
    Private Sub txt_RasterValueField_Enter(sender As Object, e As EventArgs) Handles txt_RasterValueField.Enter
        txt_RasterValueField.ForeColor = Color.Blue
    End Sub
    'enter text box - tab 1
    Private Sub txt_MaxDist1_Enter(sender As Object, e As EventArgs) Handles txt_MaxDist1.Enter
        txt_MaxDist1.ForeColor = Color.Blue
    End Sub
    'leave text box - tab 1
    Private Sub txt_LanduseShp_Leave(sender As Object, e As EventArgs) Handles txt_LanduseShp.Leave
        Try
            GC_input_luse_shp = txt_LanduseShp.Text
            If (GC_input_luse_shp <> "") And My.Computer.FileSystem.FileExists(GC_input_luse_shp) Then
                GC_input_luse_shp_exists = True
                txt_LanduseShp.ForeColor = Color.Black
            Else
                GC_input_luse_shp_exists = False
                txt_LanduseShp.ForeColor = Color.Red
            End If

        Catch ex As Exception
            MsgBox("Error in selecting land use shapefile name.")
        End Try
    End Sub
    'leave text box - tab 1 '' note: updates GC_RootDir
    Private Sub txt_InputF_Leave(sender As Object, e As EventArgs) Handles txt_InputF.Leave
        Try
            GC_RootDir = txt_InputF.Text
            txt_rasterFolderTab2.Text = txt_InputF.Text 'update to tab 2
            txt_SelRootDir.Text = txt_InputF.Text 'update to tab 3
            If (GC_RootDir <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir) Then
                GC_RootDir_exists = True
                txt_InputF.ForeColor = Color.Black
                txt_rasterFolderTab2.ForeColor = Color.Black
                txt_SelRootDir.ForeColor = Color.Black
            Else
                GC_RootDir_exists = False
                txt_InputF.ForeColor = Color.Red
                txt_rasterFolderTab2.ForeColor = Color.Red
                txt_SelRootDir.ForeColor = Color.Red
            End If
            'update raster existence, colors and combo box lists
            RasterFolderLeave()

        Catch ex As Exception
            MsgBox("Error in setting raster folder.")
        End Try
    End Sub
    'leave text box - tab 1 '' note: updates GC_input_cc (lh_cc)
    Private Sub txt_inplh_cc1_Leave(sender As Object, e As EventArgs) Handles txt_inplh_cc1.Leave
        Try
            GC_input_CC = txt_inplh_cc1.Text
            'copy to other tabs
            txt_habitatTab2.Text = txt_inplh_cc1.Text 'update to tab 2 (lh_cc)
            'update text colour on all tabs if folder exists/does not exist
            If (GC_input_CC <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_CC) Then
                GC_input_CC_exists = True
                txt_inplh_cc1.ForeColor = Color.Black
                txt_habitatTab2.ForeColor = Color.Black
            Else
                GC_input_CC_exists = False
                txt_inplh_cc1.ForeColor = Color.Red
                txt_habitatTab2.ForeColor = Color.Red
            End If
            'update veg list for combo box
            If Not GC_input_CC = "" Then
                UpdateVegList(GC_input_CC, GC_input_CC_exists)
            End If

        Catch ex As Exception
            MsgBox("Error in entering habitat raster name.")
        End Try
    End Sub
    'leave text box - tab 1 '' note: updates GC_input_luse
    Private Sub txt_luse1_Leave(sender As Object, e As EventArgs) Handles txt_luse1.Leave
        Try
            GC_input_luse = txt_luse1.Text
            'copy to other tabs
            txt_landuseTab2.Text = txt_luse1.Text 'update to tab 1 (luse)
            'update text colour on all tabs if folder exists/does not exist
            If (GC_input_luse <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_luse) Then
                GC_input_luse_exists = True
                txt_landuseTab2.ForeColor = Color.Black
                txt_luse1.ForeColor = Color.Black
            Else
                GC_input_luse_exists = False
                txt_landuseTab2.ForeColor = Color.Red
                txt_luse1.ForeColor = Color.Red
            End If
            'update landuse list for combo box
            If Not GC_input_luse = "" Then
                UpdateLanduseList(GC_input_luse, GC_input_luse_exists)
            End If

        Catch ex As Exception
            MsgBox("Error in entering land use raster name.")
        End Try
    End Sub
    'leave text box - tab 1 '' note: updates GC_input_gap_cross
    Private Sub txt_gap_cross1_Leave(sender As Object, e As EventArgs) Handles txt_gap_cross1.Leave
        Try
            GC_input_gap_cross = txt_gap_cross1.Text
            If (GC_input_gap_cross <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_gap_cross) Then
                GC_input_gap_cross_exists = True
                txt_gap_cross1.ForeColor = Color.Black
            Else
                GC_input_gap_cross_exists = False
                txt_gap_cross1.ForeColor = Color.Red
            End If
            'update gapcross list for combo box
            If Not GC_input_gap_cross = "" Then
                UpdateGapcrossList(GC_input_gap_cross, GC_input_gap_cross_exists)
            End If

        Catch ex As Exception
            MsgBox("error in entering gappcross raster name.")
        End Try
    End Sub
    'leave text box - tab 1
    Private Sub txt_gapcrossOld_Leave(sender As Object, e As EventArgs) Handles txt_gapcrossOld.Leave
        Try
            GC_input_gap_crossO = txt_gapcrossOld.Text
            If (GC_input_gap_crossO <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_gap_crossO) Then
                GC_input_gap_crossO_exists = True
                txt_gapcrossOld.ForeColor = Color.Black
            Else
                GC_input_gap_crossO_exists = False
                txt_gapcrossOld.ForeColor = Color.Red
            End If
            'update gapcross list for combo box
            If Not GC_input_gap_crossO = "" Then
                UpdateGapcrossList(GC_input_gap_crossO, GC_input_gap_crossO_exists)
            End If

        Catch ex As Exception
            MsgBox("Error in entering gapcross (old method) raster name.")
        End Try
    End Sub
    'leave text box - tab 1
    Private Sub txt_RasterValueField_Leave(sender As Object, e As EventArgs) Handles txt_RasterValueField.Leave
        Try
            GC_conv_luse_RVfield = txt_RasterValueField.Text
            If txt_RasterValueField.TextLength > 0 Then
                GC_conv_luse_RVfield_exists = True
                txt_RasterValueField.ForeColor = Color.Black
            Else
                GC_conv_luse_RVfield_exists = False
                txt_RasterValueField.ForeColor = Color.Red 'if length is zero then wont be seen anyway but just keeping code consistent
            End If

        Catch ex As Exception
            MsgBox("Error in selecting raster value field.")
        End Try
    End Sub
    'enter text box - tab 1
    Private Sub txt_inpMultiTab1_Enter(sender As Object, e As EventArgs) Handles txt_inpMultiTab1.Enter
        txt_inpMultiTab1.ForeColor = Color.Blue
    End Sub
    'leave text box - tab 1 numerical
    Private Sub txt_inpMultiTab1_Leave(sender As Object, e As EventArgs) Handles txt_inpMultiTab1.Leave
        Try
            If txt_inpMultiTab1.Text <> Nothing Then
                GC_CellMultiplier = CDbl(txt_inpMultiTab1.Text)
                GC_CellMultiplier_exists = True
                txt_inpMultiTab1.ForeColor = Color.Black
            Else
                GC_CellMultiplier_exists = False
                txt_inpMultiTab1.ForeColor = Color.Red 'if is Nothing then wont be seen anyway but just keeping code consistent
            End If

        Catch ex As Exception
            MsgBox("The value entered for cell multiplier must be a number")
            txt_inpMultiTab1.Select()
        End Try
    End Sub
    'leave text box - tab 1 numerical
    Private Sub txt_MaxDist1_Leave(sender As Object, e As EventArgs) Handles txt_MaxDist1.Leave
        Try
            If txt_MaxDist1.Text <> Nothing Then
                GC_Max_dist1 = CDbl(txt_MaxDist1.Text)
                GC_Max_dist1_exists = True
                txt_MaxDist1.ForeColor = Color.Black
            Else
                GC_Max_dist1_exists = False
                txt_MaxDist1.ForeColor = Color.Red 'if is Nothing then wont be seen anyway but just keeping code consistent
            End If

        Catch ex As Exception
            MsgBox("The value entered must be a number.")
            txt_MaxDist1.Select()
        End Try
    End Sub


    '
    'select button land use shapefile - tab 1
    Private Sub btn_LanduseShp_Click(sender As Object, e As EventArgs) Handles btn_LanduseShp.Click
        Dim temp5 As String = txt_LanduseShp.Text
        Try
            Dim dlgb = dlg_OpenShapefile.ShowDialog() ' find file dialog to find or set scenario file name
            dlg_OpenShapefile.Title = "Select land use shapefile"
            If dlgb = Windows.Forms.DialogResult.OK Then
                txt_LanduseShp.Text = dlg_OpenShapefile.FileName
                GC_input_luse_shp = txt_LanduseShp.Text
                If My.Computer.FileSystem.FileExists(GC_input_luse_shp) Then
                    GC_input_luse_shp_exists = True
                    txt_LanduseShp.ForeColor = Color.Black
                Else
                    GC_input_luse_shp_exists = False
                    txt_LanduseShp.ForeColor = Color.Red
                End If
                'save the path to this folder
                GC_LastFolder = IO.Path.GetDirectoryName(GC_input_luse_shp)

            ElseIf dlgb = Windows.Forms.DialogResult.Cancel Then
                txt_LanduseShp.Text = temp5
            End If
        Catch ex As Exception
            MsgBox("Error in selecting land use shapefile") ': {0}", ex.ToString())
        End Try
    End Sub
    'select button input folder - tab 1 '' note: updates GC_RootDir
    Private Sub btn_InputF_Click(sender As Object, e As EventArgs) Handles btn_InputF.Click
        Dim tempText As String = txt_InputF.Text

        Try
            'sets the initial selected directory to the luse.shp path if that has been previously selected
            dlg_GetRootFolder.SelectedPath = GC_LastFolder

            'end testing
            Dim dlgc = dlg_GetRootFolder.ShowDialog()
            If dlgc = Windows.Forms.DialogResult.OK Then
                txt_InputF.Text = dlg_GetRootFolder.SelectedPath
                GC_RootDir = txt_InputF.Text
                GC_LastFolder = dlg_GetRootFolder.SelectedPath
                'copy to other tabs
                txt_rasterFolderTab2.Text = txt_InputF.Text 'update to tab 2
                txt_SelRootDir.Text = txt_InputF.Text 'update to tab 3
                'update text colour on all tabs if folder exists/does not exist
                If My.Computer.FileSystem.DirectoryExists(GC_RootDir) Then
                    GC_RootDir_exists = True
                    txt_InputF.ForeColor = Color.Black
                    txt_rasterFolderTab2.ForeColor = Color.Black
                    txt_SelRootDir.ForeColor = Color.Black
                Else
                    GC_RootDir_exists = False
                    txt_InputF.ForeColor = Color.Red
                    txt_rasterFolderTab2.ForeColor = Color.Red
                    txt_SelRootDir.ForeColor = Color.Red
                End If
                'update raster existence, colors and combo box lists
                RasterFolderLeave()

            ElseIf dlgc = Windows.Forms.DialogResult.Cancel Then
                txt_InputF.Text = tempText
            End If
        Catch ex As Exception
            MsgBox("Error in selecting the raster folder") ': {0}", ex.ToString())
        End Try
    End Sub
    'select tab 1 with click
    Private Sub tb_1_Click(sender As Object, e As EventArgs) Handles tb_1.Click
        tb_1.Select()
    End Sub
    'select tab 2 with click
    Private Sub tb_2_Click(sender As Object, e As EventArgs) Handles tb_2.Click
        tb_2.Select()
    End Sub
    'select tab 4 with click
    Private Sub tb_4_Click(sender As Object, e As EventArgs) Handles tb_4.Click
        tb_4.Select()
    End Sub
    'About box
    Private Sub btn_About_Click(sender As Object, e As EventArgs) Handles btn_About.Click
        Dim About_Text As String = "This application is an implementation of GAP_CLoSR tools and methods " & vbCrLf
        About_Text = About_Text & "developed by Dr Alex Lechner (alexmarklechner@yahoo.com.au) as a part " & vbCrLf
        About_Text = About_Text & "of the Australian Government's National Environmental Research Program " & vbCrLf
        About_Text = About_Text & "(NERP) Landscapes and Policy hub." & vbCrLf
        About_Text = About_Text & " " & vbCrLf
        About_Text = About_Text & "This GUI was developed by Dr Michael Lacey (Michael.Lacey@utas.edu.au)," & vbCrLf
        About_Text = About_Text & "in association with Alex Lechner and the NERP Landscapes and Policy" & vbCrLf
        About_Text = About_Text & "hub and is licensed under the Creative Commons " & vbCrLf
        About_Text = About_Text & "AttributionNonCommercial-ShareAlike 3.0 Australia (CC BY-NC-SA 3.0 AU)" & vbCrLf
        About_Text = About_Text & "license . To view a copy of this licence, " & vbCrLf
        About_Text = About_Text & "visit https://creativecommons.org/licenses/by-nc-sa/3.0/au/)." & vbCrLf
        About_Text = About_Text & " " & vbCrLf
        About_Text = About_Text & My.Application.Info.ProductName & vbCrLf
        About_Text = About_Text & String.Format("Version {0}", My.Application.Info.Version.ToString) & vbCrLf
        About_Text = About_Text & My.Application.Info.Copyright & vbCrLf
        About_Text = About_Text & My.Application.Info.CompanyName & vbCrLf
        Dim MB_About = MessageBox.Show(About_Text, "About GAP_CLoSR_GUI", MessageBoxButtons.OK)

    End Sub

    'button - select change layer shapefile - tab 2
    Private Sub btn_browseChngShpTab2_Click(sender As Object, e As EventArgs) Handles btn_browseChngShpTab2.Click
        Dim temp5 As String = txt_ChngLyrShpTab2.Text
        Try
            Dim dlgb = dlg_OpenShapefile.ShowDialog() ' find file dialog to find or set scenario file name
            dlg_OpenShapefile.Title = "Select change layer shapefile"
            If dlgb = Windows.Forms.DialogResult.OK Then
                txt_ChngLyrShpTab2.Text = dlg_OpenShapefile.FileName
                GC_input_changelyr_shp = txt_ChngLyrShpTab2.Text
                If My.Computer.FileSystem.FileExists(GC_input_changelyr_shp) Then
                    GC_input_changelyr_shp_exists = True
                    txt_ChngLyrShpTab2.ForeColor = Color.Black
                Else
                    GC_input_changelyr_shp_exists = False
                    txt_ChngLyrShpTab2.ForeColor = Color.Red
                End If

            ElseIf dlgb = Windows.Forms.DialogResult.Cancel Then
                txt_ChngLyrShpTab2.Text = temp5
            End If
        Catch ex As Exception
            MsgBox("error in selecting shapefile")
        End Try
    End Sub
    'button - select raster folder - tab 2
    Private Sub btn_browse_RasFolderTab2_Click(sender As Object, e As EventArgs) Handles btn_browse_RasFolderTab2.Click
        Dim tempText As String = txt_rasterFolderTab2.Text

        'sets the initial selected directory to the luse.shp path if that has been previously selected
        dlg_GetRootFolder.SelectedPath = GC_LastFolder

        Try
            Dim dlgc = dlg_GetRootFolder.ShowDialog()
            If dlgc = Windows.Forms.DialogResult.OK Then
                txt_rasterFolderTab2.Text = dlg_GetRootFolder.SelectedPath
                GC_RootDir = txt_rasterFolderTab2.Text
                GC_LastFolder = dlg_GetRootFolder.SelectedPath
                'copy to other tabs
                txt_SelRootDir.Text = txt_rasterFolderTab2.Text 'update to tab 3
                txt_InputF.Text = txt_rasterFolderTab2.Text 'update to tab 1
                'update text colour on all tabs if folder exists/does not exist
                If My.Computer.FileSystem.DirectoryExists(GC_RootDir) Then
                    GC_RootDir_exists = True
                    txt_InputF.ForeColor = Color.Black
                    txt_rasterFolderTab2.ForeColor = Color.Black
                    txt_SelRootDir.ForeColor = Color.Black
                Else
                    GC_RootDir_exists = False
                    txt_InputF.ForeColor = Color.Red
                    txt_rasterFolderTab2.ForeColor = Color.Red
                    txt_SelRootDir.ForeColor = Color.Red
                End If

            ElseIf dlgc = Windows.Forms.DialogResult.Cancel Then
                txt_rasterFolderTab2.Text = tempText
            End If
        Catch ex As Exception
            MsgBox("Please enter or select the path to the raster folder")
        End Try
    End Sub

    '
    Private Sub txt_ChngLyrShpTab2_Enter(sender As Object, e As EventArgs) Handles txt_ChngLyrShpTab2.Enter
        txt_ChngLyrShpTab2.ForeColor = Color.Blue
    End Sub

    Private Sub txt_rasterFolderTab2_Enter(sender As Object, e As EventArgs) Handles txt_rasterFolderTab2.Enter
        txt_rasterFolderTab2.ForeColor = Color.Blue
    End Sub

    Private Sub txt_habitatTab2_Enter(sender As Object, e As EventArgs) Handles txt_habitatTab2.Enter
        txt_habitatTab2.ForeColor = Color.Blue
    End Sub

    Private Sub txt_landuseTab2_Enter(sender As Object, e As EventArgs) Handles txt_landuseTab2.Enter
        txt_landuseTab2.ForeColor = Color.Blue
    End Sub

    Private Sub txt_ChangerasterTab2_Enter(sender As Object, e As EventArgs) Handles txt_ChangerasterTab2.Enter
        txt_ChangerasterTab2.ForeColor = Color.Blue
    End Sub

    Private Sub txt_NewRasterRemv_Enter(sender As Object, e As EventArgs) Handles txt_NewRasterRemv.Enter
        txt_NewRasterRemv.ForeColor = Color.Blue
    End Sub

    Private Sub txt_NewRastAdd_Enter(sender As Object, e As EventArgs) Handles txt_NewRastAdd.Enter
        txt_NewRastAdd.ForeColor = Color.Blue
    End Sub

    Private Sub txt_GapcrossTab2_Enter(sender As Object, e As EventArgs) Handles txt_GapcrossTab2.Enter
        txt_GapcrossTab2.ForeColor = Color.Blue
    End Sub

    Private Sub txt_infrastructure_Enter(sender As Object, e As EventArgs) Handles txt_infrastructure.Enter
        txt_infrastructure.ForeColor = Color.Blue
    End Sub

    Private Sub txt_RasValFldTab2_Enter(sender As Object, e As EventArgs) Handles txt_RasValFldTab2.Enter
        txt_RasValFldTab2.ForeColor = Color.Blue
    End Sub

    Private Sub txt_HydrolVal1_Enter(sender As Object, e As EventArgs) Handles txt_HydrolVal1.Enter
        txt_HydrolVal1.ForeColor = Color.Blue
    End Sub

    Private Sub txt_CellMultip2_Enter(sender As Object, e As EventArgs) Handles txt_CellMultip2.Enter
        txt_CellMultip2.ForeColor = Color.Blue
    End Sub

    Private Sub txt_HydrolVal2_Enter(sender As Object, e As EventArgs) Handles txt_HydrolVal2.Enter
        txt_HydrolVal2.ForeColor = Color.Blue
    End Sub

    Private Sub txt_ChngLyrShpTab2_Leave(sender As Object, e As EventArgs) Handles txt_ChngLyrShpTab2.Leave
        Try
            GC_input_changelyr_shp = txt_ChngLyrShpTab2.Text
            If (GC_input_changelyr_shp <> "") And My.Computer.FileSystem.FileExists(GC_input_changelyr_shp) Then
                GC_input_changelyr_shp_exists = True
                txt_ChngLyrShpTab2.ForeColor = Color.Black
            Else
                GC_input_changelyr_shp_exists = False
                txt_ChngLyrShpTab2.ForeColor = Color.Red
            End If

        Catch ex As Exception
            MsgBox("Please enter change layer shapefile.")
        End Try
    End Sub
    ''' updates GC_RootDir
    Private Sub txt_rasterFolderTab2_Leave(sender As Object, e As EventArgs) Handles txt_rasterFolderTab2.Leave
        Try
            GC_RootDir = txt_rasterFolderTab2.Text
            txt_InputF.Text = txt_rasterFolderTab2.Text 'update to tab 1
            txt_SelRootDir.Text = txt_rasterFolderTab2.Text 'update to tab 3
            If (GC_RootDir <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir) Then
                GC_RootDir_exists = True
                txt_InputF.ForeColor = Color.Black
                txt_rasterFolderTab2.ForeColor = Color.Black
                txt_SelRootDir.ForeColor = Color.Black
            Else
                GC_RootDir_exists = False
                txt_InputF.ForeColor = Color.Red
                txt_rasterFolderTab2.ForeColor = Color.Red
                txt_SelRootDir.ForeColor = Color.Red
            End If
            'update raster existence, colors and combo box lists
            RasterFolderLeave()

        Catch ex As Exception
            MsgBox("Please enter raster path.")
        End Try
    End Sub
    ''' updates GC_input_CC
    Private Sub txt_habitatTab2_Leave(sender As Object, e As EventArgs) Handles txt_habitatTab2.Leave
        Try
            GC_input_CC = txt_habitatTab2.Text
            'copy to other tabs
            txt_inplh_cc1.Text = txt_habitatTab2.Text 'update to tab 1 (lh_cc)
            'update text colour on all tabs if folder exists/does not exist
            If (GC_input_CC <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_CC) Then
                GC_input_CC_exists = True
                txt_inplh_cc1.ForeColor = Color.Black
                txt_habitatTab2.ForeColor = Color.Black
            Else
                GC_input_CC_exists = False
                txt_inplh_cc1.ForeColor = Color.Red
                txt_habitatTab2.ForeColor = Color.Red
            End If
            'update veg list for combo box
            If Not GC_input_CC = "" Then
                UpdateVegList(GC_input_CC, GC_input_CC_exists)
            End If

        Catch ex As Exception
            MsgBox("Please enter habitat raster.")
        End Try
    End Sub
    ''' updates GC_input_luse
    Private Sub txt_landuseTab2_Leave(sender As Object, e As EventArgs) Handles txt_landuseTab2.Leave
        Try
            GC_input_luse = txt_landuseTab2.Text
            'copy to other tabs
            txt_luse1.Text = txt_landuseTab2.Text 'update to tab 1 (luse)
            'update text colour on all tabs if folder exists/does not exist
            If (GC_input_luse <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_luse) Then
                GC_input_luse_exists = True
                txt_landuseTab2.ForeColor = Color.Black
                txt_luse1.ForeColor = Color.Black
            Else
                GC_input_luse_exists = False
                txt_landuseTab2.ForeColor = Color.Red
                txt_luse1.ForeColor = Color.Red
            End If
            'update landuse list for combo box
            If Not GC_input_luse = "" Then
                UpdateLanduseList(GC_input_luse, GC_input_luse_exists)
            End If

        Catch ex As Exception
            MsgBox("Please enter land use raster.")
        End Try
    End Sub

    Private Sub txt_ChangerasterTab2_Leave(sender As Object, e As EventArgs) Handles txt_ChangerasterTab2.Leave
        Try
            GC_input_changelyr = txt_ChangerasterTab2.Text
            If (GC_input_changelyr <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_changelyr) Then
                GC_input_changelyr_exists = True
                txt_ChangerasterTab2.ForeColor = Color.Black
            Else
                GC_input_changelyr_exists = False
                txt_ChangerasterTab2.ForeColor = Color.Red
            End If

        Catch ex As Exception
            MsgBox("Please enter change layer raster.")
        End Try
    End Sub

    Private Sub txt_NewRasterRemv_Leave(sender As Object, e As EventArgs) Handles txt_NewRasterRemv.Leave
        Try
            GC_veg_removal = txt_NewRasterRemv.Text
            If (GC_veg_removal <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_veg_removal) Then
                GC_veg_removal_exists = True
                txt_NewRasterRemv.ForeColor = Color.Black
            Else
                GC_veg_removal_exists = False
                txt_NewRasterRemv.ForeColor = Color.Red
            End If
            'update veg list for combo box
            If Not GC_veg_removal = "" Then
                UpdateVegList(GC_veg_removal, GC_veg_removal_exists)
            End If

        Catch ex As Exception
            MsgBox("Please enter new vegetation layer (removal) name.")
        End Try
    End Sub

    Private Sub txt_NewRastAdd_Leave(sender As Object, e As EventArgs) Handles txt_NewRastAdd.Leave
        Try
            GC_veg_addition = txt_NewRastAdd.Text
            If (GC_veg_addition <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_veg_addition) Then
                GC_veg_addition_exists = True
                txt_NewRastAdd.ForeColor = Color.Black
            Else
                GC_veg_addition_exists = False
                txt_NewRastAdd.ForeColor = Color.Red
            End If
            'update veg list for combo box
            If Not GC_veg_addition = "" Then
                UpdateVegList(GC_veg_addition, GC_veg_addition_exists)
            End If

        Catch ex As Exception
            MsgBox("Please enter ne vegetation layer (addition) name.")
        End Try
    End Sub

    Private Sub txt_GapcrossTab2_Leave(sender As Object, e As EventArgs) Handles txt_GapcrossTab2.Leave
        Try
            GC_gapcross_add = txt_GapcrossTab2.Text
            If (GC_gapcross_add <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_gapcross_add) Then
                GC_gapcross_add_exists = True
                txt_GapcrossTab2.ForeColor = Color.Black
            Else
                GC_gapcross_add_exists = False
                txt_GapcrossTab2.ForeColor = Color.Red
            End If
            'update gapcross list for combo box
            If Not GC_gapcross_add = "" Then
                UpdateGapcrossList(GC_gapcross_add, GC_gapcross_add_exists)
            End If

        Catch ex As Exception
            MsgBox("Please enter gapcross (addition) name.")
        End Try
    End Sub

    Private Sub txt_infrastructure_Leave(sender As Object, e As EventArgs) Handles txt_infrastructure.Leave
        Try
            GC_luse_add = txt_infrastructure.Text
            If (GC_luse_add <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_luse_add) Then
                GC_luse_add_exists = True
                txt_infrastructure.ForeColor = Color.Black
            Else
                GC_luse_add_exists = False
                txt_infrastructure.ForeColor = Color.Red
            End If
            'update landuse list for combo box
            If Not GC_luse_add = "" Then
                UpdateLanduseList(GC_luse_add, GC_luse_add_exists)
            End If

        Catch ex As Exception
            MsgBox("Please enter landuse (infrastructure) name.")
        End Try
    End Sub

    Private Sub txt_RasValFldTab2_Leave(sender As Object, e As EventArgs) Handles txt_RasValFldTab2.Leave
        Try
            GC_FieldName = txt_RasValFldTab2.Text
            If txt_RasValFldTab2.TextLength > 0 Then
                GC_FieldName_exists = True
                txt_RasValFldTab2.ForeColor = Color.Black
            Else
                GC_FieldName_exists = False
                txt_RasValFldTab2.ForeColor = Color.Red 'if length is zero then wont be seen anyway but just keeping code consistent
            End If

        Catch ex As Exception
            MsgBox("Please enter output path.")
        End Try
    End Sub
    'leave numerical
    Private Sub txt_HydrolVal1_Leave(sender As Object, e As EventArgs) Handles txt_HydrolVal1.Leave
        Try
            If txt_HydrolVal1.Text <> Nothing Then
                GC_HydrologyValue1 = CDbl(txt_HydrolVal1.Text)
                GC_HydrologyValue1_exists = True
                txt_HydrolVal1.ForeColor = Color.Black
            Else
                GC_HydrologyValue1_exists = False
                txt_HydrolVal1.ForeColor = Color.Red
            End If

        Catch ex As Exception
            MsgBox("The value entered must be a number")
            txt_HydrolVal1.Select()
        End Try
    End Sub
    'leave numerical
    Private Sub txt_CellMultip2_Leave(sender As Object, e As EventArgs) Handles txt_CellMultip2.Leave
        Try
            If txt_CellMultip2.Text <> Nothing Then
                GC_CellMultiplier2 = CDbl(txt_CellMultip2.Text)
                GC_CellMultiplier2_exists = True
                txt_CellMultip2.ForeColor = Color.Black
            Else
                GC_CellMultiplier2_exists = False
                txt_CellMultip2.ForeColor = Color.Red
            End If

        Catch ex As Exception
            MsgBox("The value entered must be a number")
            txt_CellMultip2.Select()
        End Try
    End Sub
    'leave numerical
    Private Sub txt_HydrolVal2_Leave(sender As Object, e As EventArgs) Handles txt_HydrolVal2.Leave
        Try
            If txt_HydrolVal2.Text <> Nothing Then
                GC_HydrologyValue2 = CDbl(txt_HydrolVal2.Text)
                GC_HydrologyValue2_exists = True
                txt_HydrolVal2.ForeColor = Color.Black
            Else
                GC_HydrologyValue2_exists = False
                txt_HydrolVal2.ForeColor = Color.Red
            End If

        Catch ex As Exception
            MsgBox("The value entered must be a number")
            txt_HydrolVal2.Select()
        End Try

    End Sub
    '

    '
    'update veg combo box list
    Private Sub UpdateVegList(s_raster As String, ex_raster As Boolean) 'raster name and does it exist
        Try
            'if exists and not already there add veg raster to list
            If (Not GC_v.Contains(s_raster)) And (ex_raster = True) Then
                GC_v.Add(s_raster)
            End If
            'if not exists and is already there delete veg raster from list
            If (GC_v.Contains(s_raster)) And (ex_raster = False) Then
                GC_v.Remove(s_raster)
            End If
        Catch
            MsgBox("error in populating list")
        End Try
    End Sub

    'make veg combo box selection
    Private Sub cbo_SelectVegRaster_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbo_SelectVegRaster.SelectedIndexChanged
        txt_inp_cc.Text = CStr(cbo_SelectVegRaster.SelectedItem)
        GC_v_sel = txt_inp_cc.Text
    End Sub
    'populate veg combo box
    Private Sub cbo_SelectVegRaster_Enter(sender As Object, e As EventArgs) Handles cbo_SelectVegRaster.Enter
        cbo_SelectVegRaster.Items.Clear()
        If Not GC_v Is Nothing Then
            For Each x In GC_v
                cbo_SelectVegRaster.Items.Add(x)
            Next
        End If
    End Sub
    'clear veg combo box afterwards
    Private Sub cbo_SelectVegRaster_Leave(sender As Object, e As EventArgs) Handles cbo_SelectVegRaster.Leave
        cbo_SelectVegRaster.Text = ""
    End Sub
    'update gapcross combo box list
    Private Sub UpdateGapcrossList(s_raster As String, ex_raster As Boolean)
        Try
            'if exists and not already there add gapcross raster to list
            If (Not GC_g.Contains(s_raster)) And (ex_raster = True) Then
                GC_g.Add(s_raster)
            End If
            'if not exists and is already there delete gapcross raster from list
            If (GC_g.Contains(s_raster)) And (ex_raster = False) Then
                GC_g.Remove(s_raster)
            End If
        Catch
            MsgBox("error in populating list")
        End Try
    End Sub

    Private Sub cbo_SelectGapcrossRaster_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbo_SelectGapcrossRaster.SelectedIndexChanged
        txt_inp_gc.Text = CStr(cbo_SelectGapcrossRaster.SelectedItem)
        GC_g_sel = txt_inp_gc.Text
    End Sub

    Private Sub cbo_SelectGapcrossRaster_Enter(sender As Object, e As EventArgs) Handles cbo_SelectGapcrossRaster.Enter
        cbo_SelectGapcrossRaster.Items.Clear()
        If Not GC_g Is Nothing Then
            For Each x In GC_g
                cbo_SelectGapcrossRaster.Items.Add(x)
            Next
        End If
    End Sub

    Private Sub cbo_SelectGapcrossRaster_Leave(sender As Object, e As EventArgs) Handles cbo_SelectGapcrossRaster.Leave
        cbo_SelectGapcrossRaster.Text = ""
    End Sub
    'update landuse combo box list
    Private Sub UpdateLanduseList(s_raster As String, ex_raster As Boolean)
        Try
            'if exists and not already there add landuse raster to list
            If (Not GC_l.Contains(s_raster)) And (ex_raster = True) Then
                GC_l.Add(s_raster)
            End If
            'if not exists and is already there delete landuse raster from list
            If (GC_l.Contains(s_raster)) And (ex_raster = False) Then
                GC_l.Remove(s_raster)
            End If
        Catch
            MsgBox("error in populating list")
        End Try
    End Sub

    Private Sub cbo_SelectLanduseRaster_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbo_SelectLanduseRaster.SelectedIndexChanged
        txt_inp_luse.Text = CStr(cbo_SelectLanduseRaster.SelectedItem)
        GC_l_sel = txt_inp_luse.Text
    End Sub

    Private Sub cbo_SelectLanduseRaster_Enter(sender As Object, e As EventArgs) Handles cbo_SelectLanduseRaster.Enter
        cbo_SelectLanduseRaster.Items.Clear()
        If Not GC_l Is Nothing Then
            For Each x In GC_l
                cbo_SelectLanduseRaster.Items.Add(x)
            Next
        End If
    End Sub

    Private Sub cbo_SelectLanduseRaster_Leave(sender As Object, e As EventArgs) Handles cbo_SelectLanduseRaster.Leave
        cbo_SelectLanduseRaster.Text = ""
    End Sub
    '

    '
    Private Sub DefaultsTabToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DefaultsTabToolStripMenuItem.Click
        tb_Settings.SelectedTab = tb_1
    End Sub

    Private Sub ScenariosTabToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ScenariosTabToolStripMenuItem.Click
        tb_Settings.SelectedTab = tb_2
    End Sub

    Private Sub ProcessrastersForModelTabToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProcessrastersForModelTabToolStripMenuItem.Click
        tb_Settings.SelectedTab = tb_3
    End Sub

    Private Sub ScriptOutputsTabToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ScriptOutputsTabToolStripMenuItem.Click
        tb_Settings.SelectedTab = tb_4
    End Sub

    Private Sub PythonConfigTabToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PythonConfigTabToolStripMenuItem.Click
        tb_Settings.SelectedTab = tb_Config
    End Sub

    Private Sub LoadScenarioToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles LoadScenarioToolStripMenuItem1.Click
        'open load file dialog box
        Dim ScenarioPath As String = appPath & "\Scenarios\Defaults.txt"

        Try
            Dim Rst = dlg_GetScenarioFile.ShowDialog() ' find file dialog to find or set scenario file name
            If Rst = Windows.Forms.DialogResult.OK Then
                ScenarioPath = dlg_GetScenarioFile.FileName
                LoadParameters(ScenarioPath)
            ElseIf Rst = Windows.Forms.DialogResult.Cancel Then
                'nothing happens when cancel selected
            End If
        Catch ex As Exception
            MsgBox("unhandled exception")
        End Try
    End Sub

    Private Sub SaveScenarioToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveScenarioToolStripMenuItem.Click
        'open save file dialog box
        Dim Defaultspath As String = appPath & "\Scenarios\Defaults.txt"
        Try
            Dim Rst = dlg_SaveF.ShowDialog() 'find save file name
            If Rst = Windows.Forms.DialogResult.OK Then
                Defaultspath = dlg_SaveF.FileName
                SaveParamsGeneric(Defaultspath)
            ElseIf Rst = Windows.Forms.DialogResult.Cancel Then
                MsgBox("Save file was cancelled.")
            End If
        Catch ex As Exception
            MsgBox("unhandled exception")
        End Try
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click

        Dim MB = MessageBox.Show("Save current parameters?", "Save Scenerio", MessageBoxButtons.YesNo)

        If MB = Windows.Forms.DialogResult.Yes Then
            SaveScenarioToolStripMenuItem_Click(Me, Nothing)
        ElseIf MB = Windows.Forms.DialogResult.No Then
            'MsgBox("Save was cancelled.")
        End If
        'close
        Close()
    End Sub

    Private Sub AboutGAPCLosRToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutGAPCLosRToolStripMenuItem.Click
        btn_About_Click(Me, Nothing)
    End Sub
    '
    'button to save script output to file
    Private Sub btn_saveScriptOutput_Click(sender As Object, e As EventArgs) Handles btn_saveScriptOutput.Click
        'open save file dialog box
        Dim SaveScriptOutput As String = appPath & "\Scenarios\ScriptOutput.txt"
        Try
            Dim Rst = dlg_SaveF.ShowDialog() 'find save file name
            If Rst = Windows.Forms.DialogResult.OK Then
                SaveScriptOutput = dlg_SaveF.FileName
                Try
                    Dim sw As New IO.StreamWriter(SaveScriptOutput, False) 'overwrite
                    sw.Write(txt_PythonOutput.Text)
                    sw.Close()
                Catch

                End Try
            ElseIf Rst = Windows.Forms.DialogResult.Cancel Then
                MsgBox("Save file was cancelled.")
            End If
        Catch ex As Exception
            MsgBox("unhandled exception")
        End Try
    End Sub
    '
    Private Sub btn_BrHabRasTab1_Click(sender As Object, e As EventArgs) Handles btn_BrHabRasTab1.Click
        Try
            'sets the initial selected directory to the luse.shp path if that has been previously selected
            dlg_GetRootFolder.SelectedPath = GC_LastFolder

            'end testing
            Dim dlgc = dlg_GetRootFolder.ShowDialog()
            If dlgc = Windows.Forms.DialogResult.OK Then
                txt_inplh_cc1.Text = dlg_GetRootFolder.SelectedPath.Split(IO.Path.DirectorySeparatorChar).Last() 'get last part only
                GC_input_CC = txt_inplh_cc1.Text
                'copy to other tabs
                txt_habitatTab2.Text = txt_inplh_cc1.Text 'update to tab 2 (lh_cc)
                'update text colour on all tabs if folder exists/does not exist
                If (GC_input_CC <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_CC) Then
                    GC_input_CC_exists = True
                    txt_inplh_cc1.ForeColor = Color.Black
                    txt_habitatTab2.ForeColor = Color.Black
                Else
                    GC_input_CC_exists = False
                    txt_inplh_cc1.ForeColor = Color.Red
                    txt_habitatTab2.ForeColor = Color.Red
                End If
                'update veg list for combo box
                If Not GC_input_CC = "" Then
                    UpdateVegList(GC_input_CC, GC_input_CC_exists)
                End If

            End If

        Catch ex As Exception
            MsgBox("Error in selecting the raster") ': {0}", ex.ToString())
        End Try
    End Sub

    Private Sub btn_BrLuRasTab1_Click(sender As Object, e As EventArgs) Handles btn_BrLuRasTab1.Click
        Try
            'sets the initial selected directory to the luse.shp path if that has been previously selected
            dlg_GetRootFolder.SelectedPath = GC_LastFolder

            Dim dlgc = dlg_GetRootFolder.ShowDialog()
            If dlgc = Windows.Forms.DialogResult.OK Then
                txt_luse1.Text = dlg_GetRootFolder.SelectedPath.Split(IO.Path.DirectorySeparatorChar).Last() 'get last part only
                GC_input_luse = txt_luse1.Text
                'copy to other tabs
                txt_landuseTab2.Text = txt_luse1.Text 'update to tab 1 (luse)
                'update text colour on all tabs if folder exists/does not exist
                If (GC_input_luse <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_luse) Then
                    GC_input_luse_exists = True
                    txt_landuseTab2.ForeColor = Color.Black
                    txt_luse1.ForeColor = Color.Black
                Else
                    GC_input_luse_exists = False
                    txt_landuseTab2.ForeColor = Color.Red
                    txt_luse1.ForeColor = Color.Red
                End If
                'update landuse list for combo box
                If Not GC_input_luse = "" Then
                    UpdateLanduseList(GC_input_luse, GC_input_luse_exists)
                End If
            End If
        Catch ex As Exception
            MsgBox("Error in selecting the raster") ': {0}", ex.ToString())
        End Try
    End Sub

    Private Sub btn_BrGcRasTab1_Click(sender As Object, e As EventArgs) Handles btn_BrGcRasTab1.Click
        Try
            'sets the initial selected directory to the luse.shp path if that has been previously selected
            dlg_GetRootFolder.SelectedPath = GC_LastFolder

            Dim dlgc = dlg_GetRootFolder.ShowDialog()
            If dlgc = Windows.Forms.DialogResult.OK Then
                txt_gap_cross1.Text = dlg_GetRootFolder.SelectedPath.Split(IO.Path.DirectorySeparatorChar).Last() 'get last part only
                GC_input_gap_cross = txt_gap_cross1.Text
                If (GC_input_gap_cross <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_gap_cross) Then
                    GC_input_gap_cross_exists = True
                    txt_gap_cross1.ForeColor = Color.Black
                Else
                    GC_input_gap_cross_exists = False
                    txt_gap_cross1.ForeColor = Color.Red
                End If
                'update gapcross list for combo box
                If Not GC_input_gap_cross = "" Then
                    UpdateGapcrossList(GC_input_gap_cross, GC_input_gap_cross_exists)
                End If
            End If
        Catch ex As Exception
            MsgBox("Error in selecting the raster")
        End Try
    End Sub

    Private Sub btn_BrGcORasTab1_Click(sender As Object, e As EventArgs) Handles btn_BrGcORasTab1.Click
        Try
            'sets the initial selected directory to the luse.shp path if that has been previously selected
            dlg_GetRootFolder.SelectedPath = GC_LastFolder

            Dim dlgc = dlg_GetRootFolder.ShowDialog()
            If dlgc = Windows.Forms.DialogResult.OK Then
                txt_gapcrossOld.Text = dlg_GetRootFolder.SelectedPath.Split(IO.Path.DirectorySeparatorChar).Last() 'get last part only
                GC_input_gap_crossO = txt_gapcrossOld.Text
                If (GC_input_gap_crossO <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_gap_crossO) Then
                    GC_input_gap_crossO_exists = True
                    txt_gapcrossOld.ForeColor = Color.Black
                Else
                    GC_input_gap_crossO_exists = False
                    txt_gapcrossOld.ForeColor = Color.Red
                End If
                'update gapcross list for combo box
                If Not GC_input_gap_crossO = "" Then
                    UpdateGapcrossList(GC_input_gap_crossO, GC_input_gap_crossO_exists)
                End If
            End If
        Catch ex As Exception
            MsgBox("Error in selecting the raster")
        End Try
    End Sub

    Private Sub btn_BrChTab2_Click(sender As Object, e As EventArgs) Handles btn_BrChTab2.Click
        Try
            'sets the initial selected directory to the luse.shp path if that has been previously selected
            dlg_GetRootFolder.SelectedPath = GC_LastFolder

            Dim dlgc = dlg_GetRootFolder.ShowDialog()
            If dlgc = Windows.Forms.DialogResult.OK Then
                txt_ChangerasterTab2.Text = dlg_GetRootFolder.SelectedPath.Split(IO.Path.DirectorySeparatorChar).Last() 'get last part only
                GC_input_changelyr = txt_ChangerasterTab2.Text
                If (GC_input_changelyr <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_input_changelyr) Then
                    GC_input_changelyr_exists = True
                    txt_ChangerasterTab2.ForeColor = Color.Black
                Else
                    GC_input_changelyr_exists = False
                    txt_ChangerasterTab2.ForeColor = Color.Red
                End If
            End If
        Catch ex As Exception
            MsgBox("Error in selecting the raster")
        End Try
    End Sub

    Private Sub btn_BrRemTab2_Click(sender As Object, e As EventArgs) Handles btn_BrRemTab2.Click
        Try
            'sets the initial selected directory to the luse.shp path if that has been previously selected
            dlg_GetRootFolder.SelectedPath = GC_LastFolder

            Dim dlgc = dlg_GetRootFolder.ShowDialog()
            If dlgc = Windows.Forms.DialogResult.OK Then
                txt_NewRasterRemv.Text = dlg_GetRootFolder.SelectedPath.Split(IO.Path.DirectorySeparatorChar).Last() 'get last part only
                GC_veg_removal = txt_NewRasterRemv.Text
                If (GC_veg_removal <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_veg_removal) Then
                    GC_veg_removal_exists = True
                    txt_NewRasterRemv.ForeColor = Color.Black
                Else
                    GC_veg_removal_exists = False
                    txt_NewRasterRemv.ForeColor = Color.Red
                End If
                'update veg list for combo box
                If Not GC_veg_removal = "" Then
                    UpdateVegList(GC_veg_removal, GC_veg_removal_exists)
                End If
            End If
        Catch ex As Exception
            MsgBox("Error in selecting the raster")
        End Try
    End Sub

    Private Sub btn_BrAddTab2_Click(sender As Object, e As EventArgs) Handles btn_BrAddTab2.Click
        Try
            'sets the initial selected directory to the luse.shp path if that has been previously selected
            dlg_GetRootFolder.SelectedPath = GC_LastFolder

            Dim dlgc = dlg_GetRootFolder.ShowDialog()
            If dlgc = Windows.Forms.DialogResult.OK Then
                txt_NewRastAdd.Text = dlg_GetRootFolder.SelectedPath.Split(IO.Path.DirectorySeparatorChar).Last() 'get last part only
                GC_veg_addition = txt_NewRastAdd.Text
                If (GC_veg_addition <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_veg_addition) Then
                    GC_veg_addition_exists = True
                    txt_NewRastAdd.ForeColor = Color.Black
                Else
                    GC_veg_addition_exists = False
                    txt_NewRastAdd.ForeColor = Color.Red
                End If
                'update veg list for combo box
                If Not GC_veg_addition = "" Then
                    UpdateVegList(GC_veg_addition, GC_veg_addition_exists)
                End If
            End If
        Catch ex As Exception
            MsgBox("Error in selecting the raster")
        End Try
    End Sub

    Private Sub btn_BrGCTab2_Click(sender As Object, e As EventArgs) Handles btn_BrGCTab2.Click
        Try
            'sets the initial selected directory to the luse.shp path if that has been previously selected
            dlg_GetRootFolder.SelectedPath = GC_LastFolder

            Dim dlgc = dlg_GetRootFolder.ShowDialog()
            If dlgc = Windows.Forms.DialogResult.OK Then
                txt_GapcrossTab2.Text = dlg_GetRootFolder.SelectedPath.Split(IO.Path.DirectorySeparatorChar).Last() 'get last part only
                GC_gapcross_add = txt_GapcrossTab2.Text
                If (GC_gapcross_add <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_gapcross_add) Then
                    GC_gapcross_add_exists = True
                    txt_GapcrossTab2.ForeColor = Color.Black
                Else
                    GC_gapcross_add_exists = False
                    txt_GapcrossTab2.ForeColor = Color.Red
                End If
                'update gapcross list for combo box
                If Not GC_gapcross_add = "" Then
                    UpdateGapcrossList(GC_gapcross_add, GC_gapcross_add_exists)
                End If
            End If
        Catch ex As Exception
            MsgBox("Error in selecting the raster")
        End Try
    End Sub

    Private Sub btn_BrInfTab2_Click(sender As Object, e As EventArgs) Handles btn_BrInfTab2.Click
        Try
            'sets the initial selected directory to the luse.shp path if that has been previously selected
            dlg_GetRootFolder.SelectedPath = GC_LastFolder

            Dim dlgc = dlg_GetRootFolder.ShowDialog()
            If dlgc = Windows.Forms.DialogResult.OK Then
                txt_infrastructure.Text = dlg_GetRootFolder.SelectedPath.Split(IO.Path.DirectorySeparatorChar).Last() 'get last part only
                GC_luse_add = txt_infrastructure.Text
                If (GC_luse_add <> "") And My.Computer.FileSystem.DirectoryExists(GC_RootDir & "\" & GC_luse_add) Then
                    GC_luse_add_exists = True
                    txt_infrastructure.ForeColor = Color.Black
                Else
                    GC_luse_add_exists = False
                    txt_infrastructure.ForeColor = Color.Red
                End If
                'update landuse list for combo box
                If Not GC_luse_add = "" Then
                    UpdateLanduseList(GC_luse_add, GC_luse_add_exists)
                End If
            End If
        Catch ex As Exception
            MsgBox("Error in selecting the raster")
        End Try
    End Sub
    '
    'run scripts for selected rasters together
    Private Sub btn_RunCombined_Click(sender As Object, e As EventArgs) Handles btn_RunCombined.Click
        Try
            'what to do here
            'disable relevant controls
            btn_RunCombined.Enabled = False
            'check which check boxes have been selected
            If chk_SelDefL.Checked = True Then
                btn_RunConvLusetoRaster_Click(Me, Nothing)
            End If
            If chk_SelDefGC.Checked = True Then
                btn_CreateGapCross_Click(Me, Nothing)
            End If
            If chk_SelDefGCO.Checked = True Then
                btn_GapCrossOld_Click(Me, Nothing)
            End If
            If chk_selS1.Checked = True Then
                btn_RunScen1_Click(Me, Nothing)
            End If
            If chk_selS2a.Checked = True Then
                btn_RunScen2a_Click(Me, Nothing)
            End If
            If chk_sel2b.Checked = True Then
                btn_RunScen2b_Click(Me, Nothing)
            End If
            If chk_sel3.Checked = True Then
                btn_RunScen3_Click(Me, Nothing)
            End If
            If chk_selS4.Checked = True Then
                btn_RunScen4_Click(Me, Nothing)
            End If

            'identify which inputs are missing, cancel and prompt for changes
            'notice to say which outputs will be overwritten
            'run scripts in sequence
            'unselect check boxes
            btn_RunCombined.Enabled = True
        Catch
            MsgBox("There was an error with running the selected scripts")
        End Try
    End Sub

    Private Sub btn_SetScriptsFolder_Click(sender As Object, e As EventArgs) Handles btn_SetScriptsFolder.Click
        GC_ScriptsFolder = Chr(34) & appPath & "\GAP_CLoSR_Code" & Chr(34)
        txt_ScriptsFolder.Text = GC_ScriptsFolder
    End Sub
    '
    Private Sub chk_SelDefL_CheckedChanged(sender As Object, e As EventArgs) Handles chk_SelDefL.CheckedChanged
        If chk_SelDefL.Checked = True Then
            btn_RunConvLusetoRaster.Enabled = False
            'txt_PythonOutput.AppendText(vbCrLf & "create land use raster (default) selected")
        Else
            btn_RunConvLusetoRaster.Enabled = True
            'txt_PythonOutput.AppendText(vbCrLf & "create land use raster (default) unselected")
        End If
    End Sub

    Private Sub chk_SelDefGC_CheckedChanged(sender As Object, e As EventArgs) Handles chk_SelDefGC.CheckedChanged
        If chk_SelDefGC.Checked = True Then
            btn_CreateGapCross.Enabled = False
            'txt_PythonOutput.AppendText(vbCrLf & "create gap-cross raster (default) selected")
        Else
            btn_CreateGapCross.Enabled = True
            'txt_PythonOutput.AppendText(vbCrLf & "create gap-cross raster (default) unselected")
        End If
    End Sub

    Private Sub chk_SelDefGCO_CheckedChanged(sender As Object, e As EventArgs) Handles chk_SelDefGCO.CheckedChanged
        If chk_SelDefGCO.Checked = True Then
            btn_GapCrossOld.Enabled = False
            'txt_PythonOutput.AppendText(vbCrLf & "create gap-cross raster (default, alternative method) selected")
        Else
            btn_GapCrossOld.Enabled = True
            'txt_PythonOutput.AppendText(vbCrLf & "create gap-cross raster (default, alternative method) unselected")
        End If
    End Sub

    Private Sub chk_selS1_CheckedChanged(sender As Object, e As EventArgs) Handles chk_selS1.CheckedChanged
        If chk_selS1.Checked = True Then
            btn_RunScen1.Enabled = False
            'txt_PythonOutput.AppendText(vbCrLf & "create change raster selected")
        Else
            btn_RunScen1.Enabled = True
            'txt_PythonOutput.AppendText(vbCrLf & "create changes raster unselected")
        End If
    End Sub

    Private Sub chk_selS2a_CheckedChanged(sender As Object, e As EventArgs) Handles chk_selS2a.CheckedChanged
        If chk_selS2a.Checked = True Then
            btn_RunScen2a.Enabled = False
            'txt_PythonOutput.AppendText(vbCrLf & "create new habitat (removal) raster selected")
        Else
            btn_RunScen2a.Enabled = True
            'txt_PythonOutput.AppendText(vbCrLf & "create new habitat (removal) raster unselected")
        End If
    End Sub

    Private Sub chk_sel2b_CheckedChanged(sender As Object, e As EventArgs) Handles chk_sel2b.CheckedChanged
        If chk_sel2b.Checked = True Then
            btn_RunScen2b.Enabled = False
            'txt_PythonOutput.AppendText(vbCrLf & "create new habitat (addition) raster selected")
        Else
            btn_RunScen2b.Enabled = True
            'txt_PythonOutput.AppendText(vbCrLf & "create new habitat (addition) raster unselected")
        End If
    End Sub

    Private Sub chk_sel3_CheckedChanged(sender As Object, e As EventArgs) Handles chk_sel3.CheckedChanged
        If chk_sel3.Checked = True Then
            btn_RunScen3.Enabled = False
            'txt_PythonOutput.AppendText(vbCrLf & "create gap-cross (scenario) raster selected")
        Else
            btn_RunScen3.Enabled = True
            'txt_PythonOutput.AppendText(vbCrLf & "create gap-cross (scenario) raster unselected")
        End If
    End Sub

    Private Sub chk_selS4_CheckedChanged(sender As Object, e As EventArgs) Handles chk_selS4.CheckedChanged
        If chk_selS4.Checked = True Then
            btn_RunScen4.Enabled = False
            'txt_PythonOutput.AppendText(vbCrLf & "create modified land use (infrastructure) raster selected")
        Else
            btn_RunScen4.Enabled = True
            'txt_PythonOutput.AppendText(vbCrLf & "create modified land use (infrastructure) raster unselected")
        End If
    End Sub
    '

    Private Sub btn_ProcessrastersTab4_Click(sender As Object, e As EventArgs) Handles btn_ProcessrastersTab4.Click
        btn_Run_GC_Click(Me, Nothing)
    End Sub
End Class
'todo
'
'remove redundant code
'more testing

