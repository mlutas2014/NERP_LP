﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_Main))
        Me.tb_Settings = New System.Windows.Forms.TabControl()
        Me.tb_1 = New System.Windows.Forms.TabPage()
        Me.btn_BrHabRasTab1 = New System.Windows.Forms.Button()
        Me.lbl_outputsTab1 = New System.Windows.Forms.Label()
        Me.lbl_InputsTab1 = New System.Windows.Forms.Label()
        Me.txt_LanduseShp = New System.Windows.Forms.TextBox()
        Me.lbl_LanduseShp = New System.Windows.Forms.Label()
        Me.btn_LanduseShp = New System.Windows.Forms.Button()
        Me.lbl_RasterValueField = New System.Windows.Forms.Label()
        Me.txt_RasterValueField = New System.Windows.Forms.TextBox()
        Me.txt_gapcrossOld = New System.Windows.Forms.TextBox()
        Me.lbl_gapcross_old = New System.Windows.Forms.Label()
        Me.lbl_gap_cross1 = New System.Windows.Forms.Label()
        Me.lbl_luse1 = New System.Windows.Forms.Label()
        Me.lbl_InpVeg = New System.Windows.Forms.Label()
        Me.txt_gap_cross1 = New System.Windows.Forms.TextBox()
        Me.txt_luse1 = New System.Windows.Forms.TextBox()
        Me.txt_inplh_cc1 = New System.Windows.Forms.TextBox()
        Me.btn_InputF = New System.Windows.Forms.Button()
        Me.lbl_InputF = New System.Windows.Forms.Label()
        Me.txt_InputF = New System.Windows.Forms.TextBox()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.chk_SelDefGCO = New System.Windows.Forms.CheckBox()
        Me.btn_BrGcORasTab1 = New System.Windows.Forms.Button()
        Me.btn_GapCrossOld = New System.Windows.Forms.Button()
        Me.txt_inpMultiTab1 = New System.Windows.Forms.TextBox()
        Me.lbl_CellMultiTab1 = New System.Windows.Forms.Label()
        Me.lbl_CreategapcrossTab1 = New System.Windows.Forms.Label()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.chk_SelDefGC = New System.Windows.Forms.CheckBox()
        Me.btn_BrGcRasTab1 = New System.Windows.Forms.Button()
        Me.btn_CreateGapCross = New System.Windows.Forms.Button()
        Me.lbl_gapcrosstab1 = New System.Windows.Forms.Label()
        Me.txt_MaxDist1 = New System.Windows.Forms.TextBox()
        Me.lbl_MaxDist1 = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.chk_SelDefL = New System.Windows.Forms.CheckBox()
        Me.btn_BrLuRasTab1 = New System.Windows.Forms.Button()
        Me.btn_RunConvLusetoRaster = New System.Windows.Forms.Button()
        Me.lbl_luseToRasterTab1 = New System.Windows.Forms.Label()
        Me.tb_2 = New System.Windows.Forms.TabPage()
        Me.lbl_hydrolRasVal2 = New System.Windows.Forms.Label()
        Me.txt_HydrolVal2 = New System.Windows.Forms.TextBox()
        Me.lbl_infrastructure = New System.Windows.Forms.Label()
        Me.txt_infrastructure = New System.Windows.Forms.TextBox()
        Me.lbl_HydrolVal1 = New System.Windows.Forms.Label()
        Me.txt_HydrolVal1 = New System.Windows.Forms.TextBox()
        Me.lbl_NewRasAdd = New System.Windows.Forms.Label()
        Me.txt_NewRastAdd = New System.Windows.Forms.TextBox()
        Me.lbl_NewVegRemove = New System.Windows.Forms.Label()
        Me.txt_NewRasterRemv = New System.Windows.Forms.TextBox()
        Me.lbl_RasValFld_Tab2 = New System.Windows.Forms.Label()
        Me.txt_RasValFldTab2 = New System.Windows.Forms.TextBox()
        Me.lbl_CellMultip2 = New System.Windows.Forms.Label()
        Me.txt_CellMultip2 = New System.Windows.Forms.TextBox()
        Me.txt_ChangerasterTab2 = New System.Windows.Forms.TextBox()
        Me.txt_ChngLyrShpTab2 = New System.Windows.Forms.TextBox()
        Me.lbl_changeLyrShpTab2 = New System.Windows.Forms.Label()
        Me.lbl_changerasterTab2 = New System.Windows.Forms.Label()
        Me.btn_browseChngShpTab2 = New System.Windows.Forms.Button()
        Me.lbl_gapcrossTab2 = New System.Windows.Forms.Label()
        Me.lbl_landuseTab2 = New System.Windows.Forms.Label()
        Me.lbl_habitatTab2 = New System.Windows.Forms.Label()
        Me.txt_GapcrossTab2 = New System.Windows.Forms.TextBox()
        Me.txt_landuseTab2 = New System.Windows.Forms.TextBox()
        Me.txt_habitatTab2 = New System.Windows.Forms.TextBox()
        Me.btn_browse_RasFolderTab2 = New System.Windows.Forms.Button()
        Me.lbl_RasterFoldertab2 = New System.Windows.Forms.Label()
        Me.txt_rasterFolderTab2 = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btn_BrChTab2 = New System.Windows.Forms.Button()
        Me.chk_selS1 = New System.Windows.Forms.CheckBox()
        Me.btn_RunScen1 = New System.Windows.Forms.Button()
        Me.lbl_run1txt = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btn_BrRemTab2 = New System.Windows.Forms.Button()
        Me.chk_selS2a = New System.Windows.Forms.CheckBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.lbl_run2atext = New System.Windows.Forms.Label()
        Me.btn_RunScen2a = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.btn_BrAddTab2 = New System.Windows.Forms.Button()
        Me.chk_sel2b = New System.Windows.Forms.CheckBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.lbl_run2btext = New System.Windows.Forms.Label()
        Me.btn_RunScen2b = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.btn_BrGCTab2 = New System.Windows.Forms.Button()
        Me.chk_sel3 = New System.Windows.Forms.CheckBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.lbl_run3text = New System.Windows.Forms.Label()
        Me.btn_RunScen3 = New System.Windows.Forms.Button()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.btn_BrInfTab2 = New System.Windows.Forms.Button()
        Me.chk_selS4 = New System.Windows.Forms.CheckBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.lbl_Run4text = New System.Windows.Forms.Label()
        Me.btn_RunScen4 = New System.Windows.Forms.Button()
        Me.tb_3 = New System.Windows.Forms.TabPage()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbo_SelectLanduseRaster = New System.Windows.Forms.ComboBox()
        Me.cbo_SelectGapcrossRaster = New System.Windows.Forms.ComboBox()
        Me.lbl_ProcessRasters_tab3 = New System.Windows.Forms.Label()
        Me.btn_Run_GC = New System.Windows.Forms.Button()
        Me.cbo_SelectVegRaster = New System.Windows.Forms.ComboBox()
        Me.btn_OutputF = New System.Windows.Forms.Button()
        Me.lbl_OutputF = New System.Windows.Forms.Label()
        Me.txt_OutputF = New System.Windows.Forms.TextBox()
        Me.btn_ReclTextFile = New System.Windows.Forms.Button()
        Me.lbl_parameters = New System.Windows.Forms.Label()
        Me.lbl_SelRootDir = New System.Windows.Forms.Label()
        Me.lbl_ReclassTxtFile = New System.Windows.Forms.Label()
        Me.btn_RootDir = New System.Windows.Forms.Button()
        Me.btn_ClearAll = New System.Windows.Forms.Button()
        Me.txt_SelRootDir = New System.Windows.Forms.TextBox()
        Me.txt_ReclassTxtFile = New System.Windows.Forms.TextBox()
        Me.lbl_OrigPixelSize = New System.Windows.Forms.Label()
        Me.lbl_NewPixelSize = New System.Windows.Forms.Label()
        Me.txt_inp_luse = New System.Windows.Forms.TextBox()
        Me.txt_inp_gc = New System.Windows.Forms.TextBox()
        Me.txt_inp_cc = New System.Windows.Forms.TextBox()
        Me.lbl_MaxCost = New System.Windows.Forms.Label()
        Me.lbl_inp_luse = New System.Windows.Forms.Label()
        Me.lbl_MaxDist = New System.Windows.Forms.Label()
        Me.lbl_inp_gc = New System.Windows.Forms.Label()
        Me.lbl_inp_cc = New System.Windows.Forms.Label()
        Me.txt_OriginalPixelSize = New System.Windows.Forms.TextBox()
        Me.txt_MaxDist = New System.Windows.Forms.TextBox()
        Me.txt_NewPixelSize = New System.Windows.Forms.TextBox()
        Me.txt_MaxCost = New System.Windows.Forms.TextBox()
        Me.tb_4 = New System.Windows.Forms.TabPage()
        Me.btn_ProcessrastersTab4 = New System.Windows.Forms.Button()
        Me.btn_RunCombined = New System.Windows.Forms.Button()
        Me.btn_saveScriptOutput = New System.Windows.Forms.Button()
        Me.btn_ClearErrorOutput = New System.Windows.Forms.Button()
        Me.btn_ClearScriptOutput = New System.Windows.Forms.Button()
        Me.lbl_ScriptOutp = New System.Windows.Forms.Label()
        Me.lbl_ScriptError = New System.Windows.Forms.Label()
        Me.txt_PythonError = New System.Windows.Forms.TextBox()
        Me.txt_PythonOutput = New System.Windows.Forms.TextBox()
        Me.tb_Config = New System.Windows.Forms.TabPage()
        Me.btn_SetScriptsFolder = New System.Windows.Forms.Button()
        Me.txt_ScriptcreateGC_old = New System.Windows.Forms.TextBox()
        Me.lbl_scriptcreateGC_old = New System.Windows.Forms.Label()
        Me.btn_About = New System.Windows.Forms.Button()
        Me.lbl_ScriptScenario4 = New System.Windows.Forms.Label()
        Me.txt_scriptScenario4 = New System.Windows.Forms.TextBox()
        Me.lbl_ScriptScenario3 = New System.Windows.Forms.Label()
        Me.txt_ScriptScenario3 = New System.Windows.Forms.TextBox()
        Me.lbl_ScriptScenario2b = New System.Windows.Forms.Label()
        Me.txt_ScriptScenario2b = New System.Windows.Forms.TextBox()
        Me.lbl_scriptScenario2a = New System.Windows.Forms.Label()
        Me.txt_ScriptScenario2a = New System.Windows.Forms.TextBox()
        Me.lbl_ScriptScenario1 = New System.Windows.Forms.Label()
        Me.txt_ScriptScenario1 = New System.Windows.Forms.TextBox()
        Me.lbl_createGapCross = New System.Windows.Forms.Label()
        Me.txt_ScriptCreateGapCross = New System.Windows.Forms.TextBox()
        Me.lbl_scriptLuseToRaster = New System.Windows.Forms.Label()
        Me.txt_ScriptLuseToRaster = New System.Windows.Forms.TextBox()
        Me.lbl_ScriptsDir = New System.Windows.Forms.Label()
        Me.txt_ScriptsFolder = New System.Windows.Forms.TextBox()
        Me.lbl_ProcessingScript = New System.Windows.Forms.Label()
        Me.lbl_GC_Script = New System.Windows.Forms.Label()
        Me.txt_GC_ScriptName = New System.Windows.Forms.TextBox()
        Me.lbl_ScenPrHeader = New System.Windows.Forms.Label()
        Me.lbl_DefaultHeader = New System.Windows.Forms.Label()
        Me.lbl_Scripts = New System.Windows.Forms.Label()
        Me.btn_SavePyExePth = New System.Windows.Forms.Button()
        Me.btn_LoadPyExePth = New System.Windows.Forms.Button()
        Me.btn_BrowseArcPyPath = New System.Windows.Forms.Button()
        Me.lbl_pthArcPy = New System.Windows.Forms.Label()
        Me.txt_ArcPythonApp = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dlg_GetRootFolder = New System.Windows.Forms.FolderBrowserDialog()
        Me.dlg_FindArcPyPath = New System.Windows.Forms.OpenFileDialog()
        Me.dlg_FindGCScript = New System.Windows.Forms.OpenFileDialog()
        Me.dlg_ReclassText = New System.Windows.Forms.OpenFileDialog()
        Me.dlg_GetScenarioFile = New System.Windows.Forms.OpenFileDialog()
        Me.dlg_SaveF = New System.Windows.Forms.SaveFileDialog()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.dlg_OpenShapefile = New System.Windows.Forms.OpenFileDialog()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.LoadScenarioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadScenarioToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveScenarioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DefaultsTabToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ScenariosTabToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProcessrastersForModelTabToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ScriptOutputsTabToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PythonConfigTabToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutGAPCLosRToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tb_Settings.SuspendLayout()
        Me.tb_1.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.tb_2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.tb_3.SuspendLayout()
        Me.tb_4.SuspendLayout()
        Me.tb_Config.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'tb_Settings
        '
        Me.tb_Settings.Controls.Add(Me.tb_1)
        Me.tb_Settings.Controls.Add(Me.tb_2)
        Me.tb_Settings.Controls.Add(Me.tb_3)
        Me.tb_Settings.Controls.Add(Me.tb_4)
        Me.tb_Settings.Controls.Add(Me.tb_Config)
        Me.tb_Settings.Location = New System.Drawing.Point(1, 28)
        Me.tb_Settings.Name = "tb_Settings"
        Me.tb_Settings.SelectedIndex = 0
        Me.tb_Settings.Size = New System.Drawing.Size(845, 532)
        Me.tb_Settings.TabIndex = 16
        '
        'tb_1
        '
        Me.tb_1.Controls.Add(Me.btn_BrHabRasTab1)
        Me.tb_1.Controls.Add(Me.lbl_outputsTab1)
        Me.tb_1.Controls.Add(Me.lbl_InputsTab1)
        Me.tb_1.Controls.Add(Me.txt_LanduseShp)
        Me.tb_1.Controls.Add(Me.lbl_LanduseShp)
        Me.tb_1.Controls.Add(Me.btn_LanduseShp)
        Me.tb_1.Controls.Add(Me.lbl_RasterValueField)
        Me.tb_1.Controls.Add(Me.txt_RasterValueField)
        Me.tb_1.Controls.Add(Me.txt_gapcrossOld)
        Me.tb_1.Controls.Add(Me.lbl_gapcross_old)
        Me.tb_1.Controls.Add(Me.lbl_gap_cross1)
        Me.tb_1.Controls.Add(Me.lbl_luse1)
        Me.tb_1.Controls.Add(Me.lbl_InpVeg)
        Me.tb_1.Controls.Add(Me.txt_gap_cross1)
        Me.tb_1.Controls.Add(Me.txt_luse1)
        Me.tb_1.Controls.Add(Me.txt_inplh_cc1)
        Me.tb_1.Controls.Add(Me.btn_InputF)
        Me.tb_1.Controls.Add(Me.lbl_InputF)
        Me.tb_1.Controls.Add(Me.txt_InputF)
        Me.tb_1.Controls.Add(Me.Panel9)
        Me.tb_1.Controls.Add(Me.Panel8)
        Me.tb_1.Controls.Add(Me.Panel7)
        Me.tb_1.Location = New System.Drawing.Point(4, 22)
        Me.tb_1.Name = "tb_1"
        Me.tb_1.Padding = New System.Windows.Forms.Padding(3)
        Me.tb_1.Size = New System.Drawing.Size(837, 506)
        Me.tb_1.TabIndex = 5
        Me.tb_1.Text = "Default Rasters Generation"
        Me.tb_1.UseVisualStyleBackColor = True
        '
        'btn_BrHabRasTab1
        '
        Me.btn_BrHabRasTab1.Location = New System.Drawing.Point(342, 181)
        Me.btn_BrHabRasTab1.Name = "btn_BrHabRasTab1"
        Me.btn_BrHabRasTab1.Size = New System.Drawing.Size(52, 23)
        Me.btn_BrHabRasTab1.TabIndex = 53
        Me.btn_BrHabRasTab1.Text = "Browse"
        Me.btn_BrHabRasTab1.UseVisualStyleBackColor = True
        '
        'lbl_outputsTab1
        '
        Me.lbl_outputsTab1.AutoSize = True
        Me.lbl_outputsTab1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_outputsTab1.Location = New System.Drawing.Point(34, 226)
        Me.lbl_outputsTab1.Name = "lbl_outputsTab1"
        Me.lbl_outputsTab1.Size = New System.Drawing.Size(51, 13)
        Me.lbl_outputsTab1.TabIndex = 41
        Me.lbl_outputsTab1.Text = "Outputs"
        '
        'lbl_InputsTab1
        '
        Me.lbl_InputsTab1.AutoSize = True
        Me.lbl_InputsTab1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_InputsTab1.Location = New System.Drawing.Point(34, 31)
        Me.lbl_InputsTab1.Name = "lbl_InputsTab1"
        Me.lbl_InputsTab1.Size = New System.Drawing.Size(42, 13)
        Me.lbl_InputsTab1.TabIndex = 39
        Me.lbl_InputsTab1.Text = "Inputs"
        '
        'txt_LanduseShp
        '
        Me.txt_LanduseShp.Location = New System.Drawing.Point(37, 60)
        Me.txt_LanduseShp.Multiline = True
        Me.txt_LanduseShp.Name = "txt_LanduseShp"
        Me.txt_LanduseShp.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_LanduseShp.Size = New System.Drawing.Size(394, 40)
        Me.txt_LanduseShp.TabIndex = 38
        '
        'lbl_LanduseShp
        '
        Me.lbl_LanduseShp.AutoSize = True
        Me.lbl_LanduseShp.Location = New System.Drawing.Point(34, 44)
        Me.lbl_LanduseShp.Name = "lbl_LanduseShp"
        Me.lbl_LanduseShp.Size = New System.Drawing.Size(96, 13)
        Me.lbl_LanduseShp.TabIndex = 37
        Me.lbl_LanduseShp.Text = "Land-use shapefile"
        '
        'btn_LanduseShp
        '
        Me.btn_LanduseShp.Location = New System.Drawing.Point(437, 60)
        Me.btn_LanduseShp.Name = "btn_LanduseShp"
        Me.btn_LanduseShp.Size = New System.Drawing.Size(52, 23)
        Me.btn_LanduseShp.TabIndex = 36
        Me.btn_LanduseShp.Text = "Browse"
        Me.btn_LanduseShp.UseVisualStyleBackColor = True
        '
        'lbl_RasterValueField
        '
        Me.lbl_RasterValueField.AutoSize = True
        Me.lbl_RasterValueField.Location = New System.Drawing.Point(420, 165)
        Me.lbl_RasterValueField.Name = "lbl_RasterValueField"
        Me.lbl_RasterValueField.Size = New System.Drawing.Size(89, 13)
        Me.lbl_RasterValueField.TabIndex = 20
        Me.lbl_RasterValueField.Text = "Raster value field"
        '
        'txt_RasterValueField
        '
        Me.txt_RasterValueField.Location = New System.Drawing.Point(423, 181)
        Me.txt_RasterValueField.Name = "txt_RasterValueField"
        Me.txt_RasterValueField.Size = New System.Drawing.Size(100, 20)
        Me.txt_RasterValueField.TabIndex = 19
        '
        'txt_gapcrossOld
        '
        Me.txt_gapcrossOld.Location = New System.Drawing.Point(37, 422)
        Me.txt_gapcrossOld.Name = "txt_gapcrossOld"
        Me.txt_gapcrossOld.Size = New System.Drawing.Size(299, 20)
        Me.txt_gapcrossOld.TabIndex = 16
        '
        'lbl_gapcross_old
        '
        Me.lbl_gapcross_old.AutoSize = True
        Me.lbl_gapcross_old.Location = New System.Drawing.Point(34, 407)
        Me.lbl_gapcross_old.Name = "lbl_gapcross_old"
        Me.lbl_gapcross_old.Size = New System.Drawing.Size(200, 13)
        Me.lbl_gapcross_old.TabIndex = 11
        Me.lbl_gapcross_old.Text = "Gap-crossing raster (default - old method)"
        '
        'lbl_gap_cross1
        '
        Me.lbl_gap_cross1.AutoSize = True
        Me.lbl_gap_cross1.Location = New System.Drawing.Point(34, 332)
        Me.lbl_gap_cross1.Name = "lbl_gap_cross1"
        Me.lbl_gap_cross1.Size = New System.Drawing.Size(139, 13)
        Me.lbl_gap_cross1.TabIndex = 8
        Me.lbl_gap_cross1.Text = "Gap-crossing raster (default)"
        '
        'lbl_luse1
        '
        Me.lbl_luse1.AutoSize = True
        Me.lbl_luse1.Location = New System.Drawing.Point(32, 258)
        Me.lbl_luse1.Name = "lbl_luse1"
        Me.lbl_luse1.Size = New System.Drawing.Size(80, 13)
        Me.lbl_luse1.TabIndex = 7
        Me.lbl_luse1.Text = "Land use raster"
        '
        'lbl_InpVeg
        '
        Me.lbl_InpVeg.AutoSize = True
        Me.lbl_InpVeg.Location = New System.Drawing.Point(34, 165)
        Me.lbl_InpVeg.Name = "lbl_InpVeg"
        Me.lbl_InpVeg.Size = New System.Drawing.Size(144, 13)
        Me.lbl_InpVeg.TabIndex = 6
        Me.lbl_InpVeg.Text = "Input habitat raster (template)"
        '
        'txt_gap_cross1
        '
        Me.txt_gap_cross1.Location = New System.Drawing.Point(37, 348)
        Me.txt_gap_cross1.Name = "txt_gap_cross1"
        Me.txt_gap_cross1.Size = New System.Drawing.Size(299, 20)
        Me.txt_gap_cross1.TabIndex = 5
        '
        'txt_luse1
        '
        Me.txt_luse1.Location = New System.Drawing.Point(35, 274)
        Me.txt_luse1.Name = "txt_luse1"
        Me.txt_luse1.Size = New System.Drawing.Size(299, 20)
        Me.txt_luse1.TabIndex = 4
        '
        'txt_inplh_cc1
        '
        Me.txt_inplh_cc1.Location = New System.Drawing.Point(37, 181)
        Me.txt_inplh_cc1.Name = "txt_inplh_cc1"
        Me.txt_inplh_cc1.Size = New System.Drawing.Size(299, 20)
        Me.txt_inplh_cc1.TabIndex = 3
        '
        'btn_InputF
        '
        Me.btn_InputF.Location = New System.Drawing.Point(437, 122)
        Me.btn_InputF.Name = "btn_InputF"
        Me.btn_InputF.Size = New System.Drawing.Size(52, 23)
        Me.btn_InputF.TabIndex = 2
        Me.btn_InputF.Text = "Browse"
        Me.btn_InputF.UseVisualStyleBackColor = True
        '
        'lbl_InputF
        '
        Me.lbl_InputF.AutoSize = True
        Me.lbl_InputF.Location = New System.Drawing.Point(34, 106)
        Me.lbl_InputF.Name = "lbl_InputF"
        Me.lbl_InputF.Size = New System.Drawing.Size(67, 13)
        Me.lbl_InputF.TabIndex = 1
        Me.lbl_InputF.Text = "Raster folder"
        '
        'txt_InputF
        '
        Me.txt_InputF.Location = New System.Drawing.Point(37, 122)
        Me.txt_InputF.Multiline = True
        Me.txt_InputF.Name = "txt_InputF"
        Me.txt_InputF.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_InputF.Size = New System.Drawing.Size(394, 40)
        Me.txt_InputF.TabIndex = 0
        '
        'Panel9
        '
        Me.Panel9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel9.Controls.Add(Me.chk_SelDefGCO)
        Me.Panel9.Controls.Add(Me.btn_BrGcORasTab1)
        Me.Panel9.Controls.Add(Me.btn_GapCrossOld)
        Me.Panel9.Controls.Add(Me.txt_inpMultiTab1)
        Me.Panel9.Controls.Add(Me.lbl_CellMultiTab1)
        Me.Panel9.Controls.Add(Me.lbl_CreategapcrossTab1)
        Me.Panel9.Location = New System.Drawing.Point(7, 394)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(803, 66)
        Me.Panel9.TabIndex = 52
        '
        'chk_SelDefGCO
        '
        Me.chk_SelDefGCO.AutoSize = True
        Me.chk_SelDefGCO.Location = New System.Drawing.Point(559, 33)
        Me.chk_SelDefGCO.Name = "chk_SelDefGCO"
        Me.chk_SelDefGCO.Size = New System.Drawing.Size(56, 17)
        Me.chk_SelDefGCO.TabIndex = 51
        Me.chk_SelDefGCO.Text = "Select"
        Me.chk_SelDefGCO.UseVisualStyleBackColor = True
        '
        'btn_BrGcORasTab1
        '
        Me.btn_BrGcORasTab1.Location = New System.Drawing.Point(334, 26)
        Me.btn_BrGcORasTab1.Name = "btn_BrGcORasTab1"
        Me.btn_BrGcORasTab1.Size = New System.Drawing.Size(52, 23)
        Me.btn_BrGcORasTab1.TabIndex = 50
        Me.btn_BrGcORasTab1.Text = "Browse"
        Me.btn_BrGcORasTab1.UseVisualStyleBackColor = True
        '
        'btn_GapCrossOld
        '
        Me.btn_GapCrossOld.Location = New System.Drawing.Point(635, 27)
        Me.btn_GapCrossOld.Name = "btn_GapCrossOld"
        Me.btn_GapCrossOld.Size = New System.Drawing.Size(52, 23)
        Me.btn_GapCrossOld.TabIndex = 49
        Me.btn_GapCrossOld.Text = "Run"
        Me.btn_GapCrossOld.UseVisualStyleBackColor = True
        '
        'txt_inpMultiTab1
        '
        Me.txt_inpMultiTab1.Location = New System.Drawing.Point(414, 26)
        Me.txt_inpMultiTab1.Name = "txt_inpMultiTab1"
        Me.txt_inpMultiTab1.Size = New System.Drawing.Size(100, 20)
        Me.txt_inpMultiTab1.TabIndex = 42
        '
        'lbl_CellMultiTab1
        '
        Me.lbl_CellMultiTab1.AutoSize = True
        Me.lbl_CellMultiTab1.Location = New System.Drawing.Point(411, 10)
        Me.lbl_CellMultiTab1.Name = "lbl_CellMultiTab1"
        Me.lbl_CellMultiTab1.Size = New System.Drawing.Size(93, 13)
        Me.lbl_CellMultiTab1.TabIndex = 43
        Me.lbl_CellMultiTab1.Text = "Input Cell Multipler"
        '
        'lbl_CreategapcrossTab1
        '
        Me.lbl_CreategapcrossTab1.AutoSize = True
        Me.lbl_CreategapcrossTab1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_CreategapcrossTab1.Location = New System.Drawing.Point(556, 11)
        Me.lbl_CreategapcrossTab1.Name = "lbl_CreategapcrossTab1"
        Me.lbl_CreategapcrossTab1.Size = New System.Drawing.Size(240, 13)
        Me.lbl_CreategapcrossTab1.TabIndex = 46
        Me.lbl_CreategapcrossTab1.Text = "Create Gap Crossing Raster (Old method)"
        '
        'Panel8
        '
        Me.Panel8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel8.Controls.Add(Me.chk_SelDefGC)
        Me.Panel8.Controls.Add(Me.btn_BrGcRasTab1)
        Me.Panel8.Controls.Add(Me.btn_CreateGapCross)
        Me.Panel8.Controls.Add(Me.lbl_gapcrosstab1)
        Me.Panel8.Controls.Add(Me.txt_MaxDist1)
        Me.Panel8.Controls.Add(Me.lbl_MaxDist1)
        Me.Panel8.Location = New System.Drawing.Point(7, 322)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(803, 66)
        Me.Panel8.TabIndex = 51
        '
        'chk_SelDefGC
        '
        Me.chk_SelDefGC.AutoSize = True
        Me.chk_SelDefGC.Location = New System.Drawing.Point(559, 29)
        Me.chk_SelDefGC.Name = "chk_SelDefGC"
        Me.chk_SelDefGC.Size = New System.Drawing.Size(56, 17)
        Me.chk_SelDefGC.TabIndex = 50
        Me.chk_SelDefGC.Text = "Select"
        Me.chk_SelDefGC.UseVisualStyleBackColor = True
        '
        'btn_BrGcRasTab1
        '
        Me.btn_BrGcRasTab1.Location = New System.Drawing.Point(333, 23)
        Me.btn_BrGcRasTab1.Name = "btn_BrGcRasTab1"
        Me.btn_BrGcRasTab1.Size = New System.Drawing.Size(52, 23)
        Me.btn_BrGcRasTab1.TabIndex = 49
        Me.btn_BrGcRasTab1.Text = "Browse"
        Me.btn_BrGcRasTab1.UseVisualStyleBackColor = True
        '
        'btn_CreateGapCross
        '
        Me.btn_CreateGapCross.Location = New System.Drawing.Point(635, 23)
        Me.btn_CreateGapCross.Name = "btn_CreateGapCross"
        Me.btn_CreateGapCross.Size = New System.Drawing.Size(52, 23)
        Me.btn_CreateGapCross.TabIndex = 48
        Me.btn_CreateGapCross.Text = "Run"
        Me.btn_CreateGapCross.UseVisualStyleBackColor = True
        '
        'lbl_gapcrosstab1
        '
        Me.lbl_gapcrosstab1.AutoSize = True
        Me.lbl_gapcrosstab1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_gapcrosstab1.Location = New System.Drawing.Point(556, 7)
        Me.lbl_gapcrosstab1.Name = "lbl_gapcrosstab1"
        Me.lbl_gapcrosstab1.Size = New System.Drawing.Size(164, 13)
        Me.lbl_gapcrosstab1.TabIndex = 45
        Me.lbl_gapcrosstab1.Text = "Create Gap Crossing Raster"
        '
        'txt_MaxDist1
        '
        Me.txt_MaxDist1.Location = New System.Drawing.Point(414, 24)
        Me.txt_MaxDist1.Name = "txt_MaxDist1"
        Me.txt_MaxDist1.Size = New System.Drawing.Size(100, 20)
        Me.txt_MaxDist1.TabIndex = 17
        '
        'lbl_MaxDist1
        '
        Me.lbl_MaxDist1.AutoSize = True
        Me.lbl_MaxDist1.Location = New System.Drawing.Point(411, 7)
        Me.lbl_MaxDist1.Name = "lbl_MaxDist1"
        Me.lbl_MaxDist1.Size = New System.Drawing.Size(94, 13)
        Me.lbl_MaxDist1.TabIndex = 18
        Me.lbl_MaxDist1.Text = "Maximum distance"
        '
        'Panel7
        '
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel7.Controls.Add(Me.chk_SelDefL)
        Me.Panel7.Controls.Add(Me.btn_BrLuRasTab1)
        Me.Panel7.Controls.Add(Me.btn_RunConvLusetoRaster)
        Me.Panel7.Controls.Add(Me.lbl_luseToRasterTab1)
        Me.Panel7.Location = New System.Drawing.Point(7, 250)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(803, 66)
        Me.Panel7.TabIndex = 50
        '
        'chk_SelDefL
        '
        Me.chk_SelDefL.AutoSize = True
        Me.chk_SelDefL.Location = New System.Drawing.Point(559, 28)
        Me.chk_SelDefL.Name = "chk_SelDefL"
        Me.chk_SelDefL.Size = New System.Drawing.Size(56, 17)
        Me.chk_SelDefL.TabIndex = 49
        Me.chk_SelDefL.Text = "Select"
        Me.chk_SelDefL.UseVisualStyleBackColor = True
        '
        'btn_BrLuRasTab1
        '
        Me.btn_BrLuRasTab1.Location = New System.Drawing.Point(333, 22)
        Me.btn_BrLuRasTab1.Name = "btn_BrLuRasTab1"
        Me.btn_BrLuRasTab1.Size = New System.Drawing.Size(52, 23)
        Me.btn_BrLuRasTab1.TabIndex = 48
        Me.btn_BrLuRasTab1.Text = "Browse"
        Me.btn_BrLuRasTab1.UseVisualStyleBackColor = True
        '
        'btn_RunConvLusetoRaster
        '
        Me.btn_RunConvLusetoRaster.Location = New System.Drawing.Point(635, 22)
        Me.btn_RunConvLusetoRaster.Name = "btn_RunConvLusetoRaster"
        Me.btn_RunConvLusetoRaster.Size = New System.Drawing.Size(52, 23)
        Me.btn_RunConvLusetoRaster.TabIndex = 47
        Me.btn_RunConvLusetoRaster.Text = "Run"
        Me.btn_RunConvLusetoRaster.UseVisualStyleBackColor = True
        '
        'lbl_luseToRasterTab1
        '
        Me.lbl_luseToRasterTab1.AutoSize = True
        Me.lbl_luseToRasterTab1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_luseToRasterTab1.Location = New System.Drawing.Point(556, 6)
        Me.lbl_luseToRasterTab1.Name = "lbl_luseToRasterTab1"
        Me.lbl_luseToRasterTab1.Size = New System.Drawing.Size(154, 13)
        Me.lbl_luseToRasterTab1.TabIndex = 44
        Me.lbl_luseToRasterTab1.Text = "Convert land use to raster"
        '
        'tb_2
        '
        Me.tb_2.Controls.Add(Me.lbl_hydrolRasVal2)
        Me.tb_2.Controls.Add(Me.txt_HydrolVal2)
        Me.tb_2.Controls.Add(Me.lbl_infrastructure)
        Me.tb_2.Controls.Add(Me.txt_infrastructure)
        Me.tb_2.Controls.Add(Me.lbl_HydrolVal1)
        Me.tb_2.Controls.Add(Me.txt_HydrolVal1)
        Me.tb_2.Controls.Add(Me.lbl_NewRasAdd)
        Me.tb_2.Controls.Add(Me.txt_NewRastAdd)
        Me.tb_2.Controls.Add(Me.lbl_NewVegRemove)
        Me.tb_2.Controls.Add(Me.txt_NewRasterRemv)
        Me.tb_2.Controls.Add(Me.lbl_RasValFld_Tab2)
        Me.tb_2.Controls.Add(Me.txt_RasValFldTab2)
        Me.tb_2.Controls.Add(Me.lbl_CellMultip2)
        Me.tb_2.Controls.Add(Me.txt_CellMultip2)
        Me.tb_2.Controls.Add(Me.txt_ChangerasterTab2)
        Me.tb_2.Controls.Add(Me.txt_ChngLyrShpTab2)
        Me.tb_2.Controls.Add(Me.lbl_changeLyrShpTab2)
        Me.tb_2.Controls.Add(Me.lbl_changerasterTab2)
        Me.tb_2.Controls.Add(Me.btn_browseChngShpTab2)
        Me.tb_2.Controls.Add(Me.lbl_gapcrossTab2)
        Me.tb_2.Controls.Add(Me.lbl_landuseTab2)
        Me.tb_2.Controls.Add(Me.lbl_habitatTab2)
        Me.tb_2.Controls.Add(Me.txt_GapcrossTab2)
        Me.tb_2.Controls.Add(Me.txt_landuseTab2)
        Me.tb_2.Controls.Add(Me.txt_habitatTab2)
        Me.tb_2.Controls.Add(Me.btn_browse_RasFolderTab2)
        Me.tb_2.Controls.Add(Me.lbl_RasterFoldertab2)
        Me.tb_2.Controls.Add(Me.txt_rasterFolderTab2)
        Me.tb_2.Controls.Add(Me.Panel2)
        Me.tb_2.Controls.Add(Me.Panel3)
        Me.tb_2.Controls.Add(Me.Panel4)
        Me.tb_2.Controls.Add(Me.Panel5)
        Me.tb_2.Controls.Add(Me.Panel6)
        Me.tb_2.Location = New System.Drawing.Point(4, 22)
        Me.tb_2.Name = "tb_2"
        Me.tb_2.Padding = New System.Windows.Forms.Padding(3)
        Me.tb_2.Size = New System.Drawing.Size(837, 506)
        Me.tb_2.TabIndex = 6
        Me.tb_2.Text = "Scenario Options Processing"
        Me.tb_2.UseVisualStyleBackColor = True
        '
        'lbl_hydrolRasVal2
        '
        Me.lbl_hydrolRasVal2.AutoSize = True
        Me.lbl_hydrolRasVal2.Location = New System.Drawing.Point(396, 456)
        Me.lbl_hydrolRasVal2.Name = "lbl_hydrolRasVal2"
        Me.lbl_hydrolRasVal2.Size = New System.Drawing.Size(112, 13)
        Me.lbl_hydrolRasVal2.TabIndex = 53
        Me.lbl_hydrolRasVal2.Text = "Hydrology raster value"
        '
        'txt_HydrolVal2
        '
        Me.txt_HydrolVal2.Location = New System.Drawing.Point(399, 472)
        Me.txt_HydrolVal2.Name = "txt_HydrolVal2"
        Me.txt_HydrolVal2.Size = New System.Drawing.Size(100, 20)
        Me.txt_HydrolVal2.TabIndex = 52
        '
        'lbl_infrastructure
        '
        Me.lbl_infrastructure.AutoSize = True
        Me.lbl_infrastructure.Location = New System.Drawing.Point(33, 456)
        Me.lbl_infrastructure.Name = "lbl_infrastructure"
        Me.lbl_infrastructure.Size = New System.Drawing.Size(189, 13)
        Me.lbl_infrastructure.TabIndex = 51
        Me.lbl_infrastructure.Text = "Modified land use raster - infrastructure"
        '
        'txt_infrastructure
        '
        Me.txt_infrastructure.Location = New System.Drawing.Point(33, 472)
        Me.txt_infrastructure.Name = "txt_infrastructure"
        Me.txt_infrastructure.Size = New System.Drawing.Size(299, 20)
        Me.txt_infrastructure.TabIndex = 50
        '
        'lbl_HydrolVal1
        '
        Me.lbl_HydrolVal1.AutoSize = True
        Me.lbl_HydrolVal1.Location = New System.Drawing.Point(396, 348)
        Me.lbl_HydrolVal1.Name = "lbl_HydrolVal1"
        Me.lbl_HydrolVal1.Size = New System.Drawing.Size(112, 13)
        Me.lbl_HydrolVal1.TabIndex = 49
        Me.lbl_HydrolVal1.Text = "Hydrology raster value"
        '
        'txt_HydrolVal1
        '
        Me.txt_HydrolVal1.Location = New System.Drawing.Point(399, 364)
        Me.txt_HydrolVal1.Name = "txt_HydrolVal1"
        Me.txt_HydrolVal1.Size = New System.Drawing.Size(100, 20)
        Me.txt_HydrolVal1.TabIndex = 48
        '
        'lbl_NewRasAdd
        '
        Me.lbl_NewRasAdd.AutoSize = True
        Me.lbl_NewRasAdd.Location = New System.Drawing.Point(33, 348)
        Me.lbl_NewRasAdd.Name = "lbl_NewRasAdd"
        Me.lbl_NewRasAdd.Size = New System.Drawing.Size(139, 13)
        Me.lbl_NewRasAdd.TabIndex = 47
        Me.lbl_NewRasAdd.Text = "New habitat raster - addition"
        '
        'txt_NewRastAdd
        '
        Me.txt_NewRastAdd.Location = New System.Drawing.Point(33, 364)
        Me.txt_NewRastAdd.Name = "txt_NewRastAdd"
        Me.txt_NewRastAdd.Size = New System.Drawing.Size(299, 20)
        Me.txt_NewRastAdd.TabIndex = 46
        '
        'lbl_NewVegRemove
        '
        Me.lbl_NewVegRemove.AutoSize = True
        Me.lbl_NewVegRemove.Location = New System.Drawing.Point(33, 297)
        Me.lbl_NewVegRemove.Name = "lbl_NewVegRemove"
        Me.lbl_NewVegRemove.Size = New System.Drawing.Size(139, 13)
        Me.lbl_NewVegRemove.TabIndex = 45
        Me.lbl_NewVegRemove.Text = "New habitat raster - removal"
        '
        'txt_NewRasterRemv
        '
        Me.txt_NewRasterRemv.Location = New System.Drawing.Point(33, 310)
        Me.txt_NewRasterRemv.Name = "txt_NewRasterRemv"
        Me.txt_NewRasterRemv.Size = New System.Drawing.Size(299, 20)
        Me.txt_NewRasterRemv.TabIndex = 44
        '
        'lbl_RasValFld_Tab2
        '
        Me.lbl_RasValFld_Tab2.AutoSize = True
        Me.lbl_RasValFld_Tab2.Location = New System.Drawing.Point(396, 240)
        Me.lbl_RasValFld_Tab2.Name = "lbl_RasValFld_Tab2"
        Me.lbl_RasValFld_Tab2.Size = New System.Drawing.Size(89, 13)
        Me.lbl_RasValFld_Tab2.TabIndex = 43
        Me.lbl_RasValFld_Tab2.Text = "Raster value field"
        '
        'txt_RasValFldTab2
        '
        Me.txt_RasValFldTab2.Location = New System.Drawing.Point(399, 256)
        Me.txt_RasValFldTab2.Name = "txt_RasValFldTab2"
        Me.txt_RasValFldTab2.Size = New System.Drawing.Size(100, 20)
        Me.txt_RasValFldTab2.TabIndex = 42
        '
        'lbl_CellMultip2
        '
        Me.lbl_CellMultip2.AutoSize = True
        Me.lbl_CellMultip2.Location = New System.Drawing.Point(396, 403)
        Me.lbl_CellMultip2.Name = "lbl_CellMultip2"
        Me.lbl_CellMultip2.Size = New System.Drawing.Size(67, 13)
        Me.lbl_CellMultip2.TabIndex = 39
        Me.lbl_CellMultip2.Text = "Cell multiplier"
        '
        'txt_CellMultip2
        '
        Me.txt_CellMultip2.Location = New System.Drawing.Point(399, 419)
        Me.txt_CellMultip2.Name = "txt_CellMultip2"
        Me.txt_CellMultip2.Size = New System.Drawing.Size(100, 20)
        Me.txt_CellMultip2.TabIndex = 38
        '
        'txt_ChangerasterTab2
        '
        Me.txt_ChangerasterTab2.Location = New System.Drawing.Point(33, 256)
        Me.txt_ChangerasterTab2.Name = "txt_ChangerasterTab2"
        Me.txt_ChangerasterTab2.Size = New System.Drawing.Size(299, 20)
        Me.txt_ChangerasterTab2.TabIndex = 37
        '
        'txt_ChngLyrShpTab2
        '
        Me.txt_ChngLyrShpTab2.Location = New System.Drawing.Point(33, 39)
        Me.txt_ChngLyrShpTab2.Multiline = True
        Me.txt_ChngLyrShpTab2.Name = "txt_ChngLyrShpTab2"
        Me.txt_ChngLyrShpTab2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_ChngLyrShpTab2.Size = New System.Drawing.Size(394, 40)
        Me.txt_ChngLyrShpTab2.TabIndex = 35
        '
        'lbl_changeLyrShpTab2
        '
        Me.lbl_changeLyrShpTab2.AutoSize = True
        Me.lbl_changeLyrShpTab2.Location = New System.Drawing.Point(31, 23)
        Me.lbl_changeLyrShpTab2.Name = "lbl_changeLyrShpTab2"
        Me.lbl_changeLyrShpTab2.Size = New System.Drawing.Size(114, 13)
        Me.lbl_changeLyrShpTab2.TabIndex = 33
        Me.lbl_changeLyrShpTab2.Text = "Change layer shapefile"
        '
        'lbl_changerasterTab2
        '
        Me.lbl_changerasterTab2.AutoSize = True
        Me.lbl_changerasterTab2.Location = New System.Drawing.Point(31, 240)
        Me.lbl_changerasterTab2.Name = "lbl_changerasterTab2"
        Me.lbl_changerasterTab2.Size = New System.Drawing.Size(73, 13)
        Me.lbl_changerasterTab2.TabIndex = 32
        Me.lbl_changerasterTab2.Text = "Change raster"
        '
        'btn_browseChngShpTab2
        '
        Me.btn_browseChngShpTab2.Location = New System.Drawing.Point(433, 39)
        Me.btn_browseChngShpTab2.Name = "btn_browseChngShpTab2"
        Me.btn_browseChngShpTab2.Size = New System.Drawing.Size(52, 23)
        Me.btn_browseChngShpTab2.TabIndex = 30
        Me.btn_browseChngShpTab2.Text = "Browse"
        Me.btn_browseChngShpTab2.UseVisualStyleBackColor = True
        '
        'lbl_gapcrossTab2
        '
        Me.lbl_gapcrossTab2.AutoSize = True
        Me.lbl_gapcrossTab2.Location = New System.Drawing.Point(33, 403)
        Me.lbl_gapcrossTab2.Name = "lbl_gapcrossTab2"
        Me.lbl_gapcrossTab2.Size = New System.Drawing.Size(147, 13)
        Me.lbl_gapcrossTab2.TabIndex = 29
        Me.lbl_gapcrossTab2.Text = "Gap-crossing raster (scenario)"
        '
        'lbl_landuseTab2
        '
        Me.lbl_landuseTab2.AutoSize = True
        Me.lbl_landuseTab2.Location = New System.Drawing.Point(31, 181)
        Me.lbl_landuseTab2.Name = "lbl_landuseTab2"
        Me.lbl_landuseTab2.Size = New System.Drawing.Size(80, 13)
        Me.lbl_landuseTab2.TabIndex = 28
        Me.lbl_landuseTab2.Text = "Land use raster"
        '
        'lbl_habitatTab2
        '
        Me.lbl_habitatTab2.AutoSize = True
        Me.lbl_habitatTab2.Location = New System.Drawing.Point(31, 142)
        Me.lbl_habitatTab2.Name = "lbl_habitatTab2"
        Me.lbl_habitatTab2.Size = New System.Drawing.Size(144, 13)
        Me.lbl_habitatTab2.TabIndex = 27
        Me.lbl_habitatTab2.Text = "Input habitat raster (template)"
        '
        'txt_GapcrossTab2
        '
        Me.txt_GapcrossTab2.Location = New System.Drawing.Point(33, 418)
        Me.txt_GapcrossTab2.Name = "txt_GapcrossTab2"
        Me.txt_GapcrossTab2.Size = New System.Drawing.Size(299, 20)
        Me.txt_GapcrossTab2.TabIndex = 26
        '
        'txt_landuseTab2
        '
        Me.txt_landuseTab2.Location = New System.Drawing.Point(33, 197)
        Me.txt_landuseTab2.Name = "txt_landuseTab2"
        Me.txt_landuseTab2.Size = New System.Drawing.Size(299, 20)
        Me.txt_landuseTab2.TabIndex = 25
        '
        'txt_habitatTab2
        '
        Me.txt_habitatTab2.Location = New System.Drawing.Point(33, 158)
        Me.txt_habitatTab2.Name = "txt_habitatTab2"
        Me.txt_habitatTab2.Size = New System.Drawing.Size(299, 20)
        Me.txt_habitatTab2.TabIndex = 24
        '
        'btn_browse_RasFolderTab2
        '
        Me.btn_browse_RasFolderTab2.Location = New System.Drawing.Point(433, 99)
        Me.btn_browse_RasFolderTab2.Name = "btn_browse_RasFolderTab2"
        Me.btn_browse_RasFolderTab2.Size = New System.Drawing.Size(52, 23)
        Me.btn_browse_RasFolderTab2.TabIndex = 23
        Me.btn_browse_RasFolderTab2.Text = "Browse"
        Me.btn_browse_RasFolderTab2.UseVisualStyleBackColor = True
        Me.btn_browse_RasFolderTab2.Visible = False
        '
        'lbl_RasterFoldertab2
        '
        Me.lbl_RasterFoldertab2.AutoSize = True
        Me.lbl_RasterFoldertab2.Location = New System.Drawing.Point(31, 83)
        Me.lbl_RasterFoldertab2.Name = "lbl_RasterFoldertab2"
        Me.lbl_RasterFoldertab2.Size = New System.Drawing.Size(67, 13)
        Me.lbl_RasterFoldertab2.TabIndex = 22
        Me.lbl_RasterFoldertab2.Text = "Raster folder"
        '
        'txt_rasterFolderTab2
        '
        Me.txt_rasterFolderTab2.Location = New System.Drawing.Point(33, 99)
        Me.txt_rasterFolderTab2.Multiline = True
        Me.txt_rasterFolderTab2.Name = "txt_rasterFolderTab2"
        Me.txt_rasterFolderTab2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_rasterFolderTab2.Size = New System.Drawing.Size(394, 40)
        Me.txt_rasterFolderTab2.TabIndex = 21
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.btn_BrChTab2)
        Me.Panel2.Controls.Add(Me.chk_selS1)
        Me.Panel2.Controls.Add(Me.btn_RunScen1)
        Me.Panel2.Controls.Add(Me.lbl_run1txt)
        Me.Panel2.Controls.Add(Me.Label18)
        Me.Panel2.Controls.Add(Me.Label19)
        Me.Panel2.Location = New System.Drawing.Point(7, 235)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(830, 48)
        Me.Panel2.TabIndex = 73
        '
        'btn_BrChTab2
        '
        Me.btn_BrChTab2.Location = New System.Drawing.Point(330, 17)
        Me.btn_BrChTab2.Name = "btn_BrChTab2"
        Me.btn_BrChTab2.Size = New System.Drawing.Size(52, 23)
        Me.btn_BrChTab2.TabIndex = 68
        Me.btn_BrChTab2.Text = "Browse"
        Me.btn_BrChTab2.UseVisualStyleBackColor = True
        '
        'chk_selS1
        '
        Me.chk_selS1.AutoSize = True
        Me.chk_selS1.Location = New System.Drawing.Point(514, 23)
        Me.chk_selS1.Name = "chk_selS1"
        Me.chk_selS1.Size = New System.Drawing.Size(56, 17)
        Me.chk_selS1.TabIndex = 67
        Me.chk_selS1.Text = "Select"
        Me.chk_selS1.UseVisualStyleBackColor = True
        '
        'btn_RunScen1
        '
        Me.btn_RunScen1.Location = New System.Drawing.Point(576, 18)
        Me.btn_RunScen1.Name = "btn_RunScen1"
        Me.btn_RunScen1.Size = New System.Drawing.Size(52, 23)
        Me.btn_RunScen1.TabIndex = 55
        Me.btn_RunScen1.Text = "Run"
        Me.btn_RunScen1.UseVisualStyleBackColor = True
        '
        'lbl_run1txt
        '
        Me.lbl_run1txt.AutoSize = True
        Me.lbl_run1txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_run1txt.Location = New System.Drawing.Point(511, 4)
        Me.lbl_run1txt.Name = "lbl_run1txt"
        Me.lbl_run1txt.Size = New System.Drawing.Size(141, 13)
        Me.lbl_run1txt.TabIndex = 60
        Me.lbl_run1txt.Text = "1. Create change raster"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(634, 17)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(156, 13)
        Me.Label18.TabIndex = 65
        Me.Label18.Text = "Requires habitat template raster"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(634, 30)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(116, 13)
        Me.Label19.TabIndex = 66
        Me.Label19.Text = "and  land-use shapefile"
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.btn_BrRemTab2)
        Me.Panel3.Controls.Add(Me.chk_selS2a)
        Me.Panel3.Controls.Add(Me.Label20)
        Me.Panel3.Controls.Add(Me.Label22)
        Me.Panel3.Controls.Add(Me.lbl_run2atext)
        Me.Panel3.Controls.Add(Me.btn_RunScen2a)
        Me.Panel3.Location = New System.Drawing.Point(7, 286)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(830, 51)
        Me.Panel3.TabIndex = 74
        '
        'btn_BrRemTab2
        '
        Me.btn_BrRemTab2.Location = New System.Drawing.Point(330, 22)
        Me.btn_BrRemTab2.Name = "btn_BrRemTab2"
        Me.btn_BrRemTab2.Size = New System.Drawing.Size(52, 23)
        Me.btn_BrRemTab2.TabIndex = 71
        Me.btn_BrRemTab2.Text = "Browse"
        Me.btn_BrRemTab2.UseVisualStyleBackColor = True
        '
        'chk_selS2a
        '
        Me.chk_selS2a.AutoSize = True
        Me.chk_selS2a.Location = New System.Drawing.Point(514, 24)
        Me.chk_selS2a.Name = "chk_selS2a"
        Me.chk_selS2a.Size = New System.Drawing.Size(56, 17)
        Me.chk_selS2a.TabIndex = 70
        Me.chk_selS2a.Text = "Select"
        Me.chk_selS2a.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(634, 19)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(156, 13)
        Me.Label20.TabIndex = 67
        Me.Label20.Text = "Requires habitat template raster"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(634, 33)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(96, 13)
        Me.Label22.TabIndex = 69
        Me.Label22.Text = "and  change raster"
        '
        'lbl_run2atext
        '
        Me.lbl_run2atext.AutoSize = True
        Me.lbl_run2atext.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_run2atext.Location = New System.Drawing.Point(511, 6)
        Me.lbl_run2atext.Name = "lbl_run2atext"
        Me.lbl_run2atext.Size = New System.Drawing.Size(227, 13)
        Me.lbl_run2atext.TabIndex = 61
        Me.lbl_run2atext.Text = "2a. Modify vegetation raster - Removal"
        '
        'btn_RunScen2a
        '
        Me.btn_RunScen2a.Location = New System.Drawing.Point(576, 19)
        Me.btn_RunScen2a.Name = "btn_RunScen2a"
        Me.btn_RunScen2a.Size = New System.Drawing.Size(52, 23)
        Me.btn_RunScen2a.TabIndex = 56
        Me.btn_RunScen2a.Text = "Run"
        Me.btn_RunScen2a.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel4.Controls.Add(Me.btn_BrAddTab2)
        Me.Panel4.Controls.Add(Me.chk_sel2b)
        Me.Panel4.Controls.Add(Me.Label23)
        Me.Panel4.Controls.Add(Me.Label21)
        Me.Panel4.Controls.Add(Me.lbl_run2btext)
        Me.Panel4.Controls.Add(Me.btn_RunScen2b)
        Me.Panel4.Location = New System.Drawing.Point(7, 340)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(830, 51)
        Me.Panel4.TabIndex = 75
        '
        'btn_BrAddTab2
        '
        Me.btn_BrAddTab2.Location = New System.Drawing.Point(330, 22)
        Me.btn_BrAddTab2.Name = "btn_BrAddTab2"
        Me.btn_BrAddTab2.Size = New System.Drawing.Size(52, 23)
        Me.btn_BrAddTab2.TabIndex = 72
        Me.btn_BrAddTab2.Text = "Browse"
        Me.btn_BrAddTab2.UseVisualStyleBackColor = True
        '
        'chk_sel2b
        '
        Me.chk_sel2b.AutoSize = True
        Me.chk_sel2b.Location = New System.Drawing.Point(514, 24)
        Me.chk_sel2b.Name = "chk_sel2b"
        Me.chk_sel2b.Size = New System.Drawing.Size(56, 17)
        Me.chk_sel2b.TabIndex = 71
        Me.chk_sel2b.Text = "Select"
        Me.chk_sel2b.UseVisualStyleBackColor = True
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(634, 34)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(141, 13)
        Me.Label23.TabIndex = 70
        Me.Label23.Text = "land use and change rasters"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(634, 19)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(159, 13)
        Me.Label21.TabIndex = 68
        Me.Label21.Text = "Requires habitat template raster,"
        '
        'lbl_run2btext
        '
        Me.lbl_run2btext.AutoSize = True
        Me.lbl_run2btext.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_run2btext.Location = New System.Drawing.Point(511, 6)
        Me.lbl_run2btext.Name = "lbl_run2btext"
        Me.lbl_run2btext.Size = New System.Drawing.Size(224, 13)
        Me.lbl_run2btext.TabIndex = 62
        Me.lbl_run2btext.Text = "2b. Modify vegetation raster - Addition"
        '
        'btn_RunScen2b
        '
        Me.btn_RunScen2b.Location = New System.Drawing.Point(576, 19)
        Me.btn_RunScen2b.Name = "btn_RunScen2b"
        Me.btn_RunScen2b.Size = New System.Drawing.Size(52, 23)
        Me.btn_RunScen2b.TabIndex = 57
        Me.btn_RunScen2b.Text = "Run"
        Me.btn_RunScen2b.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel5.Controls.Add(Me.btn_BrGCTab2)
        Me.Panel5.Controls.Add(Me.chk_sel3)
        Me.Panel5.Controls.Add(Me.Label24)
        Me.Panel5.Controls.Add(Me.lbl_run3text)
        Me.Panel5.Controls.Add(Me.btn_RunScen3)
        Me.Panel5.Location = New System.Drawing.Point(7, 394)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(830, 51)
        Me.Panel5.TabIndex = 76
        '
        'btn_BrGCTab2
        '
        Me.btn_BrGCTab2.Location = New System.Drawing.Point(330, 22)
        Me.btn_BrGCTab2.Name = "btn_BrGCTab2"
        Me.btn_BrGCTab2.Size = New System.Drawing.Size(52, 23)
        Me.btn_BrGCTab2.TabIndex = 73
        Me.btn_BrGCTab2.Text = "Browse"
        Me.btn_BrGCTab2.UseVisualStyleBackColor = True
        '
        'chk_sel3
        '
        Me.chk_sel3.AutoSize = True
        Me.chk_sel3.Location = New System.Drawing.Point(514, 28)
        Me.chk_sel3.Name = "chk_sel3"
        Me.chk_sel3.Size = New System.Drawing.Size(56, 17)
        Me.chk_sel3.TabIndex = 72
        Me.chk_sel3.Text = "Select"
        Me.chk_sel3.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(634, 19)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(159, 13)
        Me.Label24.TabIndex = 71
        Me.Label24.Text = "Requires habitat (removal) raster"
        '
        'lbl_run3text
        '
        Me.lbl_run3text.AutoSize = True
        Me.lbl_run3text.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_run3text.Location = New System.Drawing.Point(511, 7)
        Me.lbl_run3text.Name = "lbl_run3text"
        Me.lbl_run3text.Size = New System.Drawing.Size(171, 13)
        Me.lbl_run3text.TabIndex = 63
        Me.lbl_run3text.Text = "3. Create gap crossing raster"
        '
        'btn_RunScen3
        '
        Me.btn_RunScen3.Location = New System.Drawing.Point(576, 23)
        Me.btn_RunScen3.Name = "btn_RunScen3"
        Me.btn_RunScen3.Size = New System.Drawing.Size(52, 23)
        Me.btn_RunScen3.TabIndex = 58
        Me.btn_RunScen3.Text = "Run"
        Me.btn_RunScen3.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel6.Controls.Add(Me.btn_BrInfTab2)
        Me.Panel6.Controls.Add(Me.chk_selS4)
        Me.Panel6.Controls.Add(Me.Label25)
        Me.Panel6.Controls.Add(Me.lbl_Run4text)
        Me.Panel6.Controls.Add(Me.btn_RunScen4)
        Me.Panel6.Location = New System.Drawing.Point(7, 448)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(830, 51)
        Me.Panel6.TabIndex = 77
        '
        'btn_BrInfTab2
        '
        Me.btn_BrInfTab2.Location = New System.Drawing.Point(330, 22)
        Me.btn_BrInfTab2.Name = "btn_BrInfTab2"
        Me.btn_BrInfTab2.Size = New System.Drawing.Size(52, 23)
        Me.btn_BrInfTab2.TabIndex = 74
        Me.btn_BrInfTab2.Text = "Browse"
        Me.btn_BrInfTab2.UseVisualStyleBackColor = True
        '
        'chk_selS4
        '
        Me.chk_selS4.AutoSize = True
        Me.chk_selS4.Location = New System.Drawing.Point(514, 25)
        Me.chk_selS4.Name = "chk_selS4"
        Me.chk_selS4.Size = New System.Drawing.Size(56, 17)
        Me.chk_selS4.TabIndex = 73
        Me.chk_selS4.Text = "Select"
        Me.chk_selS4.UseVisualStyleBackColor = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(634, 19)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(186, 13)
        Me.Label25.TabIndex = 72
        Me.Label25.Text = "Requires land use and change rasters"
        '
        'lbl_Run4text
        '
        Me.lbl_Run4text.AutoSize = True
        Me.lbl_Run4text.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Run4text.Location = New System.Drawing.Point(511, 6)
        Me.lbl_Run4text.Name = "lbl_Run4text"
        Me.lbl_Run4text.Size = New System.Drawing.Size(235, 13)
        Me.lbl_Run4text.TabIndex = 64
        Me.lbl_Run4text.Text = "4. Modify land use raster - Infrastructure"
        '
        'btn_RunScen4
        '
        Me.btn_RunScen4.Location = New System.Drawing.Point(576, 19)
        Me.btn_RunScen4.Name = "btn_RunScen4"
        Me.btn_RunScen4.Size = New System.Drawing.Size(52, 23)
        Me.btn_RunScen4.TabIndex = 59
        Me.btn_RunScen4.Text = "Run"
        Me.btn_RunScen4.UseVisualStyleBackColor = True
        '
        'tb_3
        '
        Me.tb_3.Controls.Add(Me.Label3)
        Me.tb_3.Controls.Add(Me.Label2)
        Me.tb_3.Controls.Add(Me.Label1)
        Me.tb_3.Controls.Add(Me.cbo_SelectLanduseRaster)
        Me.tb_3.Controls.Add(Me.cbo_SelectGapcrossRaster)
        Me.tb_3.Controls.Add(Me.lbl_ProcessRasters_tab3)
        Me.tb_3.Controls.Add(Me.btn_Run_GC)
        Me.tb_3.Controls.Add(Me.cbo_SelectVegRaster)
        Me.tb_3.Controls.Add(Me.btn_OutputF)
        Me.tb_3.Controls.Add(Me.lbl_OutputF)
        Me.tb_3.Controls.Add(Me.txt_OutputF)
        Me.tb_3.Controls.Add(Me.btn_ReclTextFile)
        Me.tb_3.Controls.Add(Me.lbl_parameters)
        Me.tb_3.Controls.Add(Me.lbl_SelRootDir)
        Me.tb_3.Controls.Add(Me.lbl_ReclassTxtFile)
        Me.tb_3.Controls.Add(Me.btn_RootDir)
        Me.tb_3.Controls.Add(Me.btn_ClearAll)
        Me.tb_3.Controls.Add(Me.txt_SelRootDir)
        Me.tb_3.Controls.Add(Me.txt_ReclassTxtFile)
        Me.tb_3.Controls.Add(Me.lbl_OrigPixelSize)
        Me.tb_3.Controls.Add(Me.lbl_NewPixelSize)
        Me.tb_3.Controls.Add(Me.txt_inp_luse)
        Me.tb_3.Controls.Add(Me.txt_inp_gc)
        Me.tb_3.Controls.Add(Me.txt_inp_cc)
        Me.tb_3.Controls.Add(Me.lbl_MaxCost)
        Me.tb_3.Controls.Add(Me.lbl_inp_luse)
        Me.tb_3.Controls.Add(Me.lbl_MaxDist)
        Me.tb_3.Controls.Add(Me.lbl_inp_gc)
        Me.tb_3.Controls.Add(Me.lbl_inp_cc)
        Me.tb_3.Controls.Add(Me.txt_OriginalPixelSize)
        Me.tb_3.Controls.Add(Me.txt_MaxDist)
        Me.tb_3.Controls.Add(Me.txt_NewPixelSize)
        Me.tb_3.Controls.Add(Me.txt_MaxCost)
        Me.tb_3.Location = New System.Drawing.Point(4, 22)
        Me.tb_3.Name = "tb_3"
        Me.tb_3.Padding = New System.Windows.Forms.Padding(3)
        Me.tb_3.Size = New System.Drawing.Size(837, 506)
        Me.tb_3.TabIndex = 0
        Me.tb_3.Text = "Process Rasters for Model"
        Me.tb_3.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(343, 198)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(115, 13)
        Me.Label3.TabIndex = 51
        Me.Label3.Text = "Choose land use raster"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(343, 159)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(135, 13)
        Me.Label2.TabIndex = 50
        Me.Label2.Text = "Choose gap-crossing raster"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(343, 115)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(107, 13)
        Me.Label1.TabIndex = 49
        Me.Label1.Text = "Choose habitat raster"
        '
        'cbo_SelectLanduseRaster
        '
        Me.cbo_SelectLanduseRaster.FormattingEnabled = True
        Me.cbo_SelectLanduseRaster.Location = New System.Drawing.Point(343, 214)
        Me.cbo_SelectLanduseRaster.Name = "cbo_SelectLanduseRaster"
        Me.cbo_SelectLanduseRaster.Size = New System.Drawing.Size(165, 21)
        Me.cbo_SelectLanduseRaster.TabIndex = 48
        '
        'cbo_SelectGapcrossRaster
        '
        Me.cbo_SelectGapcrossRaster.FormattingEnabled = True
        Me.cbo_SelectGapcrossRaster.Location = New System.Drawing.Point(343, 175)
        Me.cbo_SelectGapcrossRaster.Name = "cbo_SelectGapcrossRaster"
        Me.cbo_SelectGapcrossRaster.Size = New System.Drawing.Size(165, 21)
        Me.cbo_SelectGapcrossRaster.TabIndex = 47
        '
        'lbl_ProcessRasters_tab3
        '
        Me.lbl_ProcessRasters_tab3.AutoSize = True
        Me.lbl_ProcessRasters_tab3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ProcessRasters_tab3.Location = New System.Drawing.Point(22, 404)
        Me.lbl_ProcessRasters_tab3.Name = "lbl_ProcessRasters_tab3"
        Me.lbl_ProcessRasters_tab3.Size = New System.Drawing.Size(150, 13)
        Me.lbl_ProcessRasters_tab3.TabIndex = 46
        Me.lbl_ProcessRasters_tab3.Text = "Process rasters for model"
        '
        'btn_Run_GC
        '
        Me.btn_Run_GC.Location = New System.Drawing.Point(23, 423)
        Me.btn_Run_GC.Name = "btn_Run_GC"
        Me.btn_Run_GC.Size = New System.Drawing.Size(67, 23)
        Me.btn_Run_GC.TabIndex = 45
        Me.btn_Run_GC.Text = "Run"
        Me.btn_Run_GC.UseVisualStyleBackColor = True
        '
        'cbo_SelectVegRaster
        '
        Me.cbo_SelectVegRaster.FormattingEnabled = True
        Me.cbo_SelectVegRaster.Location = New System.Drawing.Point(343, 131)
        Me.cbo_SelectVegRaster.Name = "cbo_SelectVegRaster"
        Me.cbo_SelectVegRaster.Size = New System.Drawing.Size(165, 21)
        Me.cbo_SelectVegRaster.TabIndex = 44
        '
        'btn_OutputF
        '
        Me.btn_OutputF.Location = New System.Drawing.Point(421, 316)
        Me.btn_OutputF.Name = "btn_OutputF"
        Me.btn_OutputF.Size = New System.Drawing.Size(52, 30)
        Me.btn_OutputF.TabIndex = 43
        Me.btn_OutputF.Text = "Browse"
        Me.btn_OutputF.UseVisualStyleBackColor = True
        '
        'lbl_OutputF
        '
        Me.lbl_OutputF.AutoSize = True
        Me.lbl_OutputF.Location = New System.Drawing.Point(22, 300)
        Me.lbl_OutputF.Name = "lbl_OutputF"
        Me.lbl_OutputF.Size = New System.Drawing.Size(68, 13)
        Me.lbl_OutputF.TabIndex = 42
        Me.lbl_OutputF.Text = "Output folder"
        '
        'txt_OutputF
        '
        Me.txt_OutputF.Location = New System.Drawing.Point(22, 316)
        Me.txt_OutputF.Multiline = True
        Me.txt_OutputF.Name = "txt_OutputF"
        Me.txt_OutputF.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_OutputF.Size = New System.Drawing.Size(394, 40)
        Me.txt_OutputF.TabIndex = 41
        '
        'btn_ReclTextFile
        '
        Me.btn_ReclTextFile.Location = New System.Drawing.Point(423, 253)
        Me.btn_ReclTextFile.Name = "btn_ReclTextFile"
        Me.btn_ReclTextFile.Size = New System.Drawing.Size(52, 30)
        Me.btn_ReclTextFile.TabIndex = 40
        Me.btn_ReclTextFile.Text = "Browse"
        Me.btn_ReclTextFile.UseVisualStyleBackColor = True
        '
        'lbl_parameters
        '
        Me.lbl_parameters.AccessibleDescription = ""
        Me.lbl_parameters.AutoSize = True
        Me.lbl_parameters.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_parameters.Location = New System.Drawing.Point(20, 24)
        Me.lbl_parameters.Name = "lbl_parameters"
        Me.lbl_parameters.Size = New System.Drawing.Size(180, 13)
        Me.lbl_parameters.TabIndex = 3
        Me.lbl_parameters.Text = "Processing Parameter Settings"
        '
        'lbl_SelRootDir
        '
        Me.lbl_SelRootDir.AutoSize = True
        Me.lbl_SelRootDir.Location = New System.Drawing.Point(20, 49)
        Me.lbl_SelRootDir.Name = "lbl_SelRootDir"
        Me.lbl_SelRootDir.Size = New System.Drawing.Size(93, 13)
        Me.lbl_SelRootDir.TabIndex = 2
        Me.lbl_SelRootDir.Text = "Raster input folder"
        '
        'lbl_ReclassTxtFile
        '
        Me.lbl_ReclassTxtFile.AutoSize = True
        Me.lbl_ReclassTxtFile.Location = New System.Drawing.Point(22, 237)
        Me.lbl_ReclassTxtFile.Name = "lbl_ReclassTxtFile"
        Me.lbl_ReclassTxtFile.Size = New System.Drawing.Size(81, 13)
        Me.lbl_ReclassTxtFile.TabIndex = 38
        Me.lbl_ReclassTxtFile.Text = "Reclass text file"
        '
        'btn_RootDir
        '
        Me.btn_RootDir.Location = New System.Drawing.Point(421, 65)
        Me.btn_RootDir.Name = "btn_RootDir"
        Me.btn_RootDir.Size = New System.Drawing.Size(52, 30)
        Me.btn_RootDir.TabIndex = 1
        Me.btn_RootDir.Text = "Browse"
        Me.btn_RootDir.UseVisualStyleBackColor = True
        Me.btn_RootDir.Visible = False
        '
        'btn_ClearAll
        '
        Me.btn_ClearAll.Location = New System.Drawing.Point(656, 326)
        Me.btn_ClearAll.Name = "btn_ClearAll"
        Me.btn_ClearAll.Size = New System.Drawing.Size(73, 30)
        Me.btn_ClearAll.TabIndex = 21
        Me.btn_ClearAll.Text = "Clear All"
        Me.btn_ClearAll.UseVisualStyleBackColor = True
        '
        'txt_SelRootDir
        '
        Me.txt_SelRootDir.Location = New System.Drawing.Point(22, 65)
        Me.txt_SelRootDir.Multiline = True
        Me.txt_SelRootDir.Name = "txt_SelRootDir"
        Me.txt_SelRootDir.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_SelRootDir.Size = New System.Drawing.Size(394, 40)
        Me.txt_SelRootDir.TabIndex = 0
        '
        'txt_ReclassTxtFile
        '
        Me.txt_ReclassTxtFile.Location = New System.Drawing.Point(23, 253)
        Me.txt_ReclassTxtFile.Multiline = True
        Me.txt_ReclassTxtFile.Name = "txt_ReclassTxtFile"
        Me.txt_ReclassTxtFile.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_ReclassTxtFile.Size = New System.Drawing.Size(394, 40)
        Me.txt_ReclassTxtFile.TabIndex = 37
        '
        'lbl_OrigPixelSize
        '
        Me.lbl_OrigPixelSize.AutoSize = True
        Me.lbl_OrigPixelSize.Location = New System.Drawing.Point(641, 65)
        Me.lbl_OrigPixelSize.Name = "lbl_OrigPixelSize"
        Me.lbl_OrigPixelSize.Size = New System.Drawing.Size(90, 13)
        Me.lbl_OrigPixelSize.TabIndex = 7
        Me.lbl_OrigPixelSize.Text = "Original Pixel Size"
        '
        'lbl_NewPixelSize
        '
        Me.lbl_NewPixelSize.AutoSize = True
        Me.lbl_NewPixelSize.Location = New System.Drawing.Point(641, 108)
        Me.lbl_NewPixelSize.Name = "lbl_NewPixelSize"
        Me.lbl_NewPixelSize.Size = New System.Drawing.Size(77, 13)
        Me.lbl_NewPixelSize.TabIndex = 8
        Me.lbl_NewPixelSize.Text = "New Pixel Size"
        '
        'txt_inp_luse
        '
        Me.txt_inp_luse.Location = New System.Drawing.Point(23, 214)
        Me.txt_inp_luse.Name = "txt_inp_luse"
        Me.txt_inp_luse.Size = New System.Drawing.Size(299, 20)
        Me.txt_inp_luse.TabIndex = 13
        '
        'txt_inp_gc
        '
        Me.txt_inp_gc.Location = New System.Drawing.Point(24, 175)
        Me.txt_inp_gc.Name = "txt_inp_gc"
        Me.txt_inp_gc.Size = New System.Drawing.Size(299, 20)
        Me.txt_inp_gc.TabIndex = 12
        '
        'txt_inp_cc
        '
        Me.txt_inp_cc.Location = New System.Drawing.Point(24, 131)
        Me.txt_inp_cc.Name = "txt_inp_cc"
        Me.txt_inp_cc.Size = New System.Drawing.Size(299, 20)
        Me.txt_inp_cc.TabIndex = 11
        '
        'lbl_MaxCost
        '
        Me.lbl_MaxCost.AutoSize = True
        Me.lbl_MaxCost.Location = New System.Drawing.Point(643, 147)
        Me.lbl_MaxCost.Name = "lbl_MaxCost"
        Me.lbl_MaxCost.Size = New System.Drawing.Size(75, 13)
        Me.lbl_MaxCost.TabIndex = 9
        Me.lbl_MaxCost.Text = "Maximum Cost"
        '
        'lbl_inp_luse
        '
        Me.lbl_inp_luse.AutoSize = True
        Me.lbl_inp_luse.Location = New System.Drawing.Point(22, 198)
        Me.lbl_inp_luse.Name = "lbl_inp_luse"
        Me.lbl_inp_luse.Size = New System.Drawing.Size(80, 13)
        Me.lbl_inp_luse.TabIndex = 6
        Me.lbl_inp_luse.Text = "Land use raster"
        '
        'lbl_MaxDist
        '
        Me.lbl_MaxDist.AutoSize = True
        Me.lbl_MaxDist.Location = New System.Drawing.Point(643, 188)
        Me.lbl_MaxDist.Name = "lbl_MaxDist"
        Me.lbl_MaxDist.Size = New System.Drawing.Size(96, 13)
        Me.lbl_MaxDist.TabIndex = 10
        Me.lbl_MaxDist.Text = "Maximum Distance"
        '
        'lbl_inp_gc
        '
        Me.lbl_inp_gc.AutoSize = True
        Me.lbl_inp_gc.Location = New System.Drawing.Point(22, 159)
        Me.lbl_inp_gc.Name = "lbl_inp_gc"
        Me.lbl_inp_gc.Size = New System.Drawing.Size(98, 13)
        Me.lbl_inp_gc.TabIndex = 5
        Me.lbl_inp_gc.Text = "Gap-crossing raster"
        '
        'lbl_inp_cc
        '
        Me.lbl_inp_cc.AutoSize = True
        Me.lbl_inp_cc.Location = New System.Drawing.Point(22, 115)
        Me.lbl_inp_cc.Name = "lbl_inp_cc"
        Me.lbl_inp_cc.Size = New System.Drawing.Size(70, 13)
        Me.lbl_inp_cc.TabIndex = 4
        Me.lbl_inp_cc.Text = "Habitat raster"
        '
        'txt_OriginalPixelSize
        '
        Me.txt_OriginalPixelSize.Location = New System.Drawing.Point(655, 82)
        Me.txt_OriginalPixelSize.Name = "txt_OriginalPixelSize"
        Me.txt_OriginalPixelSize.Size = New System.Drawing.Size(60, 20)
        Me.txt_OriginalPixelSize.TabIndex = 14
        '
        'txt_MaxDist
        '
        Me.txt_MaxDist.Location = New System.Drawing.Point(656, 207)
        Me.txt_MaxDist.Name = "txt_MaxDist"
        Me.txt_MaxDist.Size = New System.Drawing.Size(61, 20)
        Me.txt_MaxDist.TabIndex = 17
        '
        'txt_NewPixelSize
        '
        Me.txt_NewPixelSize.Location = New System.Drawing.Point(655, 124)
        Me.txt_NewPixelSize.Name = "txt_NewPixelSize"
        Me.txt_NewPixelSize.Size = New System.Drawing.Size(61, 20)
        Me.txt_NewPixelSize.TabIndex = 15
        '
        'txt_MaxCost
        '
        Me.txt_MaxCost.Location = New System.Drawing.Point(656, 165)
        Me.txt_MaxCost.Name = "txt_MaxCost"
        Me.txt_MaxCost.Size = New System.Drawing.Size(60, 20)
        Me.txt_MaxCost.TabIndex = 16
        Me.ToolTip1.SetToolTip(Me.txt_MaxCost, "Highest value a pixel can have not including those pixels with infinite value.")
        '
        'tb_4
        '
        Me.tb_4.Controls.Add(Me.btn_ProcessrastersTab4)
        Me.tb_4.Controls.Add(Me.btn_RunCombined)
        Me.tb_4.Controls.Add(Me.btn_saveScriptOutput)
        Me.tb_4.Controls.Add(Me.btn_ClearErrorOutput)
        Me.tb_4.Controls.Add(Me.btn_ClearScriptOutput)
        Me.tb_4.Controls.Add(Me.lbl_ScriptOutp)
        Me.tb_4.Controls.Add(Me.lbl_ScriptError)
        Me.tb_4.Controls.Add(Me.txt_PythonError)
        Me.tb_4.Controls.Add(Me.txt_PythonOutput)
        Me.tb_4.Location = New System.Drawing.Point(4, 22)
        Me.tb_4.Name = "tb_4"
        Me.tb_4.Padding = New System.Windows.Forms.Padding(3)
        Me.tb_4.Size = New System.Drawing.Size(837, 506)
        Me.tb_4.TabIndex = 1
        Me.tb_4.Text = "Script Outputs"
        Me.tb_4.UseVisualStyleBackColor = True
        '
        'btn_ProcessrastersTab4
        '
        Me.btn_ProcessrastersTab4.Location = New System.Drawing.Point(13, 57)
        Me.btn_ProcessrastersTab4.Name = "btn_ProcessrastersTab4"
        Me.btn_ProcessrastersTab4.Size = New System.Drawing.Size(273, 23)
        Me.btn_ProcessrastersTab4.TabIndex = 10
        Me.btn_ProcessrastersTab4.Text = "Process rasters for model"
        Me.btn_ProcessrastersTab4.UseVisualStyleBackColor = True
        '
        'btn_RunCombined
        '
        Me.btn_RunCombined.Location = New System.Drawing.Point(13, 17)
        Me.btn_RunCombined.Name = "btn_RunCombined"
        Me.btn_RunCombined.Size = New System.Drawing.Size(273, 23)
        Me.btn_RunCombined.TabIndex = 9
        Me.btn_RunCombined.Text = "Generate selected Default and Scenario input rasters"
        Me.btn_RunCombined.UseVisualStyleBackColor = True
        '
        'btn_saveScriptOutput
        '
        Me.btn_saveScriptOutput.Location = New System.Drawing.Point(621, 93)
        Me.btn_saveScriptOutput.Name = "btn_saveScriptOutput"
        Me.btn_saveScriptOutput.Size = New System.Drawing.Size(101, 23)
        Me.btn_saveScriptOutput.TabIndex = 8
        Me.btn_saveScriptOutput.Text = "Save text  to file"
        Me.btn_saveScriptOutput.UseVisualStyleBackColor = True
        '
        'btn_ClearErrorOutput
        '
        Me.btn_ClearErrorOutput.Location = New System.Drawing.Point(728, 306)
        Me.btn_ClearErrorOutput.Name = "btn_ClearErrorOutput"
        Me.btn_ClearErrorOutput.Size = New System.Drawing.Size(75, 23)
        Me.btn_ClearErrorOutput.TabIndex = 7
        Me.btn_ClearErrorOutput.Text = "Clear"
        Me.btn_ClearErrorOutput.UseVisualStyleBackColor = True
        '
        'btn_ClearScriptOutput
        '
        Me.btn_ClearScriptOutput.Location = New System.Drawing.Point(728, 93)
        Me.btn_ClearScriptOutput.Name = "btn_ClearScriptOutput"
        Me.btn_ClearScriptOutput.Size = New System.Drawing.Size(75, 23)
        Me.btn_ClearScriptOutput.TabIndex = 6
        Me.btn_ClearScriptOutput.Text = "Clear"
        Me.btn_ClearScriptOutput.UseVisualStyleBackColor = True
        '
        'lbl_ScriptOutp
        '
        Me.lbl_ScriptOutp.AutoSize = True
        Me.lbl_ScriptOutp.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ScriptOutp.Location = New System.Drawing.Point(10, 106)
        Me.lbl_ScriptOutp.Name = "lbl_ScriptOutp"
        Me.lbl_ScriptOutp.Size = New System.Drawing.Size(111, 13)
        Me.lbl_ScriptOutp.TabIndex = 4
        Me.lbl_ScriptOutp.Text = "Script Text Output"
        '
        'lbl_ScriptError
        '
        Me.lbl_ScriptError.AutoSize = True
        Me.lbl_ScriptError.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ScriptError.Location = New System.Drawing.Point(10, 316)
        Me.lbl_ScriptError.Name = "lbl_ScriptError"
        Me.lbl_ScriptError.Size = New System.Drawing.Size(113, 13)
        Me.lbl_ScriptError.TabIndex = 3
        Me.lbl_ScriptError.Text = "Script Error Output"
        '
        'txt_PythonError
        '
        Me.txt_PythonError.Location = New System.Drawing.Point(11, 332)
        Me.txt_PythonError.Multiline = True
        Me.txt_PythonError.Name = "txt_PythonError"
        Me.txt_PythonError.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_PythonError.Size = New System.Drawing.Size(792, 166)
        Me.txt_PythonError.TabIndex = 2
        '
        'txt_PythonOutput
        '
        Me.txt_PythonOutput.Location = New System.Drawing.Point(13, 122)
        Me.txt_PythonOutput.Multiline = True
        Me.txt_PythonOutput.Name = "txt_PythonOutput"
        Me.txt_PythonOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_PythonOutput.Size = New System.Drawing.Size(792, 178)
        Me.txt_PythonOutput.TabIndex = 1
        '
        'tb_Config
        '
        Me.tb_Config.Controls.Add(Me.btn_SetScriptsFolder)
        Me.tb_Config.Controls.Add(Me.txt_ScriptcreateGC_old)
        Me.tb_Config.Controls.Add(Me.lbl_scriptcreateGC_old)
        Me.tb_Config.Controls.Add(Me.btn_About)
        Me.tb_Config.Controls.Add(Me.lbl_ScriptScenario4)
        Me.tb_Config.Controls.Add(Me.txt_scriptScenario4)
        Me.tb_Config.Controls.Add(Me.lbl_ScriptScenario3)
        Me.tb_Config.Controls.Add(Me.txt_ScriptScenario3)
        Me.tb_Config.Controls.Add(Me.lbl_ScriptScenario2b)
        Me.tb_Config.Controls.Add(Me.txt_ScriptScenario2b)
        Me.tb_Config.Controls.Add(Me.lbl_scriptScenario2a)
        Me.tb_Config.Controls.Add(Me.txt_ScriptScenario2a)
        Me.tb_Config.Controls.Add(Me.lbl_ScriptScenario1)
        Me.tb_Config.Controls.Add(Me.txt_ScriptScenario1)
        Me.tb_Config.Controls.Add(Me.lbl_createGapCross)
        Me.tb_Config.Controls.Add(Me.txt_ScriptCreateGapCross)
        Me.tb_Config.Controls.Add(Me.lbl_scriptLuseToRaster)
        Me.tb_Config.Controls.Add(Me.txt_ScriptLuseToRaster)
        Me.tb_Config.Controls.Add(Me.lbl_ScriptsDir)
        Me.tb_Config.Controls.Add(Me.txt_ScriptsFolder)
        Me.tb_Config.Controls.Add(Me.lbl_ProcessingScript)
        Me.tb_Config.Controls.Add(Me.lbl_GC_Script)
        Me.tb_Config.Controls.Add(Me.txt_GC_ScriptName)
        Me.tb_Config.Controls.Add(Me.lbl_ScenPrHeader)
        Me.tb_Config.Controls.Add(Me.lbl_DefaultHeader)
        Me.tb_Config.Controls.Add(Me.lbl_Scripts)
        Me.tb_Config.Controls.Add(Me.btn_SavePyExePth)
        Me.tb_Config.Controls.Add(Me.btn_LoadPyExePth)
        Me.tb_Config.Controls.Add(Me.btn_BrowseArcPyPath)
        Me.tb_Config.Controls.Add(Me.lbl_pthArcPy)
        Me.tb_Config.Controls.Add(Me.txt_ArcPythonApp)
        Me.tb_Config.Controls.Add(Me.Panel1)
        Me.tb_Config.Location = New System.Drawing.Point(4, 22)
        Me.tb_Config.Name = "tb_Config"
        Me.tb_Config.Padding = New System.Windows.Forms.Padding(3)
        Me.tb_Config.Size = New System.Drawing.Size(837, 506)
        Me.tb_Config.TabIndex = 4
        Me.tb_Config.Text = "Configuration"
        Me.tb_Config.UseVisualStyleBackColor = True
        '
        'btn_SetScriptsFolder
        '
        Me.btn_SetScriptsFolder.Location = New System.Drawing.Point(483, 98)
        Me.btn_SetScriptsFolder.Name = "btn_SetScriptsFolder"
        Me.btn_SetScriptsFolder.Size = New System.Drawing.Size(185, 23)
        Me.btn_SetScriptsFolder.TabIndex = 64
        Me.btn_SetScriptsFolder.Text = "Set to 'GAP_CLoSR_Code' folder"
        Me.btn_SetScriptsFolder.UseVisualStyleBackColor = True
        '
        'txt_ScriptcreateGC_old
        '
        Me.txt_ScriptcreateGC_old.Location = New System.Drawing.Point(213, 238)
        Me.txt_ScriptcreateGC_old.Name = "txt_ScriptcreateGC_old"
        Me.txt_ScriptcreateGC_old.Size = New System.Drawing.Size(250, 20)
        Me.txt_ScriptcreateGC_old.TabIndex = 62
        '
        'lbl_scriptcreateGC_old
        '
        Me.lbl_scriptcreateGC_old.AutoSize = True
        Me.lbl_scriptcreateGC_old.Location = New System.Drawing.Point(20, 241)
        Me.lbl_scriptcreateGC_old.Name = "lbl_scriptcreateGC_old"
        Me.lbl_scriptcreateGC_old.Size = New System.Drawing.Size(182, 13)
        Me.lbl_scriptcreateGC_old.TabIndex = 61
        Me.lbl_scriptcreateGC_old.Text = "Create gap-crosing layer (old method)"
        '
        'btn_About
        '
        Me.btn_About.Location = New System.Drawing.Point(688, 164)
        Me.btn_About.Name = "btn_About"
        Me.btn_About.Size = New System.Drawing.Size(106, 23)
        Me.btn_About.TabIndex = 60
        Me.btn_About.Text = "About this GUI"
        Me.btn_About.UseVisualStyleBackColor = True
        Me.btn_About.Visible = False
        '
        'lbl_ScriptScenario4
        '
        Me.lbl_ScriptScenario4.AutoSize = True
        Me.lbl_ScriptScenario4.Location = New System.Drawing.Point(19, 407)
        Me.lbl_ScriptScenario4.Name = "lbl_ScriptScenario4"
        Me.lbl_ScriptScenario4.Size = New System.Drawing.Size(190, 13)
        Me.lbl_ScriptScenario4.TabIndex = 59
        Me.lbl_ScriptScenario4.Text = "4. Modify Land-use - Add Infrastructure"
        '
        'txt_scriptScenario4
        '
        Me.txt_scriptScenario4.Location = New System.Drawing.Point(214, 401)
        Me.txt_scriptScenario4.Name = "txt_scriptScenario4"
        Me.txt_scriptScenario4.Size = New System.Drawing.Size(252, 20)
        Me.txt_scriptScenario4.TabIndex = 58
        '
        'lbl_ScriptScenario3
        '
        Me.lbl_ScriptScenario3.AutoSize = True
        Me.lbl_ScriptScenario3.Location = New System.Drawing.Point(20, 380)
        Me.lbl_ScriptScenario3.Name = "lbl_ScriptScenario3"
        Me.lbl_ScriptScenario3.Size = New System.Drawing.Size(144, 13)
        Me.lbl_ScriptScenario3.TabIndex = 57
        Me.lbl_ScriptScenario3.Text = "3. Create Gap-crossing Layer"
        '
        'txt_ScriptScenario3
        '
        Me.txt_ScriptScenario3.Location = New System.Drawing.Point(214, 374)
        Me.txt_ScriptScenario3.Name = "txt_ScriptScenario3"
        Me.txt_ScriptScenario3.Size = New System.Drawing.Size(251, 20)
        Me.txt_ScriptScenario3.TabIndex = 56
        '
        'lbl_ScriptScenario2b
        '
        Me.lbl_ScriptScenario2b.AutoSize = True
        Me.lbl_ScriptScenario2b.Location = New System.Drawing.Point(17, 354)
        Me.lbl_ScriptScenario2b.Name = "lbl_ScriptScenario2b"
        Me.lbl_ScriptScenario2b.Size = New System.Drawing.Size(186, 13)
        Me.lbl_ScriptScenario2b.TabIndex = 55
        Me.lbl_ScriptScenario2b.Text = "2b. Modify Vegetation Layer - Addition"
        '
        'txt_ScriptScenario2b
        '
        Me.txt_ScriptScenario2b.Location = New System.Drawing.Point(214, 347)
        Me.txt_ScriptScenario2b.Name = "txt_ScriptScenario2b"
        Me.txt_ScriptScenario2b.Size = New System.Drawing.Size(251, 20)
        Me.txt_ScriptScenario2b.TabIndex = 54
        '
        'lbl_scriptScenario2a
        '
        Me.lbl_scriptScenario2a.AutoSize = True
        Me.lbl_scriptScenario2a.Location = New System.Drawing.Point(17, 327)
        Me.lbl_scriptScenario2a.Name = "lbl_scriptScenario2a"
        Me.lbl_scriptScenario2a.Size = New System.Drawing.Size(190, 13)
        Me.lbl_scriptScenario2a.TabIndex = 53
        Me.lbl_scriptScenario2a.Text = "2a. Modify Vegetation Layer - Removal"
        '
        'txt_ScriptScenario2a
        '
        Me.txt_ScriptScenario2a.Location = New System.Drawing.Point(214, 320)
        Me.txt_ScriptScenario2a.Name = "txt_ScriptScenario2a"
        Me.txt_ScriptScenario2a.Size = New System.Drawing.Size(251, 20)
        Me.txt_ScriptScenario2a.TabIndex = 52
        '
        'lbl_ScriptScenario1
        '
        Me.lbl_ScriptScenario1.AutoSize = True
        Me.lbl_ScriptScenario1.Location = New System.Drawing.Point(16, 301)
        Me.lbl_ScriptScenario1.Name = "lbl_ScriptScenario1"
        Me.lbl_ScriptScenario1.Size = New System.Drawing.Size(153, 13)
        Me.lbl_ScriptScenario1.TabIndex = 51
        Me.lbl_ScriptScenario1.Text = "1. Create Raster Change Layer"
        '
        'txt_ScriptScenario1
        '
        Me.txt_ScriptScenario1.Location = New System.Drawing.Point(214, 294)
        Me.txt_ScriptScenario1.Name = "txt_ScriptScenario1"
        Me.txt_ScriptScenario1.Size = New System.Drawing.Size(251, 20)
        Me.txt_ScriptScenario1.TabIndex = 50
        '
        'lbl_createGapCross
        '
        Me.lbl_createGapCross.AutoSize = True
        Me.lbl_createGapCross.Location = New System.Drawing.Point(20, 218)
        Me.lbl_createGapCross.Name = "lbl_createGapCross"
        Me.lbl_createGapCross.Size = New System.Drawing.Size(132, 13)
        Me.lbl_createGapCross.TabIndex = 49
        Me.lbl_createGapCross.Text = "Create Gap-crossing Layer"
        '
        'txt_ScriptCreateGapCross
        '
        Me.txt_ScriptCreateGapCross.Location = New System.Drawing.Point(213, 211)
        Me.txt_ScriptCreateGapCross.Name = "txt_ScriptCreateGapCross"
        Me.txt_ScriptCreateGapCross.Size = New System.Drawing.Size(251, 20)
        Me.txt_ScriptCreateGapCross.TabIndex = 48
        '
        'lbl_scriptLuseToRaster
        '
        Me.lbl_scriptLuseToRaster.AutoSize = True
        Me.lbl_scriptLuseToRaster.Location = New System.Drawing.Point(19, 192)
        Me.lbl_scriptLuseToRaster.Name = "lbl_scriptLuseToRaster"
        Me.lbl_scriptLuseToRaster.Size = New System.Drawing.Size(137, 13)
        Me.lbl_scriptLuseToRaster.TabIndex = 47
        Me.lbl_scriptLuseToRaster.Text = "Convert Land-use to Raster"
        '
        'txt_ScriptLuseToRaster
        '
        Me.txt_ScriptLuseToRaster.Location = New System.Drawing.Point(213, 185)
        Me.txt_ScriptLuseToRaster.Name = "txt_ScriptLuseToRaster"
        Me.txt_ScriptLuseToRaster.Size = New System.Drawing.Size(252, 20)
        Me.txt_ScriptLuseToRaster.TabIndex = 46
        '
        'lbl_ScriptsDir
        '
        Me.lbl_ScriptsDir.AutoSize = True
        Me.lbl_ScriptsDir.Location = New System.Drawing.Point(16, 82)
        Me.lbl_ScriptsDir.Name = "lbl_ScriptsDir"
        Me.lbl_ScriptsDir.Size = New System.Drawing.Size(84, 13)
        Me.lbl_ScriptsDir.TabIndex = 45
        Me.lbl_ScriptsDir.Text = "Scripts Directory"
        '
        'txt_ScriptsFolder
        '
        Me.txt_ScriptsFolder.Location = New System.Drawing.Point(18, 98)
        Me.txt_ScriptsFolder.Multiline = True
        Me.txt_ScriptsFolder.Name = "txt_ScriptsFolder"
        Me.txt_ScriptsFolder.Size = New System.Drawing.Size(445, 55)
        Me.txt_ScriptsFolder.TabIndex = 44
        Me.ToolTip1.SetToolTip(Me.txt_ScriptsFolder, "The directory for Python scripts. Enclose in quotes if the path contains spaces.")
        '
        'lbl_ProcessingScript
        '
        Me.lbl_ProcessingScript.AutoSize = True
        Me.lbl_ProcessingScript.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ProcessingScript.Location = New System.Drawing.Point(22, 435)
        Me.lbl_ProcessingScript.Name = "lbl_ProcessingScript"
        Me.lbl_ProcessingScript.Size = New System.Drawing.Size(156, 13)
        Me.lbl_ProcessingScript.TabIndex = 43
        Me.lbl_ProcessingScript.Text = "Process Rasters for Model"
        '
        'lbl_GC_Script
        '
        Me.lbl_GC_Script.AutoSize = True
        Me.lbl_GC_Script.Location = New System.Drawing.Point(22, 462)
        Me.lbl_GC_Script.Name = "lbl_GC_Script"
        Me.lbl_GC_Script.Size = New System.Drawing.Size(99, 13)
        Me.lbl_GC_Script.TabIndex = 41
        Me.lbl_GC_Script.Text = "GAP_CLoSR Script"
        '
        'txt_GC_ScriptName
        '
        Me.txt_GC_ScriptName.Location = New System.Drawing.Point(214, 455)
        Me.txt_GC_ScriptName.Name = "txt_GC_ScriptName"
        Me.txt_GC_ScriptName.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_GC_ScriptName.Size = New System.Drawing.Size(251, 20)
        Me.txt_GC_ScriptName.TabIndex = 40
        '
        'lbl_ScenPrHeader
        '
        Me.lbl_ScenPrHeader.AutoSize = True
        Me.lbl_ScenPrHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ScenPrHeader.Location = New System.Drawing.Point(17, 274)
        Me.lbl_ScenPrHeader.Name = "lbl_ScenPrHeader"
        Me.lbl_ScenPrHeader.Size = New System.Drawing.Size(123, 13)
        Me.lbl_ScenPrHeader.TabIndex = 38
        Me.lbl_ScenPrHeader.Text = "Scenario Processing"
        '
        'lbl_DefaultHeader
        '
        Me.lbl_DefaultHeader.AutoSize = True
        Me.lbl_DefaultHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_DefaultHeader.Location = New System.Drawing.Point(19, 164)
        Me.lbl_DefaultHeader.Name = "lbl_DefaultHeader"
        Me.lbl_DefaultHeader.Size = New System.Drawing.Size(48, 13)
        Me.lbl_DefaultHeader.TabIndex = 37
        Me.lbl_DefaultHeader.Text = "Default"
        '
        'lbl_Scripts
        '
        Me.lbl_Scripts.AutoSize = True
        Me.lbl_Scripts.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Scripts.Location = New System.Drawing.Point(16, 69)
        Me.lbl_Scripts.Name = "lbl_Scripts"
        Me.lbl_Scripts.Size = New System.Drawing.Size(112, 13)
        Me.lbl_Scripts.TabIndex = 35
        Me.lbl_Scripts.Text = "Processing Scripts"
        '
        'btn_SavePyExePth
        '
        Me.btn_SavePyExePth.Location = New System.Drawing.Point(729, 43)
        Me.btn_SavePyExePth.Name = "btn_SavePyExePth"
        Me.btn_SavePyExePth.Size = New System.Drawing.Size(91, 23)
        Me.btn_SavePyExePth.TabIndex = 34
        Me.btn_SavePyExePth.Text = "Save Config."
        Me.btn_SavePyExePth.UseVisualStyleBackColor = True
        '
        'btn_LoadPyExePth
        '
        Me.btn_LoadPyExePth.Location = New System.Drawing.Point(729, 14)
        Me.btn_LoadPyExePth.Name = "btn_LoadPyExePth"
        Me.btn_LoadPyExePth.Size = New System.Drawing.Size(88, 23)
        Me.btn_LoadPyExePth.TabIndex = 33
        Me.btn_LoadPyExePth.Text = "Reload Config."
        Me.btn_LoadPyExePth.UseVisualStyleBackColor = True
        '
        'btn_BrowseArcPyPath
        '
        Me.btn_BrowseArcPyPath.Location = New System.Drawing.Point(484, 24)
        Me.btn_BrowseArcPyPath.Name = "btn_BrowseArcPyPath"
        Me.btn_BrowseArcPyPath.Size = New System.Drawing.Size(52, 23)
        Me.btn_BrowseArcPyPath.TabIndex = 32
        Me.btn_BrowseArcPyPath.Text = "Browse"
        Me.btn_BrowseArcPyPath.UseVisualStyleBackColor = True
        '
        'lbl_pthArcPy
        '
        Me.lbl_pthArcPy.AutoSize = True
        Me.lbl_pthArcPy.Location = New System.Drawing.Point(6, 14)
        Me.lbl_pthArcPy.Name = "lbl_pthArcPy"
        Me.lbl_pthArcPy.Size = New System.Drawing.Size(336, 13)
        Me.lbl_pthArcPy.TabIndex = 29
        Me.lbl_pthArcPy.Text = "ArgGIS Python Application (eg. C:\Python27\ArcGIS10.2\python.exe)"
        '
        'txt_ArcPythonApp
        '
        Me.txt_ArcPythonApp.Location = New System.Drawing.Point(8, 30)
        Me.txt_ArcPythonApp.Name = "txt_ArcPythonApp"
        Me.txt_ArcPythonApp.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txt_ArcPythonApp.Size = New System.Drawing.Size(447, 20)
        Me.txt_ArcPythonApp.TabIndex = 28
        Me.ToolTip1.SetToolTip(Me.txt_ArcPythonApp, "Python.exe name and path or 'python'. Can be enclosed in quotes.")
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Location = New System.Drawing.Point(9, 60)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(468, 429)
        Me.Panel1.TabIndex = 63
        '
        'dlg_GetRootFolder
        '
        Me.dlg_GetRootFolder.Description = "Please select the input folder"
        '
        'dlg_FindGCScript
        '
        Me.dlg_FindGCScript.Filter = "Python Scripts (*.py)|*.py|(*.*)|*.*"
        '
        'dlg_ReclassText
        '
        Me.dlg_ReclassText.FileName = "luse_reclass"
        Me.dlg_ReclassText.Filter = "Text Files (*.txt)|*.txt|(*.*)|*.*"
        '
        'dlg_GetScenarioFile
        '
        Me.dlg_GetScenarioFile.Filter = "Text Files (*.txt)|*.txt|(*.*)|*.*"
        '
        'dlg_SaveF
        '
        Me.dlg_SaveF.Filter = "Text Files (*.txt)|*.txt|(*.*)|*.*"
        '
        'dlg_OpenShapefile
        '
        Me.dlg_OpenShapefile.Filter = "Shapefiles (*.shp)|*.shp|(*.*)|*.*"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadScenarioToolStripMenuItem, Me.ViewToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(846, 24)
        Me.MenuStrip1.TabIndex = 17
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'LoadScenarioToolStripMenuItem
        '
        Me.LoadScenarioToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadScenarioToolStripMenuItem1, Me.SaveScenarioToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.LoadScenarioToolStripMenuItem.Name = "LoadScenarioToolStripMenuItem"
        Me.LoadScenarioToolStripMenuItem.Size = New System.Drawing.Size(35, 20)
        Me.LoadScenarioToolStripMenuItem.Text = "File"
        '
        'LoadScenarioToolStripMenuItem1
        '
        Me.LoadScenarioToolStripMenuItem1.Name = "LoadScenarioToolStripMenuItem1"
        Me.LoadScenarioToolStripMenuItem1.Size = New System.Drawing.Size(142, 22)
        Me.LoadScenarioToolStripMenuItem1.Text = "Load Scenario"
        '
        'SaveScenarioToolStripMenuItem
        '
        Me.SaveScenarioToolStripMenuItem.Name = "SaveScenarioToolStripMenuItem"
        Me.SaveScenarioToolStripMenuItem.Size = New System.Drawing.Size(142, 22)
        Me.SaveScenarioToolStripMenuItem.Text = "Save Scenario"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(142, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DefaultsTabToolStripMenuItem, Me.ScenariosTabToolStripMenuItem, Me.ProcessrastersForModelTabToolStripMenuItem, Me.ScriptOutputsTabToolStripMenuItem, Me.PythonConfigTabToolStripMenuItem})
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.ViewToolStripMenuItem.Text = "View"
        '
        'DefaultsTabToolStripMenuItem
        '
        Me.DefaultsTabToolStripMenuItem.Name = "DefaultsTabToolStripMenuItem"
        Me.DefaultsTabToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.DefaultsTabToolStripMenuItem.Text = "Defaults tab"
        '
        'ScenariosTabToolStripMenuItem
        '
        Me.ScenariosTabToolStripMenuItem.Name = "ScenariosTabToolStripMenuItem"
        Me.ScenariosTabToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.ScenariosTabToolStripMenuItem.Text = "Scenarios tab"
        '
        'ProcessrastersForModelTabToolStripMenuItem
        '
        Me.ProcessrastersForModelTabToolStripMenuItem.Name = "ProcessrastersForModelTabToolStripMenuItem"
        Me.ProcessrastersForModelTabToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.ProcessrastersForModelTabToolStripMenuItem.Text = "Process Rasters for Model tab"
        '
        'ScriptOutputsTabToolStripMenuItem
        '
        Me.ScriptOutputsTabToolStripMenuItem.Name = "ScriptOutputsTabToolStripMenuItem"
        Me.ScriptOutputsTabToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.ScriptOutputsTabToolStripMenuItem.Text = "Script Outputs tab"
        '
        'PythonConfigTabToolStripMenuItem
        '
        Me.PythonConfigTabToolStripMenuItem.Name = "PythonConfigTabToolStripMenuItem"
        Me.PythonConfigTabToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.PythonConfigTabToolStripMenuItem.Text = "Python Config tab"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutGAPCLosRToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutGAPCLosRToolStripMenuItem
        '
        Me.AboutGAPCLosRToolStripMenuItem.Name = "AboutGAPCLosRToolStripMenuItem"
        Me.AboutGAPCLosRToolStripMenuItem.Size = New System.Drawing.Size(159, 22)
        Me.AboutGAPCLosRToolStripMenuItem.Text = "About GAP CLosR"
        '
        'frm_Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoScrollMinSize = New System.Drawing.Size(618, 444)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(846, 560)
        Me.Controls.Add(Me.tb_Settings)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frm_Main"
        Me.Text = "GAP CLoSR"
        Me.tb_Settings.ResumeLayout(False)
        Me.tb_1.ResumeLayout(False)
        Me.tb_1.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.tb_2.ResumeLayout(False)
        Me.tb_2.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.tb_3.ResumeLayout(False)
        Me.tb_3.PerformLayout()
        Me.tb_4.ResumeLayout(False)
        Me.tb_4.PerformLayout()
        Me.tb_Config.ResumeLayout(False)
        Me.tb_Config.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tb_Settings As System.Windows.Forms.TabControl
    Friend WithEvents tb_3 As System.Windows.Forms.TabPage
    Friend WithEvents tb_4 As System.Windows.Forms.TabPage
    Friend WithEvents txt_SelRootDir As System.Windows.Forms.TextBox
    Friend WithEvents btn_RootDir As System.Windows.Forms.Button
    Friend WithEvents dlg_GetRootFolder As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents lbl_parameters As System.Windows.Forms.Label
    Friend WithEvents lbl_SelRootDir As System.Windows.Forms.Label
    Friend WithEvents txt_MaxDist As System.Windows.Forms.TextBox
    Friend WithEvents txt_MaxCost As System.Windows.Forms.TextBox
    Friend WithEvents txt_NewPixelSize As System.Windows.Forms.TextBox
    Friend WithEvents txt_OriginalPixelSize As System.Windows.Forms.TextBox
    Friend WithEvents txt_inp_luse As System.Windows.Forms.TextBox
    Friend WithEvents txt_inp_gc As System.Windows.Forms.TextBox
    Friend WithEvents txt_inp_cc As System.Windows.Forms.TextBox
    Friend WithEvents lbl_MaxDist As System.Windows.Forms.Label
    Friend WithEvents lbl_MaxCost As System.Windows.Forms.Label
    Friend WithEvents lbl_NewPixelSize As System.Windows.Forms.Label
    Friend WithEvents lbl_OrigPixelSize As System.Windows.Forms.Label
    Friend WithEvents lbl_inp_luse As System.Windows.Forms.Label
    Friend WithEvents lbl_inp_gc As System.Windows.Forms.Label
    Friend WithEvents lbl_inp_cc As System.Windows.Forms.Label
    Friend WithEvents btn_ClearAll As System.Windows.Forms.Button
    Friend WithEvents lbl_ScriptOutp As System.Windows.Forms.Label
    Friend WithEvents lbl_ScriptError As System.Windows.Forms.Label
    Friend WithEvents txt_PythonError As System.Windows.Forms.TextBox
    Friend WithEvents txt_PythonOutput As System.Windows.Forms.TextBox
    Friend WithEvents dlg_FindArcPyPath As System.Windows.Forms.OpenFileDialog
    Friend WithEvents dlg_FindGCScript As System.Windows.Forms.OpenFileDialog
    Friend WithEvents tb_Config As System.Windows.Forms.TabPage
    Friend WithEvents btn_BrowseArcPyPath As System.Windows.Forms.Button
    Friend WithEvents lbl_pthArcPy As System.Windows.Forms.Label
    Friend WithEvents txt_ArcPythonApp As System.Windows.Forms.TextBox
    Friend WithEvents lbl_ReclassTxtFile As System.Windows.Forms.Label
    Friend WithEvents txt_ReclassTxtFile As System.Windows.Forms.TextBox
    Friend WithEvents dlg_ReclassText As System.Windows.Forms.OpenFileDialog
    Friend WithEvents btn_ReclTextFile As System.Windows.Forms.Button
    Friend WithEvents dlg_GetScenarioFile As System.Windows.Forms.OpenFileDialog
    Friend WithEvents dlg_SaveF As System.Windows.Forms.SaveFileDialog
    Friend WithEvents btn_SavePyExePth As System.Windows.Forms.Button
    Friend WithEvents btn_LoadPyExePth As System.Windows.Forms.Button
    Friend WithEvents tb_1 As System.Windows.Forms.TabPage
    Friend WithEvents tb_2 As System.Windows.Forms.TabPage
    Friend WithEvents btn_ClearErrorOutput As System.Windows.Forms.Button
    Friend WithEvents btn_ClearScriptOutput As System.Windows.Forms.Button
    Friend WithEvents lbl_ProcessingScript As System.Windows.Forms.Label
    Friend WithEvents lbl_GC_Script As System.Windows.Forms.Label
    Friend WithEvents txt_GC_ScriptName As System.Windows.Forms.TextBox
    Friend WithEvents lbl_ScenPrHeader As System.Windows.Forms.Label
    Friend WithEvents lbl_DefaultHeader As System.Windows.Forms.Label
    Friend WithEvents lbl_Scripts As System.Windows.Forms.Label
    Friend WithEvents lbl_ScriptScenario2b As System.Windows.Forms.Label
    Friend WithEvents txt_ScriptScenario2b As System.Windows.Forms.TextBox
    Friend WithEvents lbl_scriptScenario2a As System.Windows.Forms.Label
    Friend WithEvents txt_ScriptScenario2a As System.Windows.Forms.TextBox
    Friend WithEvents lbl_ScriptScenario1 As System.Windows.Forms.Label
    Friend WithEvents txt_ScriptScenario1 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_createGapCross As System.Windows.Forms.Label
    Friend WithEvents txt_ScriptCreateGapCross As System.Windows.Forms.TextBox
    Friend WithEvents lbl_scriptLuseToRaster As System.Windows.Forms.Label
    Friend WithEvents txt_ScriptLuseToRaster As System.Windows.Forms.TextBox
    Friend WithEvents lbl_ScriptsDir As System.Windows.Forms.Label
    Friend WithEvents txt_ScriptsFolder As System.Windows.Forms.TextBox
    Friend WithEvents lbl_ScriptScenario4 As System.Windows.Forms.Label
    Friend WithEvents txt_scriptScenario4 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_ScriptScenario3 As System.Windows.Forms.Label
    Friend WithEvents txt_ScriptScenario3 As System.Windows.Forms.TextBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents btn_About As System.Windows.Forms.Button
    Friend WithEvents btn_OutputF As System.Windows.Forms.Button
    Friend WithEvents lbl_OutputF As System.Windows.Forms.Label
    Friend WithEvents txt_OutputF As System.Windows.Forms.TextBox
    Friend WithEvents txt_gapcrossOld As System.Windows.Forms.TextBox
    Friend WithEvents lbl_gapcross_old As System.Windows.Forms.Label
    Friend WithEvents lbl_gap_cross1 As System.Windows.Forms.Label
    Friend WithEvents lbl_luse1 As System.Windows.Forms.Label
    Friend WithEvents lbl_InpVeg As System.Windows.Forms.Label
    Friend WithEvents txt_gap_cross1 As System.Windows.Forms.TextBox
    Friend WithEvents txt_luse1 As System.Windows.Forms.TextBox
    Friend WithEvents txt_inplh_cc1 As System.Windows.Forms.TextBox
    Friend WithEvents btn_InputF As System.Windows.Forms.Button
    Friend WithEvents lbl_InputF As System.Windows.Forms.Label
    Friend WithEvents txt_InputF As System.Windows.Forms.TextBox
    Friend WithEvents lbl_RasterValueField As System.Windows.Forms.Label
    Friend WithEvents txt_RasterValueField As System.Windows.Forms.TextBox
    Friend WithEvents lbl_MaxDist1 As System.Windows.Forms.Label
    Friend WithEvents txt_MaxDist1 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_HydrolVal1 As System.Windows.Forms.Label
    Friend WithEvents txt_HydrolVal1 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_NewRasAdd As System.Windows.Forms.Label
    Friend WithEvents txt_NewRastAdd As System.Windows.Forms.TextBox
    Friend WithEvents lbl_NewVegRemove As System.Windows.Forms.Label
    Friend WithEvents txt_NewRasterRemv As System.Windows.Forms.TextBox
    Friend WithEvents lbl_RasValFld_Tab2 As System.Windows.Forms.Label
    Friend WithEvents txt_RasValFldTab2 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_CellMultip2 As System.Windows.Forms.Label
    Friend WithEvents txt_CellMultip2 As System.Windows.Forms.TextBox
    Friend WithEvents txt_ChangerasterTab2 As System.Windows.Forms.TextBox
    Friend WithEvents txt_ChngLyrShpTab2 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_changeLyrShpTab2 As System.Windows.Forms.Label
    Friend WithEvents lbl_changerasterTab2 As System.Windows.Forms.Label
    Friend WithEvents btn_browseChngShpTab2 As System.Windows.Forms.Button
    Friend WithEvents lbl_gapcrossTab2 As System.Windows.Forms.Label
    Friend WithEvents lbl_landuseTab2 As System.Windows.Forms.Label
    Friend WithEvents lbl_habitatTab2 As System.Windows.Forms.Label
    Friend WithEvents txt_GapcrossTab2 As System.Windows.Forms.TextBox
    Friend WithEvents txt_landuseTab2 As System.Windows.Forms.TextBox
    Friend WithEvents txt_habitatTab2 As System.Windows.Forms.TextBox
    Friend WithEvents btn_browse_RasFolderTab2 As System.Windows.Forms.Button
    Friend WithEvents lbl_RasterFoldertab2 As System.Windows.Forms.Label
    Friend WithEvents txt_rasterFolderTab2 As System.Windows.Forms.TextBox
    Friend WithEvents txt_LanduseShp As System.Windows.Forms.TextBox
    Friend WithEvents lbl_LanduseShp As System.Windows.Forms.Label
    Friend WithEvents btn_LanduseShp As System.Windows.Forms.Button
    Friend WithEvents lbl_hydrolRasVal2 As System.Windows.Forms.Label
    Friend WithEvents txt_HydrolVal2 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_infrastructure As System.Windows.Forms.Label
    Friend WithEvents txt_infrastructure As System.Windows.Forms.TextBox
    Friend WithEvents txt_ScriptcreateGC_old As System.Windows.Forms.TextBox
    Friend WithEvents lbl_scriptcreateGC_old As System.Windows.Forms.Label
    Friend WithEvents dlg_OpenShapefile As System.Windows.Forms.OpenFileDialog
    Friend WithEvents lbl_InputsTab1 As System.Windows.Forms.Label
    Friend WithEvents lbl_luseToRasterTab1 As System.Windows.Forms.Label
    Friend WithEvents lbl_CellMultiTab1 As System.Windows.Forms.Label
    Friend WithEvents txt_inpMultiTab1 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_outputsTab1 As System.Windows.Forms.Label
    Friend WithEvents btn_GapCrossOld As System.Windows.Forms.Button
    Friend WithEvents btn_CreateGapCross As System.Windows.Forms.Button
    Friend WithEvents btn_RunConvLusetoRaster As System.Windows.Forms.Button
    Friend WithEvents lbl_CreategapcrossTab1 As System.Windows.Forms.Label
    Friend WithEvents lbl_gapcrosstab1 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents lbl_Run4text As System.Windows.Forms.Label
    Friend WithEvents lbl_run3text As System.Windows.Forms.Label
    Friend WithEvents lbl_run2btext As System.Windows.Forms.Label
    Friend WithEvents lbl_run2atext As System.Windows.Forms.Label
    Friend WithEvents lbl_run1txt As System.Windows.Forms.Label
    Friend WithEvents btn_RunScen4 As System.Windows.Forms.Button
    Friend WithEvents btn_RunScen3 As System.Windows.Forms.Button
    Friend WithEvents btn_RunScen2b As System.Windows.Forms.Button
    Friend WithEvents btn_RunScen2a As System.Windows.Forms.Button
    Friend WithEvents btn_RunScen1 As System.Windows.Forms.Button
    Friend WithEvents cbo_SelectVegRaster As System.Windows.Forms.ComboBox
    Friend WithEvents btn_Run_GC As System.Windows.Forms.Button
    Friend WithEvents lbl_ProcessRasters_tab3 As System.Windows.Forms.Label
    Friend WithEvents cbo_SelectLanduseRaster As System.Windows.Forms.ComboBox
    Friend WithEvents cbo_SelectGapcrossRaster As System.Windows.Forms.ComboBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents LoadScenarioToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadScenarioToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveScenarioToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DefaultsTabToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScenariosTabToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProcessrastersForModelTabToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScriptOutputsTabToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PythonConfigTabToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutGAPCLosRToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btn_saveScriptOutput As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btn_BrHabRasTab1 As System.Windows.Forms.Button
    Friend WithEvents btn_BrGcORasTab1 As System.Windows.Forms.Button
    Friend WithEvents btn_BrGcRasTab1 As System.Windows.Forms.Button
    Friend WithEvents btn_BrLuRasTab1 As System.Windows.Forms.Button
    Friend WithEvents chk_SelDefGCO As System.Windows.Forms.CheckBox
    Friend WithEvents chk_SelDefGC As System.Windows.Forms.CheckBox
    Friend WithEvents chk_SelDefL As System.Windows.Forms.CheckBox
    Friend WithEvents chk_selS1 As System.Windows.Forms.CheckBox
    Friend WithEvents chk_selS2a As System.Windows.Forms.CheckBox
    Friend WithEvents chk_sel2b As System.Windows.Forms.CheckBox
    Friend WithEvents chk_sel3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk_selS4 As System.Windows.Forms.CheckBox
    Friend WithEvents btn_RunCombined As System.Windows.Forms.Button
    Friend WithEvents btn_BrChTab2 As System.Windows.Forms.Button
    Friend WithEvents btn_BrRemTab2 As System.Windows.Forms.Button
    Friend WithEvents btn_BrAddTab2 As System.Windows.Forms.Button
    Friend WithEvents btn_BrGCTab2 As System.Windows.Forms.Button
    Friend WithEvents btn_BrInfTab2 As System.Windows.Forms.Button
    Friend WithEvents btn_SetScriptsFolder As System.Windows.Forms.Button
    Friend WithEvents btn_ProcessrastersTab4 As System.Windows.Forms.Button

End Class
